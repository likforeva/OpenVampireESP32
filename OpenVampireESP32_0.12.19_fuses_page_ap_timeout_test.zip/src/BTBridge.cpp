#include "BTBridge.h"

BluetoothSerial SerialBT;
HardwareSerial &vampirePort = Serial2;
BTBridge btBridge;

namespace
{
constexpr size_t BRIDGE_BUFFER_SIZE = 512;
constexpr size_t TEXT_LINE_BUFFER_SIZE = 512;
constexpr uint32_t TEXT_PACKET_GAP_MS = 8;

uint8_t textLineBuffer[TEXT_LINE_BUFFER_SIZE];
size_t textLineLength = 0;

bool isTextByte(uint8_t c)
{
    return c == '\r' || c == '\n' || c == '\t' || (c >= 0x20 && c <= 0x7e);
}

void flushTextLine()
{
    if (!textLineLength)
        return;

    SerialBT.write(textLineBuffer, textLineLength);
    textLineLength = 0;

    // Preserve the line-oriented RFCOMM behaviour expected by the legacy
    // Android control application.
    delay(TEXT_PACKET_GAP_MS);
}
}

void BTBridge::begin()
{
    active = false;
    connected = false;
    rawMode = false;
    textLineLength = 0;
}

void BTBridge::setDeviceName(const String &name)
{
    if (name.isEmpty() || name == deviceName)
        return;

    deviceName = name;
    if (active && !connected)
        restart();
}

const String &BTBridge::getDeviceName() const { return deviceName; }
bool BTBridge::enabled() const { return active; }
bool BTBridge::isConnected() const { return connected; }

void BTBridge::enable()
{
    if (active)
        return;

    SerialBT.setPin("1234");
    if (!SerialBT.begin(deviceName))
    {
        Serial.println("Bluetooth start failed");
        return;
    }

    active = true;
    connected = false;
    Serial.println("Bluetooth started as " + deviceName);
}

void BTBridge::disable()
{
    if (!active)
        return;

    if (!rawMode)
        flushTextLine();

    SerialBT.end();
    active = false;
    connected = false;
    rawMode = false;
    textLineLength = 0;
    Serial.println("Bluetooth stopped");
}

void BTBridge::restart()
{
    disable();
    delay(300);
    enable();
}

void BTBridge::update()
{
    if (!active)
        return;

    const bool newState = SerialBT.hasClient();
    if (newState != connected)
    {
        connected = newState;
        rawMode = false;
        textLineLength = 0;
        Serial.println(connected ? "Bluetooth client connected; bridge ON"
                                 : "Bluetooth client disconnected; bridge OFF");
    }

    if (!connected)
        return;

    uint8_t buffer[BRIDGE_BUFFER_SIZE];

    // Android application -> Vampire.
    size_t count = 0;
    while (SerialBT.available() && count < sizeof(buffer))
    {
        const int value = SerialBT.read();
        if (value < 0)
            break;
        buffer[count++] = static_cast<uint8_t>(value);
    }
    if (count)
        vampirePort.write(buffer, count);

    // Vampire -> Android application.
    count = 0;
    while (vampirePort.available() && count < sizeof(buffer))
    {
        const int value = vampirePort.read();
        if (value < 0)
            break;
        buffer[count++] = static_cast<uint8_t>(value);
    }

    if (!count)
        return;

    if (rawMode)
    {
        SerialBT.write(buffer, count);
        return;
    }

    for (size_t i = 0; i < count; ++i)
    {
        const uint8_t c = buffer[i];
        if (!isTextByte(c) || textLineLength >= sizeof(textLineBuffer))
        {
            // Binary controller replies are still passed transparently, but no
            // special Bluetooth firmware-update state is retained.
            flushTextLine();
            rawMode = true;
            SerialBT.write(buffer + i, count - i);
            return;
        }

        textLineBuffer[textLineLength++] = c;
        if (c == '\n')
            flushTextLine();
    }
}

void BTBridge::writeFromVampire(uint8_t value)
{
    (void)value;
}
