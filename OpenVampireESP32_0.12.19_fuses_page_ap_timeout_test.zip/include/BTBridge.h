#pragma once

#include <Arduino.h>
#include <BluetoothSerial.h>

extern BluetoothSerial SerialBT;
extern HardwareSerial &vampirePort;

class BTBridge
{
public:
    void begin();
    void enable();
    void disable();
    void restart();
    void update();

    void setDeviceName(const String &name);
    const String &getDeviceName() const;

    bool enabled() const;
    bool isConnected() const;

    // Kept for compatibility with Vampire. UART bytes are read directly by
    // BTBridge while a Bluetooth client is connected.
    void writeFromVampire(uint8_t value);

private:
    bool active = false;
    bool connected = false;
    bool rawMode = false;
    String deviceName = "OpenVampire";
};

extern BTBridge btBridge;
