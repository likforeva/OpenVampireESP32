# OpenVampireESP32 0.12.35 — Statistics labels and About modal test

- Monthly chart values are always drawn above narrow bars using dark bold text.
- Yearly chart label behavior remains unchanged.
- The ESP version label in the header is clickable.
- Added a styled credits modal for Stonushie Relsy LTD.
- Credits: Developer (разработчик) — ChatGPT; Tester (тестировщик) — likforeva.
- The initial S is decorated with crossing rail-style lines using CSS only.
