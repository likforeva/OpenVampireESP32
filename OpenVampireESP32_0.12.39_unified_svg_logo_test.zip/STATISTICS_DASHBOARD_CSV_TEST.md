# 0.12.31 Statistics Dashboard & CSV Test

- Compact Today / Current month / All time summary table.
- Clickable chart legends with independent series selection.
- Current-day power, current-month daily totals and monthly archive line charts.
- Automatic refresh every 5 seconds; manual Refresh button removed.
- Added Reset statistics with confirmation.
- Excel-compatible CSV export: UTF-8 BOM, `sep=;`, semicolon columns and decimal comma.
