# 0.12.39 Unified SVG logo test

- The entire Stonushie wordmark is rendered inside one SVG.
- The S and tonushie text now share one fixed coordinate system and baseline.
- Mobile browsers can no longer shift or scale the S independently.
- Rail direction and sleeper layout are unchanged.
