# OpenVampireESP32 0.12.28 Home Assistant Discovery Test

- Based on 0.12.27 (no Bluetooth, MQTT INFO/STATE/LWT).
- Publishes retained Home Assistant MQTT Discovery config messages after each MQTT connection.
- Creates 12 sensor entities for PV, battery, load, and output telemetry.
- Uses the existing STATE topic for values and LWT topic for availability.
- No command/control entities are included in this test version.
- MQTT settings page remains compact.
