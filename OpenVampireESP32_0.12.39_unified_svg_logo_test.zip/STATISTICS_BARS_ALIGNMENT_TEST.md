# 0.12.34 Statistics Bars Alignment Test

- Monthly bars are centered exactly over their day labels.
- Yearly bars are centered exactly over month labels.
- Bar value labels are larger and bold.
- Small-bar labels are drawn above the bar; tall-bar labels are drawn inside.
- Current day and current month are highlighted with a darker shade.
- Added balanced edge spacing through categorical bar positioning.
