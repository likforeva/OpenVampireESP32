#pragma once

#include <Arduino.h>
#include <WiFiClient.h>
#include <PubSubClient.h>
#include <Preferences.h>
#include "Settings.h"

struct MqttConfig
{
    bool enabled = false;
    String host;
    uint16_t port = 1883;
    String user;
    String password;
    uint16_t periodSeconds = 10;
    String topic;  // Empty = automatic tele/VAMPIRE/SV-<serial>/STATE
};

class MqttManager
{
public:
    MqttManager();

    void begin();
    void update(const Telemetry &telemetry, const String &serialNumber, const String &vampireFirmware);
    void pause(bool paused);

    const MqttConfig &config() const { return cfg; }
    void save(const MqttConfig &newConfig);

    bool connected() { return client.connected(); }
    String stateText();
    String topicFor(const String &serialNumber) const;

    // Web diagnostics (do not require USB/Serial Monitor).
    int clientState() const { return lastClientState; }
    String clientStateText() const;
    String lastErrorText() const { return lastError; }
    uint32_t connectAttempts() const { return connectAttemptCount; }
    uint32_t reconnects() const { return reconnectCount; }
    uint32_t publishedCount() const { return publishCount; }
    uint32_t publishFailures() const { return publishFailureCount; }
    uint32_t lastPublishAgeSeconds() const;
    uint32_t lastConnectAgeSeconds() const;
    bool lastPublishResult() const { return lastPublishOk; }
    bool hasPublishResult() const { return hasLastPublishResult; }
    size_t lastPayloadLength() const { return lastPayloadSize; }
    const String &lastTopicUsed() const { return lastPublishedTopic; }
    const String &lastPayloadText() const { return lastPublishedPayload; }
    bool publishTest(const String &serialNumber);
    void forceReconnect();

private:
    WiFiClient wifiClient;
    PubSubClient client;
    Preferences prefs;
    MqttConfig cfg;

    bool isPaused = false;
    uint32_t lastConnectAttempt = 0;
    uint32_t lastPublish = 0;
    uint32_t lastSuccessfulPublish = 0;
    uint32_t lastSuccessfulConnect = 0;
    uint32_t connectAttemptCount = 0;
    uint32_t reconnectCount = 0;
    uint32_t publishCount = 0;
    uint32_t publishFailureCount = 0;
    int lastClientState = MQTT_DISCONNECTED;
    String lastError = "Not connected yet";
    String lastSerialNumber;
    bool lastPublishOk = false;
    bool hasLastPublishResult = false;
    size_t lastPayloadSize = 0;
    String lastPublishedTopic;
    String lastPublishedPayload;

    void load();
    bool connect(const String &serialNumber, const String &vampireFirmware);
    bool publishTelemetry(const Telemetry &t, const String &serialNumber);
    bool publishInfo(const String &serialNumber, const String &vampireFirmware);
    bool publishDiscovery(const String &serialNumber, const String &vampireFirmware);
    bool publishDiscoverySensor(const String &serialNumber, const String &vampireFirmware,
                                const char *key, const char *name, const char *unit,
                                const char *deviceClass, const char *icon);
    String derivedTopic(const String &serialNumber, const char *suffix) const;
    bool publishPayload(const String &topic, const uint8_t *payload, size_t length);
    void rememberClientState(const String &context);
};
