#pragma once

const char INDEX_HTML[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>OpenVampire ESP32</title>

<style>
/*====================================================
 OpenVampire ESP32
 style.css
 Version 0.5.0
====================================================*/

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Arial,Helvetica,sans-serif;
}

body{

    background:#e8e8e8;

    color:#222;

    font-size:16px;

}

.page{

    width:100%;

    max-width:700px;

    margin:auto;

    padding:12px;

}

/*====================================================
HEADER
====================================================*/

.header{

    display:flex;

    align-items:center;

    gap:12px;

    margin-bottom:15px;

}

.menuButton{

    width:48px;

    height:48px;

    font-size:28px;

    border:none;

    border-radius:8px;

    background:#1976d2;

    color:white;

    cursor:pointer;

}

.menuButton:hover{

    background:#1565c0;

}

.headerInfo{

    flex:1;

}

.line{

    display:flex;

    align-items:center;

    gap:8px;

    margin:3px 0;

    font-size:17px;

    font-weight:bold;

}

.sep{

    color:#888;

}

.wifiSignal{
    display:inline-flex;
    align-items:center;
    gap:6px;
    white-space:nowrap;
}

.wifiBars{
    display:inline-flex;
    align-items:flex-end;
    gap:2px;
    height:16px;
    padding:0 1px;
}

.wifiBar{
    display:block;
    width:5px;
    border-radius:2px 2px 0 0;
    background:#d7dbe0;
    transition:background-color .2s ease;
}

.wifiBar1{height:4px;}
.wifiBar2{height:8px;}
.wifiBar3{height:12px;}
.wifiBar4{height:16px;}

.wifiBar.active{
    background:#1976d2;
}

/*====================================================
MENU
====================================================*/

.menu{

    display:none;

    position:absolute;

    top:60px;

    left:12px;

    background:white;

    border-radius:10px;

    box-shadow:0 3px 10px rgba(0,0,0,.25);

    overflow:hidden;

    z-index:1000;

}

.menu button{

    display:block;

    width:230px;

    padding:14px;

    border:none;

    border-bottom:1px solid #ddd;

    background:white;

    text-align:left;

    cursor:pointer;

    font-size:16px;

}

.menu button:hover{

    background:#f0f0f0;

}

/*====================================================
CARD
====================================================*/

.card{

    background:white;

    border-radius:12px;

    padding:18px;

    margin-bottom:18px;

    box-shadow:0 2px 8px rgba(0,0,0,.12);

}

.card h2{

    text-align:center;

    margin-bottom:16px;

}

.card h3{

    text-align:center;

    margin-bottom:10px;

    font-size:16px;

    color:#444;

}
/*====================================================
DIMMER
====================================================*/



.dimmerControl{

    display:flex;

    align-items:center;

    gap:10px;

}

.dimmerControl button{

    width:42px;

    height:42px;

    font-size:24px;

    border:none;

    border-radius:8px;

    background:#1976d2;

    color:white;

    cursor:pointer;

}

.dimmerControl button:disabled{

    background:#bdbdbd;

    cursor:default;

}

#dimmerValue{

    width:70px;

    height:42px;

    text-align:center;

    font-size:20px;

    font-weight:bold;

    border:1px solid #bdbdbd;

    border-radius:8px;

    background:white;

    color:#222;

}



/*====================================================
SMOOTH CONTROL
====================================================*/

.radioLabel{

    display:block;

    margin-top:18px;

    margin-bottom:10px;

    font-size:17px;

    font-weight:bold;

}

.radioLabel input{

    width:20px;

    height:20px;

    margin-right:8px;

}

.modeTable{

    width:100%;

    border-collapse:separate;

    border-spacing:0 10px;

}

.modeTable td{

    padding:4px;

    vertical-align:middle;

}

.modeTable td:first-child{

    width:36%;

}

.modeTable td:nth-child(2){

    width:16%;

}

.modeTable td:nth-child(3){

    width:28%;

    text-align:right;

    padding-right:10px;

}

.modeTable td:nth-child(4){

    width:20%;

}

.modeTable input{

    width:100%;

    height:38px;

    text-align:center;

    font-size:16px;

    border:1px solid #bdbdbd;

    border-radius:8px;

}

/*====================================================
MAX REG VALUE
====================================================*/

.maxBlock{

    margin-top:22px;

    text-align:center;

}

.maxBlock label{

    display:block;

    font-weight:bold;

    margin-bottom:10px;

}

.maxBlock input{

    width:120px;

    height:42px;

    text-align:center;

    font-size:18px;

    border:1px solid #bdbdbd;

    border-radius:8px;

}

/*====================================================
APPLY
====================================================*/

.applyBlock{

    margin-top:25px;

    text-align:center;

}

.applyButton{

    width:220px;

    height:52px;

    font-size:20px;

    font-weight:bold;

    color:white;

    background:#2e7d32;

    border:none;

    border-radius:10px;

    cursor:pointer;

}

.applyButton:hover{

    background:#1b5e20;

}/*====================================================
REAL TIME MONITOR
====================================================*/

.monitorTable{

    width:100%;

    border-collapse:collapse;

    text-align:center;

}

.monitorTable th{

    padding:12px 8px;

    background:#1976d2;

    color:white;

    font-size:16px;

}

.monitorTable td{

    padding:12px 10px;

    border-bottom:1px solid #dcdcdc;

    font-size:17px;

}

.monitorTable td:first-child{

    font-weight:bold;

    width:32%;

}

.monitorTable td:nth-child(2){

    width:26%;
    font-weight:700;

}

.monitorTable td:nth-child(3){

    width:6%;

    text-align:center;

    font-size:22px;

    
}

.monitorTable td:nth-child(4){

    width:36%;

}

/*====================================================
FUSE STATUS
====================================================*/

.fuseNormal{

    color:#2e7d32;

    font-weight:bold;

}

.fuseTrip{

    color:#d50000;

    font-weight:bold;

}

/*====================================================
PROTOCOL
====================================================*/

.protocolTitle{

    margin-bottom:6px;

    font-size:14px;

    color:#666;

}

.protocolBlock{

    text-align:center;

}

.protocolBlock select{

    width:220px;

    height:42px;

    font-size:16px;

    border-radius:8px;

    border:1px solid #bdbdbd;

}

.inverterStatsRow{

    display:flex;

    align-items:center;

    justify-content:center;

    gap:18px;

}

.inverterStatsRow .protocolBlock{

    transform:translateX(-8px);

}

.statisticsButton{

    min-width:170px;

    height:42px;

    border:none;

    border-radius:8px;

    background:#1976d2;

    color:white;

    font-size:16px;

    font-weight:bold;

    cursor:pointer;

}

.statisticsButton:hover{

    background:#1565c0;

}

.protocolInfo{

    margin-top:6px;

    text-align:center;

    color:#777;

    font-size:12px;

}

/*====================================================
DIALOGS
====================================================*/

.dialog{

    display:none;

    position:fixed;

    inset:0;

    background:rgba(0,0,0,.35);

    justify-content:center;

    align-items:center;

    z-index:5000;

}

.dialogWindow{

    width:92%;

    max-width:420px;

    background:white;

    border-radius:12px;

    padding:20px;

}

.dialogWindow h2{

    margin-bottom:18px;

    text-align:center;

}

.dialogWindow input{

    width:100%;

    height:42px;

    margin-bottom:12px;

    padding:10px;

    border-radius:8px;

    border:1px solid #bdbdbd;

}

.dialogWindow textarea{

    width:100%;

    height:320px;

    resize:none;

    padding:10px;

    border-radius:8px;

    border:1px solid #bdbdbd;

    font-family:monospace;

}

.dialogButtons{

    display:flex;

    justify-content:space-between;

    gap:10px;

    margin-top:18px;

}

.dialogButtons button{

    flex:1;

    height:44px;

    border:none;

    border-radius:8px;

    color:white;

    background:#1976d2;

    cursor:pointer;

}

.dialogButtons button:disabled{

    opacity:.45;

    cursor:not-allowed;

    pointer-events:none;

}

#firmwareFile:disabled{

    opacity:.55;

    cursor:not-allowed;

}

/*====================================================
PHONE
====================================================*/

@media (max-width:600px){

.page{

    padding:8px;

}

.header{

    gap:8px;

}

.menuButton{

    width:44px;

    height:44px;

}

.line{

    font-size:15px;

}

.card{

    padding:14px;

}

.modeTable td{

    font-size:14px;

    padding:3px;

}

.modeTable input{

    height:34px;

    font-size:15px;

}

.monitorTable th{

    font-size:14px;

}

.monitorTable td{

    font-size:14px;

    padding:10px 4px;

}

.monitorTable td:nth-child(3){

    font-size:18px;

}

.applyButton{

    width:100%;

}

.protocolBlock select{

    width:100%;

}

.inverterStatsRow{

    gap:8px;

}

.inverterStatsRow .protocolBlock{

    flex:1;

    transform:none;

}

.statisticsButton{

    min-width:132px;

    padding:0 10px;

    font-size:14px;

}

}

#dimmerMinus,
#dimmerPlus{

    opacity:0.35;

    pointer-events:none;

    transition:0.2s;

}

#dimmerMinus.active,
#dimmerPlus.active{

    opacity:1;

    pointer-events:auto;

}


/*====================================================
FUSE ENABLE / DISABLE
====================================================*/

.fuseEnabled
{
    color:#000000;
    font-weight:bold;
}

.fuseDisabled
{
    color:#909090;
    font-weight:normal;
}

/*====================================================
COMPARE SYMBOL
====================================================*/

.fuseEnabled{
    color:#000;
    font-weight:bold;
}

.fuseDisabled{
    color:#909090;
    font-weight:normal;
}

.compareEnabled{
    color:#000;
    font-weight:bold;
}

.compareDisabled{
    color:#909090;
    font-weight:normal;
}

.dimmerRow
{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin:10px 0 20px 0;
}

.dimmerControl
{
    display:flex;
    align-items:center;
    gap:6px;
}

.statusCard
{
    margin-top:12px;
    padding:10px;

    border:1px solid #444;
    border-radius:8px;

    background:#222;

    text-align:center;
}

.statusTitle
{
    font-size:14px;
    color:#bbb;

    margin-bottom:6px;
}

.statusOk
{
    color:#00ff66;
    font-weight:bold;
}

.statusBusy
{
    color:#ffcc00;
    font-weight:bold;
}
.ramStatus{cursor:pointer;text-decoration:underline;text-decoration-style:dotted;text-underline-offset:3px}.systemInfoModal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.48);z-index:10000;align-items:center;justify-content:center;padding:16px}.systemInfoModal.open{display:flex}.systemInfoCard{width:min(520px,96vw);background:#fff;color:#222;border-radius:12px;box-shadow:0 12px 40px rgba(0,0,0,.35);overflow:hidden}.systemInfoHead{display:flex;justify-content:space-between;align-items:center;padding:14px 16px;background:#263238;color:#fff;font-size:18px}.systemInfoHead button{border:0;background:transparent;color:#fff;font-size:28px;cursor:pointer;line-height:1}.systemInfoTable{width:100%;border-collapse:collapse}.systemInfoTable td{padding:10px 14px;border-bottom:1px solid #ddd}.systemInfoTable td:last-child{text-align:right;font-weight:700}

.espCreditsLink{cursor:default;text-decoration:none;color:inherit;font-weight:inherit}.creditsModal{display:none;position:fixed;inset:0;background:rgba(4,18,32,.62);z-index:10020;align-items:center;justify-content:center;padding:16px}.creditsModal.open{display:flex}.creditsCard{position:relative;width:min(620px,96vw);background:linear-gradient(145deg,#fff,#f4f8fc);color:#102a43;border:1px solid #86b6e2;border-radius:20px;box-shadow:0 18px 55px rgba(0,0,0,.42);padding:28px 30px 24px;text-align:center;overflow:hidden}.creditsCloseX{position:absolute;right:16px;top:12px;border:1px solid #9ab6d0;background:#fff;color:#173a5e;border-radius:50%;width:38px;height:38px;font-size:26px;line-height:32px;cursor:pointer}.creditsBrand{margin:10px auto 2px;display:flex;align-items:center;justify-content:center;color:#082d57}.creditsWordmark{display:block;width:min(520px,92%);height:auto;overflow:visible}.creditsWordmark .logoText{font-family:Georgia,'Times New Roman',serif;font-weight:700;fill:#082d57;stroke:#041d38;stroke-width:.45;paint-order:stroke fill}.creditsWordmark .logoS{font-size:104px;font-style:italic}.creditsWordmark .logoRest{font-size:70px;font-weight:400}.creditsWordmark .railBase{fill:none;stroke:#3f474f;stroke-width:8;stroke-linecap:round}.creditsWordmark .rail{fill:none;stroke:#aeb6bd;stroke-width:5;stroke-linecap:round}.creditsWordmark .railHi{fill:none;stroke:#f4f6f8;stroke-width:1.3;stroke-linecap:round}.creditsWordmark .tie{stroke:#745329;stroke-width:5.6;stroke-linecap:round}.creditsLtd{display:flex;align-items:center;justify-content:center;gap:14px;margin:4px 0 22px;color:#a77b34;font:700 34px Georgia,'Times New Roman',serif;letter-spacing:5px}.creditsLtd:before,.creditsLtd:after{content:'';height:1px;width:75px;background:#b99556}.creditsRule{height:1px;background:linear-gradient(90deg,transparent,#9bbbd8,transparent);margin:0 0 20px}.creditRow{display:grid;grid-template-columns:54px 1fr auto;gap:12px;align-items:center;text-align:left;padding:13px 20px;border-bottom:1px solid #d7e3ed;font-size:20px}.creditIcon{width:42px;height:42px;border:2px solid #1c4d80;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:900;color:#1c4d80}.creditRole{font-weight:800}.creditName{font-weight:800;color:#0d467c}.tester .creditIcon,.tester .creditName{color:#17713b;border-color:#17713b}.creditsButton{margin-top:22px;min-width:150px;background:#0d3f75;color:#fff;border:0;border-radius:9px;padding:11px 28px;font-size:18px;font-weight:700;cursor:pointer}@media(max-width:600px){.creditsCard{padding:22px 14px 18px}.creditsBrand{margin-top:18px}.creditsWordmark{width:min(470px,96%)}.creditsLtd{font-size:23px;letter-spacing:3px;margin:0 0 16px}.creditsRule{margin-bottom:10px}.creditRow{grid-template-columns:42px 92px 1fr;gap:9px;padding:12px 4px;font-size:16px;white-space:nowrap}.creditName{grid-column:auto;text-align:left}.creditsLtd:before,.creditsLtd:after{width:30px}.creditsButton{margin-top:16px;width:min(240px,75%)}}

</style>


</head>

<body>

<div class="page">

<!--==================================================
HEADER
===================================================-->
<div class="header">

    <button
        id="menuButton"
        class="menuButton"
        onclick="toggleMenu()">

        ☰

    </button>

    <div class="headerInfo">

        <div class="line">

            <span id="sn">SV--------</span>

            <span class="sep">|</span>

            <span id="wifiSignal" class="wifiSignal">
                <span>WiFi</span>
                <span id="wifiBars" class="wifiBars" aria-label="WiFi signal">
                    <span class="wifiBar wifiBar1"></span>
                    <span class="wifiBar wifiBar2"></span>
                    <span class="wifiBar wifiBar3"></span>
                    <span class="wifiBar wifiBar4"></span>
                </span>
                <span id="wifiRssi">---</span>
            </span>

            <span class="sep">|</span>

            <span id="ramStatus" class="ramStatus" onclick="openSystemInfo()" title="System memory details">RAM ---K</span>

            <span class="sep">|</span>

            <span id="uptime">Up 0m</span>

        </div>

        <div class="line">

            <span id="fw">FW---</span>

            <span class="sep">|</span>

            <span id="esp" class="espCreditsLink" onclick="openCredits()">ESP 0.5.0</span>

            <span class="sep">|</span>

            <span id="ip">IP 0.0.0.0</span>

        </div>

    </div>

</div>
<!--==================================================
MENU
===================================================-->

<div
    id="menu"
    class="menu">

    <button onclick="location.href='fuses.html'">

        Fuse Settings

    </button>

    <button onclick="showWifi()">

        WiFi Settings

    </button>

    <button onclick="location.href='/mqtt'">

        MQTT Settings

    </button>

    <button onclick="location.href='/vampire-update'">

        Vampire Firmware Update

    </button>

    <button onclick="showFirmware()">

        ESP32 Firmware Update

    </button>

    <button onclick="showDebug()">

        Debug Log

    </button>

    <button onclick="restartESP()">

        Restart ESP32

    </button>

</div><!--==================================================
SMOOTH CONTROL SETTING
===================================================-->

<div class="card">

<h2>Smooth Control Setting</h2>

<!--==================== DIMMER ====================-->

<div class="dimmerRow">

    <label class="radioLabel">

        <input
        type="radio"
        name="mode"
        id="mode3">

        Dimmer

    </label>

    <div class="dimmerControl">

        <button
        id="dimmerMinus"
        onclick="dimmerMinus()">

        −

        </button>

        <input
        id="dimmerValue"
        type="number"
        min="0"
        max="100"
        value="0">

        <button
        id="dimmerPlus"
        onclick="dimmerPlus()">

        +

        </button>

    </div>

</div>
<!--==================== MODE 1 ====================-->

<label class="radioLabel">

<input
type="radio"
name="mode"
id="mode1"
checked>

Regulator Mode1 (Fix PV Voltage)

</label>

<table class="modeTable">

<tr>

<td>PV1 target</td>

<td>

<input
id="p0"
type="number">

</td>

<td>Reg.Coeff.</td>

<td>

<input
id="p1"
type="number">

</td>

</tr>

<tr>


<td>PV2 target</td>

<td>

<input
id="p12"
type="number">

</td>

<td>Reg.Coeff.</td>

<td>

<input
id="p13"
type="number">

</td>

</tr>

</table>

<!--==================== MODE 2 ====================-->

<label class="radioLabel">

<input
type="radio"
name="mode"
id="mode2">

Regulator Mode2 (MPPT)

</label>

<table class="modeTable">

<tr>

<td>Bat.disch.cur.</td>

<td>

<input
id="p4"
type="number">

</td>

<td>Reg.Coeff.</td>

<td>

<input
id="p2"
type="number">

</td>

</tr>

<tr>

<td>Grid power</td>

<td>

<input
id="p15"
type="number">

</td>

<td>Reg.Coeff.</td>

<td>

<input
id="p14"
type="number">

</td>

</tr>

</table>

<div class="maxBlock">

<label>

MAX.reg.value %

</label>

<input
id="p3"
type="number">

</div>

<div class="applyBlock">

<button
class="applyButton"
onclick="applySettings()">

Apply

</button>

</div>
<!--==================================================
REAL TIME MONITOR
===================================================-->

<div class="card">

<h2>Real-Time Monitor</h2>

<table class="monitorTable">

<thead>

<tr>

<th>Parameter</th>

<th>Real</th>

<th></th>

<th>Fuse</th>

</tr>

</thead>

<tbody>

<tr>

<td>PV1 Voltage</td>

<td id="rt_pv1">0 V</td>

<td></td>

<td id="f_pv1">—</td>

</tr>

<tr>

<td>PV1 Current / Power</td>

<td id="rt_pc1">0 W</td>

<td></td>

<td id="f_pc1">—</td>

</tr>

<tr>

<td>PV2 Voltage</td>

<td id="rt_pv2">0 V</td>

<td></td>

<td id="f_pv2">—</td>

</tr>

<tr>

<td>PV2 Current / Power</td>

<td id="rt_pc2">0 W</td>

<td></td>

<td id="f_pc2">—</td>

</tr>

<tr>

<td>Bat voltage</td>

<td id="rt_bat">0 V</td>

<td id="cmp_bat">&lt;</td>

<td id="f_bat">0</td>

</tr>

<tr>

<td>Bat. SOC</td>

<td id="rt_soc">0 %</td>

<td id="cmp_soc">&lt;</td>

<td id="f_soc">0</td>

</tr>

<tr>

<td>Bat. charge cur.</td>

<td id="rt_chr">0 A</td>

<td id="cmp_chr">&gt;</td>

<td id="f_chr">0</td>

</tr>

<tr>

<td>Bat. discharge cur.</td>

<td id="rt_dsc">0 A</td>

<td id="cmp_dsc">&gt;</td>

<td id="f_dsc">0</td>

</tr>

<tr>

<td>Inverter Load</td>

<td id="rt_load">0 W</td>

<td id="cmp_load">&gt;</td>

<td id="f_load">0</td>

</tr>

<tr>

<td>Grid Power</td>

<td id="rt_grid">0 W</td>

<td id="cmp_grid">&gt;</td>

<td id="f_grid">0</td>

</tr>

<tr>

<td>Regulator Output</td>

<td id="rt_out">0 %</td>

<td></td>

<td>—</td>

</tr>

</tbody>

</table>

</div>

<!--==================================================
INVERTER TYPE
===================================================-->

<div class="card">

<h3 class="protocolTitle">

Inverter Type

</h3>

<div class="inverterStatsRow">

<div class="protocolBlock">

<select id="p16">

<option value="0">Voltronic & Clones 1PV</option>

<option value="1">Anenji 4/6kW 1PV</option>

<option value="2">PowMr Modbus 1PV</option>

<option value="3">SRNE 1PV</option>

<option value="4">Anenji 11kW 2PV</option>

<option value="5">Must 1PV</option>

<option value="6">PowMr 10.2kW 2PV</option>

<option value="7">Lux Power 2PV</option>

<option value="8">Growatt 2PV</option>

<option value="9">Deye 1ph 2PV</option>

<option value="10">Deye 3ph 2PV</option>

<option value="11">JSD Solar 1PV</option>

<option value="12">Voltronic & Clones 2PV</option>

</select>

</div>

<button class="statisticsButton" onclick="location.href='/statistics'">Energy Statistics</button>

</div>

</div>
<!--==================================================
WIFI DIALOG
===================================================-->

<div
id="wifiDialog"
class="dialog">

<div class="dialogWindow">

<h2>WiFi Settings</h2>

<input
id="wifiSSID"
type="text"
placeholder="SSID">

<input
id="wifiPASS"
type="password"
placeholder="Password">

<div class="dialogButtons">

<button
onclick="saveWifi()">

Save

</button>

<button
onclick="closeWifi()">

Close

</button>

</div>

</div>

</div>

<!--==================================================
FIRMWARE UPDATE
===================================================-->

<div
id="firmwareDialog"
class="dialog">

<div class="dialogWindow">

<h2>Firmware Update</h2>

<p>Select firmware.bin</p>

<input
id="firmwareFile"
type="file"
accept=".bin,application/octet-stream"
onchange="firmwareFileChanged()">

<div id="firmwareProgressWrap" style="display:none;margin-top:16px;">
  <div style="height:22px;background:#111;border-radius:11px;overflow:hidden;">
    <div id="firmwareProgressBar" style="height:100%;width:0;background:#43a047;transition:width .15s;"></div>
  </div>
  <div id="firmwareProgressText" style="margin-top:8px;text-align:center;">0%</div>
</div>

<div id="firmwareResult" style="display:none;margin-top:16px;padding:12px;border-radius:8px;"></div>

<div class="dialogButtons">

<button id="firmwareUploadButton" onclick="uploadFirmware()" disabled>
Upload
</button>

<button id="firmwareCloseButton" onclick="closeFirmware()">
Close
</button>

<button id="firmwareOkButton" onclick="finishFirmwareUpdate()" style="display:none;">
OK
</button>

</div>

</div>

</div>

<!--==================================================
DEBUG
===================================================-->

<div
id="debugDialog"
class="dialog">

<div class="dialogWindow">

<h2>Debug Log</h2>

<textarea
id="debugText"
readonly>

</textarea>

<div class="dialogButtons">

<button
onclick="startDebug()">

Start

</button>

<button
onclick="stopDebug()">

Stop

</button>

<button
onclick="clearDebug()">

Clear

</button>

<button
onclick="closeDebug()">

Close

</button>

</div>

</div>

</div>

</div>

<div id="systemInfoModal" class="systemInfoModal" onclick="closeSystemInfo(event)">
  <div class="systemInfoCard">
    <div class="systemInfoHead"><b>System information</b><button onclick="closeSystemInfo()">×</button></div>
    <table class="systemInfoTable">
      <tr><td>RAM used</td><td id="sysRamUsed">---</td></tr>
      <tr><td>RAM free</td><td id="sysRamFree">---</td></tr>
      <tr><td>Minimum free RAM</td><td id="sysRamMin">---</td></tr>
      <tr><td>Largest free block</td><td id="sysRamLargest">---</td></tr>
      <tr><td>Firmware flash used</td><td id="sysFlashUsed">---</td></tr>
      <tr><td>OTA/free sketch space</td><td id="sysFlashFree">---</td></tr>
      <tr><td>WiFi signal</td><td id="sysWifi">---</td></tr>
      <tr><td>Uptime</td><td id="sysUptime">---</td></tr>
      <tr><td>ESP firmware</td><td id="sysEsp">---</td></tr>
      <tr><td>Vampire firmware</td><td id="sysFw">---</td></tr>
    </table>
  </div>
</div>

<div id="creditsModal" class="creditsModal" onclick="closeCredits(event)">
  <div class="creditsCard" role="dialog" aria-modal="true" aria-labelledby="creditsTitle">
    <button class="creditsCloseX" onclick="closeCredits()" aria-label="Close">×</button>
    <div id="creditsTitle" class="creditsBrand">
      <svg class="creditsWordmark" viewBox="0 0 520 130" role="img" aria-label="Stonushie">
        <text class="logoText logoS" x="20" y="103">S</text>
        <text class="logoText logoRest" x="104" y="99">tonushie</text>
        <g aria-hidden="true">
          <line class="tie" x1="23" y1="91" x2="38" y2="110"/>
          <line class="tie" x1="34" y1="83" x2="49" y2="102"/>
          <line class="tie" x1="45" y1="75" x2="60" y2="94"/>
          <line class="tie" x1="56" y1="67" x2="71" y2="86"/>
          <line class="tie" x1="67" y1="59" x2="82" y2="78"/>
          <line class="tie" x1="78" y1="51" x2="93" y2="70"/>
          <line class="tie" x1="89" y1="43" x2="104" y2="62"/>
          <line class="tie" x1="100" y1="35" x2="115" y2="54"/>
          <path class="railBase" d="M20 97 L108 33"/>
          <path class="rail" d="M20 97 L108 33"/>
          <path class="railHi" d="M20 97 L108 33"/>
          <path class="railBase" d="M27 107 L115 43"/>
          <path class="rail" d="M27 107 L115 43"/>
          <path class="railHi" d="M27 107 L115 43"/>
        </g>
      </svg>
    </div>
    <div class="creditsLtd">Relsy LTD</div>
    <div class="creditsRule"></div>
    <div class="creditRow"><span class="creditIcon">&lt;/&gt;</span><span class="creditRole">Developer</span><span class="creditName">ChatGPT</span></div>
    <div class="creditRow tester"><span class="creditIcon">✓</span><span class="creditRole">Tester</span><span class="creditName">likforeva</span></div>
    <button class="creditsButton" onclick="closeCredits()">Close</button>
  </div>
</div>

<script>
//====================================================
// OpenVampire ESP32
// app.js
// Version 0.5.0
//====================================================

//----------------------------------------------------
// GLOBAL
//----------------------------------------------------

let realtimeData = {};
let debugTimer = null;
let firmwareUploadActive = false;
 // Глобальное хранилище данных realtime

const UI =
{
    menu: document.getElementById("menu"),

    inverterType: document.getElementById("p16"),

    dimmerValue: document.getElementById("dimmerValue"),

    wifiDialog: document.getElementById("wifiDialog"),

    firmwareDialog: document.getElementById("firmwareDialog"),

    debugDialog: document.getElementById("debugDialog"),

    debugText: document.getElementById("debugText")
};

//----------------------------------------------------
// Auto Apply Protocol
//----------------------------------------------------

window.addEventListener("load", function()
{
    UI.inverterType.onchange = async function()
{
    try
    {
        await fetch("/api/protocol",
        {
            method:"POST",

            headers:
            {
                "Content-Type":"application/json"
            },

            body:JSON.stringify(
            {
                protocol:Number(UI.inverterType.value)
            })
        });

        log("Protocol applied");
    }
    catch(e)
    {
        log("Protocol apply error");
    }
};
});

//----------------------------------------------------
// MENU
//----------------------------------------------------

function toggleMenu()
{
    UI.menu.style.display =
        UI.menu.style.display === "block"
        ? "none"
        : "block";
}

document.addEventListener("click", function(e)
{
    const button =
        document.getElementById("menuButton");

    if(
        button &&
        !UI.menu.contains(e.target) &&
        !button.contains(e.target)
    )
    {
        UI.menu.style.display = "none";
    }
});

//----------------------------------------------------
// DIALOGS
//----------------------------------------------------

function showWifi()
{
    UI.menu.style.display = "none";
    UI.wifiDialog.style.display = "flex";
}

function closeWifi()
{
    UI.wifiDialog.style.display = "none";
}

function showFirmware()
{
    UI.menu.style.display = "none";
    UI.firmwareDialog.style.display = "flex";
}

function closeFirmware()
{
    if(firmwareUploadActive)
        return;

    UI.firmwareDialog.style.display = "none";
}

async function showDebug()
{
    UI.menu.style.display = "none";
    UI.debugDialog.style.display = "flex";

    startDebug();
}

function closeDebug()
{
    stopDebug();

    UI.debugDialog.style.display = "none";
}

//----------------------------------------------------
// Bluetooth Bridge
//----------------------------------------------------

let bridgeEnabled = false;

async function toggleBridge()
{
    bridgeEnabled = !bridgeEnabled;

    try
    {
        await fetch("/api/bridge",
        {
            method: "POST",

            headers:
            {
                "Content-Type":"application/json"
            },

            body: JSON.stringify(
            {
                enable: bridgeEnabled
            })
        });

       const btn = document.getElementById("bridgeButton");

if(bridgeEnabled)
{
    btn.innerText = "Bluetooth Bridge ON";
    btn.style.background = "#00aa00";
    btn.style.color = "#ffffff";
}
else
{
    btn.innerText = "Bluetooth Bridge OFF";
    btn.style.background = "";
    btn.style.color = "";
}

log(
    bridgeEnabled ?
    "Bluetooth Bridge ON" :
    "Bluetooth Bridge OFF"
);
    }
    catch(e)
    {
        log("Bridge error");
    }
}
//----------------------------------------------------
// DEBUG UPDATE
//----------------------------------------------------

async function updateDebug()
{
    try
    {
        const r = await fetch("/debug");

        UI.debugText.value = await r.text();

        UI.debugText.scrollTop =
            UI.debugText.scrollHeight;
    }
    catch(e)
    {
        UI.debugText.value = "Debug read error";
    }
}

function startDebug()
{
    stopDebug();

    updateDebug();

    debugTimer = setInterval(updateDebug,1000);
}

function stopDebug()
{
    

    if(debugTimer !== null)
    {
        clearInterval(debugTimer);
        debugTimer = null;
    }

    console.log("Debug paused");
}
function clearDebug()
{
    UI.debugText.value = "";
}

function log(text)
{
    console.log(text);
}

//----------------------------------------------------
// STATUS
//----------------------------------------------------

function formatUptime(totalSeconds)
{
    totalSeconds = Math.max(0, Number(totalSeconds) || 0);

    const days = Math.floor(totalSeconds / 86400);
    const hours = Math.floor((totalSeconds % 86400) / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = Math.floor(totalSeconds % 60);

    if(days > 0)
        return days + "d " + String(hours).padStart(2, "0") + "h " + String(minutes).padStart(2, "0") + "m";

    if(hours > 0)
        return hours + "h " + String(minutes).padStart(2, "0") + "m " + String(seconds).padStart(2, "0") + "s";

    return minutes + "m " + String(seconds).padStart(2, "0") + "s";
}

function updateWifiIndicator(connected, rssi)
{
    const bars = Array.from(document.querySelectorAll("#wifiBars .wifiBar"));
    const rssiElement = document.getElementById("wifiRssi");

    let activeBars = 0;

    if(connected && Number.isFinite(Number(rssi)))
    {
        rssi = Number(rssi);

        if(rssi >= -55) activeBars = 4;
        else if(rssi >= -67) activeBars = 3;
        else if(rssi >= -80) activeBars = 2;
        else if(rssi >= -90) activeBars = 1;

        rssiElement.innerText = rssi + " dBm";
    }
    else
    {
        rssiElement.innerText = "AP";
    }

    bars.forEach((bar, index) =>
        bar.classList.toggle("active", index < activeBars));
}

let lastSystemStatus=null;
function formatBytes(v){v=Number(v)||0;return v>=1048576?(v/1048576).toFixed(2)+" MB":Math.round(v/1024)+" KB"}
function fillSystemInfo(j){lastSystemStatus=j;const set=(id,v)=>{const e=document.getElementById(id);if(e)e.innerText=v};set("sysRamUsed",formatBytes(j.ram_used)+" / "+formatBytes(j.ram_total));set("sysRamFree",formatBytes(j.ram_free));set("sysRamMin",formatBytes(j.ram_min_free));set("sysRamLargest",formatBytes(j.ram_largest));set("sysFlashUsed",formatBytes(j.flash_used));set("sysFlashFree",formatBytes(j.flash_free));set("sysWifi",j.connected&&Number.isFinite(Number(j.rssi))?j.rssi+" dBm":"AP / disconnected");set("sysUptime",formatUptime(j.uptime));set("sysEsp",j.esp||"---");set("sysFw",j.fw||"---")}
function openSystemInfo(){if(lastSystemStatus)fillSystemInfo(lastSystemStatus);document.getElementById("systemInfoModal").classList.add("open")}
function closeSystemInfo(e){if(e&&e.target!==document.getElementById("systemInfoModal"))return;document.getElementById("systemInfoModal").classList.remove("open")}
function openCredits(){document.getElementById("creditsModal").classList.add("open")}
function closeCredits(e){if(e&&e.target!==document.getElementById("creditsModal"))return;document.getElementById("creditsModal").classList.remove("open")}

async function loadStatus()
{
    try
    {
        const r = await fetch("/api/status?t=" + Date.now(), { cache: "no-store" });

        const j = await r.json();

        document.getElementById("sn").innerText =
            j.serial || "SV --------";

        document.getElementById("fw").innerText =
            "FW " + (j.fw || "---");

        document.getElementById("esp").innerText =
    "ESP " + (j.esp || "---");

        document.getElementById("ip").innerText =
            "IP " + (j.ip || "---");

        updateWifiIndicator(j.connected, j.rssi);

        document.getElementById("uptime").innerText =
            "Up " + formatUptime(j.uptime);

        document.getElementById("ramStatus").innerText =
            "RAM " + Math.round((Number(j.ram_free)||0) / 1024) + "K";
        fillSystemInfo(j);
    }
    catch(e)
    {
        log("Status error");
    }
}

//----------------------------------------------------
// SETTINGS
//----------------------------------------------------

async function loadSettings()
{
    try
    {
        const r = await fetch("/api/settings?t=" + Date.now(), { cache: "no-store" });

        const j = await r.json();

        //------------------------------------------
        // Parameters
        //------------------------------------------

        for(let i=0;i<18;i++)
        {
            const obj =
                document.getElementById("p"+i);

            if(obj)
                obj.value = j["p"+i] ?? 0;
        }

        

       //------------------------------------------
       // Dimmer
       //------------------------------------------

         UI.dimmerValue.value = j.p10 ?? 0;

        //------------------------------------------
        // Active mode
        //------------------------------------------

        document.getElementById("mode1").checked = false;
        document.getElementById("mode2").checked = false;
        document.getElementById("mode3").checked = false;

        switch(Number(j.mode))
{
    case 2:     // Vampire = Fix Voltage
        document.getElementById("mode1").checked = true;
        break;

    case 3:     // Vampire = Dimmer
        document.getElementById("mode3").checked = true;
        break;

    case 4:     // Vampire = MPPT
        document.getElementById("mode2").checked = true;
        break;

    default:
        document.getElementById("mode1").checked = true;
        break;
}

        updateModeSelection();
    }
    catch(e)
    {
        log("Settings error");
    }
}

//----------------------------------------------------
// REALTIME
//----------------------------------------------------

async function loadRealtime()
{
    try
    {
        const r = await fetch("/api/trans?t=" + Date.now(), { cache: "no-store" });

        const j = await r.json();

        // Сохраняем полученные данные в глобальную переменную
        realtimeData = j;

               document.getElementById("rt_pv1").innerText =
            j.pv1_voltage + " V";

        const pv1Current = Number(j.pv1_current) / 10.0;
        const pv1Power = pv1Current * Number(j.pv1_voltage);
        document.getElementById("rt_pc1").innerText =
            pv1Current.toFixed(1) + " A (" + Math.round(pv1Power) + " W)";

        document.getElementById("rt_pv2").innerText =
            j.pv2_voltage + " V";

        const pv2Current = Number(j.pv2_current) / 10.0;
        const pv2Power = pv2Current * Number(j.pv2_voltage);
        document.getElementById("rt_pc2").innerText =
            pv2Current.toFixed(1) + " A (" + Math.round(pv2Power) + " W)";

        const batteryVoltage = Number(j.battery_voltage) / 10.0;
        document.getElementById("rt_bat").innerText =
            batteryVoltage.toFixed(1) + " V";

        document.getElementById("rt_soc").innerText =
            j.battery_soc + " %";

        const chargeCurrent = Number(j.charge_current);
        const chargePower = chargeCurrent * batteryVoltage;
        document.getElementById("rt_chr").innerText =
            chargeCurrent.toFixed(0) + " A (" + Math.round(chargePower) + " W)";

        const dischargeCurrent = Number(j.discharge_current);
        const dischargePower = dischargeCurrent * batteryVoltage;
        document.getElementById("rt_dsc").innerText =
            dischargeCurrent.toFixed(0) + " A (" + Math.round(dischargePower) + " W)";

        document.getElementById("rt_load").innerText =
            j.inverter_load + " W";

        document.getElementById("rt_grid").innerText =
            j.grid_power + " W";

        document.getElementById("rt_out").innerText =
            j.regulator_out + " %";
    }

    catch(e)
    {
        log("Realtime error");
    }
}

//----------------------------------------------------
// FUSES
//----------------------------------------------------

async function loadFuses()
{
    

    try
    {
        const r = await fetch("/api/fuses?t=" + Date.now(), { cache: "no-store" });
        const j = await r.json();

        // Для PV и PC предохранителей нет
        document.getElementById("f_pv1").innerText = "";
        document.getElementById("f_pc1").innerText = "";
        document.getElementById("f_pv2").innerText = "";
        document.getElementById("f_pc2").innerText = "";

        //--------------------------------------------------
        // Battery Voltage
        //--------------------------------------------------

        const bat = document.getElementById("f_bat");
        const cmpBat = document.getElementById("cmp_bat");

        bat.innerText = j.batVolt;

        bat.className = j.batVoltEnable ? "fuseEnabled" : "fuseDisabled";
        cmpBat.className = j.batVoltEnable ? "compareEnabled" : "compareDisabled";

        //--------------------------------------------------
        // Battery SOC
        //--------------------------------------------------

        const soc = document.getElementById("f_soc");
        const cmpSoc = document.getElementById("cmp_soc");

        soc.innerText = j.batSoc;

        soc.className = j.batSocEnable ? "fuseEnabled" : "fuseDisabled";
        cmpSoc.className = j.batSocEnable ? "compareEnabled" : "compareDisabled";

        //--------------------------------------------------
        // Charge Current
        //--------------------------------------------------

        const chr = document.getElementById("f_chr");
        const cmpChr = document.getElementById("cmp_chr");

        chr.innerText = j.chargeCurrent;

        chr.className = j.chargeEnable ? "fuseEnabled" : "fuseDisabled";
        cmpChr.className = j.chargeEnable ? "compareEnabled" : "compareDisabled";

        //--------------------------------------------------
        // Discharge Current
        //--------------------------------------------------

        const dsc = document.getElementById("f_dsc");
        const cmpDsc = document.getElementById("cmp_dsc");

        dsc.innerText = j.dischargeCurrent;

        dsc.className = j.dischargeEnable ? "fuseEnabled" : "fuseDisabled";
        cmpDsc.className = j.dischargeEnable ? "compareEnabled" : "compareDisabled";

        //--------------------------------------------------
        // Load
        //--------------------------------------------------

        const load = document.getElementById("f_load");
        const cmpLoad = document.getElementById("cmp_load");

        load.innerText = j.loadLimit;

        load.className = j.loadEnable ? "fuseEnabled" : "fuseDisabled";
        cmpLoad.className = j.loadEnable ? "compareEnabled" : "compareDisabled";

        //--------------------------------------------------
        // Grid
        //--------------------------------------------------

        const grid = document.getElementById("f_grid");
        const cmpGrid = document.getElementById("cmp_grid");

        grid.innerText = j.gridLimit;

        grid.className = j.gridEnable ? "fuseEnabled" : "fuseDisabled";
        cmpGrid.className = j.gridEnable ? "compareEnabled" : "compareDisabled";

        //--------------------------------------------------
        // ALARM INDICATION
        //--------------------------------------------------

        // When a fuse trips, highlight all three relevant cells:
        // the real value, the comparison symbol and the configured limit.
        function applyFuseState(realId, compareEl, limitEl, enabled, tripped)
        {
            const realEl = document.getElementById(realId);

            realEl.style.color = tripped ? "#d50000" : "";
            realEl.style.fontWeight = tripped ? "700" : "";

            if (!enabled)
            {
                compareEl.className = "compareDisabled";
                limitEl.className = "fuseDisabled";
            }
            else if (tripped)
            {
                compareEl.className = "fuseTrip";
                limitEl.className = "fuseTrip";
            }
            else
            {
                compareEl.className = "compareEnabled";
                limitEl.className = "fuseEnabled";
            }
        }

        // /api/trans uses snake_case field names. Battery voltage is
        // transferred in tenths of a volt, so compare the same engineering
        // value that is shown in the Real column.
        const realBatteryVoltage = Number(realtimeData.battery_voltage) / 10.0;
        const realBatterySOC = Number(realtimeData.battery_soc);
        const realChargeCurrent = Number(realtimeData.charge_current);
        const realDischargeCurrent = Number(realtimeData.discharge_current);
        const realInverterLoad = Number(realtimeData.inverter_load);
        const realGridPower = Number(realtimeData.grid_power);

        const batTrip = j.batVoltEnable &&
            realBatteryVoltage < Number(j.batVolt);

        const socTrip = j.batSocEnable &&
            realBatterySOC < Number(j.batSoc);

        const chargeTrip = j.chargeEnable &&
            realChargeCurrent > Number(j.chargeCurrent);

        const dischargeTrip = j.dischargeEnable &&
            realDischargeCurrent > Number(j.dischargeCurrent);

        const loadTrip = j.loadEnable &&
            realInverterLoad > Number(j.loadLimit);

        const gridTrip = j.gridEnable &&
            realGridPower > Number(j.gridLimit);

        applyFuseState("rt_bat", cmpBat, bat, j.batVoltEnable, batTrip);
        applyFuseState("rt_soc", cmpSoc, soc, j.batSocEnable, socTrip);
        applyFuseState("rt_chr", cmpChr, chr, j.chargeEnable, chargeTrip);
        applyFuseState("rt_dsc", cmpDsc, dsc, j.dischargeEnable, dischargeTrip);
        applyFuseState("rt_load", cmpLoad, load, j.loadEnable, loadTrip);
        applyFuseState("rt_grid", cmpGrid, grid, j.gridEnable, gridTrip);
    }
    catch(e)
    {
        log("Fuse load error");
    }
}

//----------------------------------------------------
// MODE SELECTION
//----------------------------------------------------

function updateModeSelection()
{
    const mode1 =
        document.getElementById("mode1");

    const mode2 =
        document.getElementById("mode2");

    const mode3 =
        document.getElementById("mode3");

    const plus =
        document.getElementById("dimmerPlus");

    const minus =
        document.getElementById("dimmerMinus");

    //------------------------------------------
    // Dimmer
    //------------------------------------------

    UI.dimmerValue.disabled = !mode3.checked;

    plus.disabled = !mode3.checked;
    minus.disabled = !mode3.checked;

    UI.dimmerValue.classList.toggle(
        "active",
        mode3.checked
    );

    plus.classList.toggle(
        "active",
        mode3.checked
    );

    minus.classList.toggle(
        "active",
        mode3.checked
    );

    //------------------------------------------
    // Mode1 parameters
    //------------------------------------------

    ["p0", "p1", "p12", "p13"].forEach(id =>
    {
        const e = document.getElementById(id);

        if(e)
            e.disabled = !mode1.checked;
    });

    //------------------------------------------
    // Mode2 parameters
    //------------------------------------------

    ["p2", "p4", "p14", "p15"].forEach(id =>
    {
        const e = document.getElementById(id);

        if(e)
            e.disabled = !mode2.checked;
    });

    //------------------------------------------
    // P3 (MAX.reg.value) is shared by Mode1 and Mode2.
    // P8 is also always available.
    //------------------------------------------

    ["p3", "p8"].forEach(id =>
    {
        const e = document.getElementById(id);

        if(e)
            e.disabled = false;
    });
}

//----------------------------------------------------
// DIMMER
//----------------------------------------------------

function dimmerPlus()
{
    if(document.getElementById("dimmerPlus").disabled)
        return;

    let value =
        parseInt(UI.dimmerValue.value);

    if(isNaN(value))
        value = 0;

    if(value < 100)
        value++;

    UI.dimmerValue.value = value;
}

function dimmerMinus()
{
    if(document.getElementById("dimmerMinus").disabled)
        return;

    let value =
        parseInt(UI.dimmerValue.value);

    if(isNaN(value))
        value = 0;

    if(value > 0)
        value--;

    UI.dimmerValue.value = value;
}

//----------------------------------------------------
// MODE EVENTS
//----------------------------------------------------

document.getElementById("mode1")
    .addEventListener(
        "change",
        updateModeSelection
    );

document.getElementById("mode2")
    .addEventListener(
        "change",
        updateModeSelection
    );

document.getElementById("mode3")
    .addEventListener(
        "change",
        updateModeSelection
    );

//----------------------------------------------------
// APPLY SETTINGS
//----------------------------------------------------

async function applySettings()
{
    let data = {};

    //------------------------------------------
    // Parameters
    //------------------------------------------

    for(let i=0;i<18;i++)
    {
        const obj =
            document.getElementById("p"+i);

        if(obj)
            data["p"+i] =
                Number(obj.value);
    }

    //------------------------------------------
    // Active mode
    //------------------------------------------

   if(document.getElementById("mode1").checked)
    data.mode = 2;      // Fix Voltage

else if(document.getElementById("mode3").checked)
    data.mode = 3;      // Dimmer

else
    data.mode = 4;      // MPPT

    // Inverter type

      data.p16 =
          Number(UI.inverterType.value);

    //------------------------------------------
    // Dimmer
    //------------------------------------------

     let d =
         Number(UI.dimmerValue.value);

     if (isNaN(d))
          d = 0;

     if (d < 0)
         d = 0;

     if (d > 100)
         d = 100;

     // P10 = Dimmer set
      data.p10 = d;

    //------------------------------------------
    // Send
    //------------------------------------------

    try
{
    const response = await fetch("/api/settings",
    {
        method:"POST",

        headers:
        {
            "Content-Type":"application/json"
        },

        body:JSON.stringify(data)
    });

    //----------------------------------------
    // Bluetooth занят
    //----------------------------------------

    if(response.status == 423)
    {
        const json = await response.json();

        alert(
            "⚠ Управление временно недоступно\n\n" +
            "К Вампиру подключено Bluetooth-приложение.\n\n" +
            "Закройте Bluetooth-приложение\n" +
            "и повторите попытку."
        );

        log(json.message);

        return;
    }

    //----------------------------------------
    // Остальные ошибки
    //----------------------------------------

    if(!response.ok)
    {
        log("Save error");

        alert("Ошибка сохранения настроек.");

        return;
    }

    log("Settings saved");
}
catch(e)
{
    log("Save error");

    alert("Нет связи с ESP32.");
}
}

//----------------------------------------------------
// SAVE SETTINGS
//----------------------------------------------------

async function saveSettings()
{
    await applySettings();

    await loadSettings();

    log("Reload complete");
}

//----------------------------------------------------
// SAVE WIFI
//----------------------------------------------------

async function saveWifi()
{
    const ssidInput = document.getElementById("wifiSSID");
    const passInput = document.getElementById("wifiPASS");

    const data =
    {
        ssid: ssidInput.value.trim(),
        password: passInput.value
    };

    if(!data.ssid)
    {
        alert("Введите имя WiFi сети (SSID).");
        ssidInput.focus();
        return;
    }

    try
    {
        const response = await fetch("/api/savewifi",
        {
            method: "POST",

            headers:
            {
                "Content-Type": "application/json"
            },

            body: JSON.stringify(data)
        });

        let result = {};

        try
        {
            result = await response.json();
        }
        catch(e)
        {
            result = {};
        }

        if(!response.ok)
        {
            const message = result.message || "Не удалось сохранить настройки WiFi.";
            log("WiFi save error: " + message);
            alert(message);
            return;
        }

        closeWifi();
        log("WiFi settings saved. ESP32 restarting...");

        alert(
            "Настройки WiFi сохранены. ESP32 перезагрузится и подключится к сети: " +
            data.ssid
        );
    }
    catch(e)
    {
        log("WiFi error");
        alert("Нет связи с ESP32. Настройки WiFi не сохранены.");
    }
}

//----------------------------------------------------
// OTA
//----------------------------------------------------

function setFirmwareProgress(value)
{
    const percent = Math.max(0, Math.min(100, Math.round(value)));
    document.getElementById("firmwareProgressBar").style.width = percent + "%";
    document.getElementById("firmwareProgressText").textContent = percent + "%";
}

function firmwareFileChanged()
{
    if(firmwareUploadActive)
        return;

    document.getElementById("firmwareUploadButton").disabled =
        !document.getElementById("firmwareFile").files.length;
}

function setFirmwareControlsLocked(locked)
{
    firmwareUploadActive = locked;

    const fileInput = document.getElementById("firmwareFile");
    const uploadButton = document.getElementById("firmwareUploadButton");
    const closeButton = document.getElementById("firmwareCloseButton");

    fileInput.disabled = locked;
    uploadButton.disabled = locked || !fileInput.files.length;
    closeButton.disabled = locked;
    uploadButton.textContent = locked ? "Uploading..." : "Upload";
}

function showFirmwareResult(message, ok)
{
    const result = document.getElementById("firmwareResult");
    result.style.display = "block";
    result.textContent = message;
    result.style.border = "1px solid " + (ok ? "#43a047" : "#e53935");
}

function uploadFirmware()
{
    if(firmwareUploadActive)
        return;

    const file = document.getElementById("firmwareFile").files[0];

    if(!file)
    {
        alert("Select firmware.bin");
        return;
    }

    setFirmwareControlsLocked(true);

    document.getElementById("firmwareProgressWrap").style.display = "block";
    document.getElementById("firmwareResult").style.display = "none";
    document.getElementById("firmwareOkButton").style.display = "none";
    setFirmwareProgress(0);

    const form = new FormData();
    form.append("update", file);

    const xhr = new XMLHttpRequest();
    xhr.open("POST", "/update", true);
    xhr.timeout = 120000;

    xhr.upload.onprogress = function(event)
    {
        if(event.lengthComputable)
            setFirmwareProgress(event.loaded * 100 / event.total);
    };

    xhr.onload = function()
    {
        let response = {};
        try
        {
            response = JSON.parse(xhr.responseText || "{}");
        }
        catch(e) {}

        if(xhr.status >= 200 && xhr.status < 300 && response.ok)
        {
            setFirmwareProgress(100);
            showFirmwareResult("Firmware updated successfully. ESP32 is rebooting...", true);
            log("OTA successful");
            waitForEspAfterOta();
        }
        else
        {
            setFirmwareControlsLocked(false);
            showFirmwareResult(response.message || ("Update failed. HTTP " + xhr.status), false);
            log("OTA error");
        }
    };

    xhr.onerror = function()
    {
        setFirmwareControlsLocked(false);
        showFirmwareResult("Connection error during firmware update.", false);
        log("OTA connection error");
    };

    xhr.ontimeout = function()
    {
        setFirmwareControlsLocked(false);
        showFirmwareResult("Firmware upload timeout.", false);
        log("OTA timeout");
    };

    xhr.onabort = function()
    {
        setFirmwareControlsLocked(false);
        showFirmwareResult("Firmware upload was aborted.", false);
        log("OTA aborted");
    };

    xhr.send(form);
}

async function waitForEspAfterOta()
{
    // Give the ESP32 time to actually restart before probing it.
    await new Promise(resolve => setTimeout(resolve, 2500));

    const started = Date.now();

    while(firmwareUploadActive)
    {
        try
        {
            const response = await fetch("/?ota_probe=" + Date.now(),
            {
                method: "GET",
                cache: "no-store",
                headers: { "Cache-Control": "no-cache" }
            });

            if(response.ok)
            {
                showFirmwareResult("ESP32 is online. Reloading page...", true);
                await new Promise(resolve => setTimeout(resolve, 500));
                window.location.replace("/?ota_done=" + Date.now());
                return;
            }
        }
        catch(e)
        {
            // Expected while the ESP32 is rebooting.
        }

        if(Date.now() - started > 90000)
        {
            showFirmwareResult("Firmware was installed, but automatic reconnect timed out. Reload the page manually.", false);
            firmwareUploadActive = false;
            document.getElementById("firmwareCloseButton").disabled = false;
            return;
        }

        await new Promise(resolve => setTimeout(resolve, 1000));
    }
}

function finishFirmwareUpdate()
{
    if(firmwareUploadActive)
        return;

    closeFirmware();

    document.getElementById("firmwareFile").value = "";
    document.getElementById("firmwareProgressWrap").style.display = "none";
    document.getElementById("firmwareResult").style.display = "none";
    document.getElementById("firmwareOkButton").style.display = "none";
    document.getElementById("firmwareCloseButton").style.display = "inline-block";
    setFirmwareControlsLocked(false);
}

//----------------------------------------------------
// RESTART
//----------------------------------------------------

async function restartESP()
{
    if(!confirm("Restart ESP32 ?"))
        return;

    try
    {
        const response = await fetch("/api/restart?t=" + Date.now(), { cache: "no-store" });
        if (!response.ok)
            throw new Error("HTTP " + response.status);

        alert("Команда перезапуска отправлена. Подключение восстановится после загрузки ESP32.");
    }
    catch (error)
    {
        alert("Не удалось отправить команду перезапуска: " + error.message);
    }
}

//----------------------------------------------------
// REFRESH
//----------------------------------------------------

let refreshRunning = false;
let refreshCounter = 0;

function settingsEditorActive()
{
    const el = document.activeElement;
    if(!el) return false;
    return el.tagName === "INPUT" || el.tagName === "SELECT" || el.tagName === "TEXTAREA";
}

async function refresh()
{
    // setInterval must not start a second HTTP chain while the previous one
    // is still waiting. Bluetooth sessions can temporarily delay requests.
    if(refreshRunning)
    {
        console.log("[BrowserSync] refresh skipped: previous cycle is active");
        return;
    }

    refreshRunning = true;
    try
    {
        await loadStatus();
        await loadRealtime();
        await loadFuses();

        // Settings were previously loaded only once, on page opening. Refresh
        // them every two seconds so changes made by the Bluetooth application
        // appear without F5. Do not overwrite a field while the user edits it.
        refreshCounter++;
        if((refreshCounter % 2) === 0 && !settingsEditorActive())
        {
            await loadSettings();
            console.log("[BrowserSync] settings refreshed");
        }
    }
    finally
    {
        refreshRunning = false;
    }
}

//----------------------------------------------------
// START
//----------------------------------------------------

window.onload = async function()
{
    log("OpenVampire ESP32");

    await loadStatus();

    await loadSettings();

    await loadRealtime();

    await loadFuses();

    setInterval(refresh,1000);
};
</script>

</body>
</html>
)rawliteral";
