# 0.12.37 Credits, mobile layout and graph labels test

- Hidden ESP easter egg remains visually unmarked.
- Rail logo changed: two parallel rails run from bottom-left to top-right through the S, with visible sleepers between them.
- Russian role captions removed; English-only credits.
- Mobile credits rows kept on one line: role and name.
- Year chart value labels now match the month chart: dark, bold and always above the bars.
