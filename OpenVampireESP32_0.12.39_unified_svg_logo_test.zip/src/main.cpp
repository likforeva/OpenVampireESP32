//====================================================
// OpenVampire ESP32
// main.cpp
//====================================================

#include <Arduino.h>
#include <esp_system.h>
#include <WiFi.h>
#include <WebServer.h>
#include <ArduinoJson.h>
#include <esp_timer.h>
#include "Config.h"
#include "Protocol.h"
#include "Settings.h"
#include "DebugLog.h"
#include "WifiManager.h"
#include "Vampire.h"
#include "OTA.h"
#include "BTBridge.h"
#include "index_html.h"
#include "fuses_html.h"
#include "vampire_update_html.h"
#include "VampireUpdater.h"
#include "StatusLed.h"
#include "MqttManager.h"
#include "mqtt_html.h"
#include "EnergyStats.h"
#include "statistics_html.h"



////////////////////////////////////////////////////////
// Global objects
////////////////////////////////////////////////////////

WifiManager wifi;

WebServer server(80);

OTA ota(server);

Vampire vampire(Serial2);
VampireUpdater vampireUpdater(Serial2);
MqttManager mqtt;
EnergyStats energyStats;
bool vampireMaintenanceMode = false;

volatile bool restartRequested = false;
uint32_t restartRequestedAt = 0;


////////////////////////////////////////////////////////
// Access Point
////////////////////////////////////////////////////////

const char *apSSID = DEFAULT_AP_SSID;
const char *apPASS = DEFAULT_AP_PASS;

constexpr uint32_t AP_DISABLE_DELAY_MS = 5UL * 60UL * 1000UL;
bool accessPointEnabled = true;
bool staWasConnected = false;
uint32_t staConnectedSince = 0;

void startAccessPoint()
{
    if (accessPointEnabled)
        return;

    WiFi.mode(WIFI_AP_STA);
    accessPointEnabled = WiFi.softAP(apSSID, apPASS);

    if (accessPointEnabled)
        Serial.println("OpenVampire access point started");
    else
        Serial.println("ERROR: Cannot start OpenVampire access point");
}

void stopAccessPoint()
{
    if (!accessPointEnabled)
        return;

    WiFi.softAPdisconnect(true);
    WiFi.mode(WIFI_STA);
    accessPointEnabled = false;
    Serial.println("OpenVampire access point stopped after 5 minutes");
}

void updateAccessPointState()
{
    const bool staConnected = WiFi.status() == WL_CONNECTED;

    if (staConnected)
    {
        if (!staWasConnected)
        {
            staConnectedSince = millis();
            staWasConnected = true;
        }

        if (accessPointEnabled &&
            (uint32_t)(millis() - staConnectedSince) >= AP_DISABLE_DELAY_MS)
        {
            stopAccessPoint();
        }
    }
    else
    {
        staWasConnected = false;
        staConnectedSince = 0;

        // Restore the configuration AP if the router connection is lost.
        if (!accessPointEnabled)
            startAccessPoint();
    }
}
////////////////////////////////////////////////////////
// JSON
////////////////////////////////////////////////////////

String statusJson()
{
    JsonDocument doc;

    doc["serial"] = vampire.serialNumber();

    doc["fw"] = vampire.firmware();      // версия Вампира
    doc["esp"] = FW_VERSION;             // версия ESP32

    if (wifi.isConnected())
        doc["ip"] = WiFi.localIP().toString();
    else
        doc["ip"] = WiFi.softAPIP().toString();

    doc["connected"] = wifi.isConnected();

    // Wi-Fi signal level is meaningful only while connected to a router.
    if (wifi.isConnected())
        doc["rssi"] = WiFi.RSSI();
    else
        doc["rssi"] = nullptr;

    // 64-bit uptime in seconds; unlike millis(), this does not wrap after ~49 days.
    doc["uptime"] = static_cast<uint64_t>(esp_timer_get_time() / 1000000ULL);

    const uint32_t heapTotal = ESP.getHeapSize();
    const uint32_t heapFree = ESP.getFreeHeap();
    doc["ram_total"] = heapTotal;
    doc["ram_free"] = heapFree;
    doc["ram_used"] = heapTotal > heapFree ? heapTotal - heapFree : 0;
    doc["ram_min_free"] = ESP.getMinFreeHeap();
    doc["ram_largest"] = ESP.getMaxAllocHeap();
    doc["flash_used"] = ESP.getSketchSize();
    doc["flash_free"] = ESP.getFreeSketchSpace();

    String out;

    serializeJson(doc, out);

    return out;
}

////////////////////////////////////////////////////////

String settingsJson()
{
    JsonDocument doc;

    const Settings &s = vampire.getSettings();

    doc["mode"] = s.mode;

    for (int i = 0; i < 18; i++)
    {
        doc["p" + String(i)] = s.p[i];
    }

    doc["p16"] = s.p[16];

    String out;

    serializeJson(doc, out);

    return out;
}

////////////////////////////////////////////////////////

String telemetryJson()
{
    JsonDocument doc;

    const Telemetry &t = vampire.getTelemetry();

    doc["pv1_voltage"] = t.pv1Voltage;
    doc["pv1_current"] = t.pv1Current;
    doc["pv1_power"]   = t.pv1Power;

    doc["pv2_voltage"] = t.pv2Voltage;
    doc["pv2_current"] = t.pv2Current;
    doc["pv2_power"]   = t.pv2Power;

    doc["battery_voltage"] = t.batteryVoltage;
    doc["battery_soc"]     = t.batterySOC;

    doc["charge_current"]    = t.chargeCurrent;
    doc["discharge_current"] = t.dischargeCurrent;

    doc["inverter_load"] = t.inverterLoad;
    doc["grid_power"]    = t.gridPower;

    doc["regulator_out"] = t.regulatorOutput;

    doc["valid"] = t.valid;

    String out;

    serializeJson(doc, out);

    return out;
}
////////////////////////////////////////////////////////
// HTTP API
////////////////////////////////////////////////////////

void handleStatus()
{
    statusLed.activity();
    server.sendHeader("Cache-Control", "no-store, no-cache, must-revalidate");
    server.sendHeader("Pragma", "no-cache");
    server.send(
        200,
        "application/json",
        statusJson()
    );
}

////////////////////////////////////////////////////////

void handleGetSettings()
{
    statusLed.activity();
    server.sendHeader("Cache-Control", "no-store, no-cache, must-revalidate");
    server.sendHeader("Pragma", "no-cache");
    server.send(
        200,
        "application/json",
        settingsJson()
    );
}

////////////////////////////////////////////////////////

void handleGetTelemetry()
{
    statusLed.activity();
    server.sendHeader("Cache-Control", "no-store, no-cache, must-revalidate");
    server.sendHeader("Pragma", "no-cache");
    server.send(
        200,
        "application/json",
        telemetryJson()
    );
}

////////////////////////////////////////////////////////

void handleSaveSettings()
{
    statusLed.activity();
    // -------------------------------------------------
    // Если Bluetooth-клиент подключен — запрещаем запись
    // -------------------------------------------------

    if (btBridge.isConnected())
{
    server.send(
        423,
        "application/json",
        R"({
            "result":"busy",
            "message":"Bluetooth application is connected. Disconnect it before changing settings."
        })"
    );

    return;
}

    JsonDocument doc;

    if (deserializeJson(doc, server.arg("plain")))
    {
        server.send(400);
        return;
    }

    Settings &s = vampire.getSettings();

    if (doc["mode"].is<uint8_t>())
        s.mode = doc["mode"];

    for (int i = 0; i < 18; i++)
    {
        String n = "p" + String(i);

        if (doc[n].is<uint16_t>())
            s.p[i] = doc[n];
    }

    debugLog.add("Settings updated");

    if(!vampire.sendAllParameters())
    {
        server.send(409, "application/json",
                    R"({"result":"error","message":"Vampire settings have not been loaded yet."})");
        return;
    }

    server.send(200, "application/json", R"({"result":"ok"})");
}
////////////////////////////////////////////////////////
// Bluetooth Bridge
////////////////////////////////////////////////////////

void handleBridge()
{
    statusLed.activity();
    server.send(200, "text/plain", "OK");
}
////////////////////////////////////////////////////////
// SAVE ONLY PROTOCOL
////////////////////////////////////////////////////////

void handleSaveProtocol()
{
    statusLed.activity();
    if (btBridge.isConnected())
    {
        server.send(423, "application/json",
                    R"({"result":"busy","message":"Bluetooth owns the Vampire UART."})");
        return;
    }

    JsonDocument doc;

    if (deserializeJson(doc, server.arg("plain")))
    {
        server.send(400);
        return;
    }

    Settings &s = vampire.getSettings();

    if(doc["protocol"].is<uint16_t>())
        s.p[16] = doc["protocol"];

    vampire.sendParameter(16, s.p[16]);

    debugLog.add(
        "Protocol changed to " +
        String(s.p[16])
    );

    server.send(200, "text/plain", "OK");
}
////////////////////////////////////////////////////////
// Fuses
////////////////////////////////////////////////////////

void handleGetFuses()
{
    statusLed.activity();
    JsonDocument doc;

    const Settings &s = vampire.getSettings();

    doc["batVoltEnable"]    = s.fuse.batVoltEnable;
    doc["batVolt"] = s.fuse.batVoltLimit / 10.0;

    doc["batSocEnable"]     = s.fuse.batSocEnable;
    doc["batSoc"]           = s.fuse.batSocLimit;

    doc["chargeEnable"]     = s.fuse.chargeEnable;
    doc["chargeCurrent"]    = s.fuse.chargeLimit;

    doc["dischargeEnable"]  = s.fuse.dischargeEnable;
    doc["dischargeCurrent"] = s.fuse.dischargeLimit;

    doc["loadEnable"]       = s.fuse.loadEnable;
    doc["loadLimit"]        = s.fuse.loadLimit;

    doc["gridEnable"]       = s.fuse.gridEnable;
    doc["gridLimit"]        = s.fuse.gridLimit;

    String out;
    serializeJson(doc, out);

    server.send(200, "application/json", out);
}

////////////////////////////////////////////////////////

void handleSaveFuses()
{
    statusLed.activity();
    if (btBridge.isConnected())
    {
        server.send(423, "application/json",
                    R"({"result":"busy","message":"Bluetooth owns the Vampire UART."})");
        return;
    }

    JsonDocument doc;

    if (deserializeJson(doc, server.arg("plain")))
    {
        server.send(400);
        return;
    }

    Settings &s = vampire.getSettings();

    s.fuse.batVoltEnable    = doc["batVoltEnable"]    | false;
    s.fuse.batVoltLimit =
    uint16_t((doc["batVolt"].as<float>() * 10.0f) + 0.5f);

    s.fuse.batSocEnable     = doc["batSocEnable"]     | false;
    s.fuse.batSocLimit      = doc["batSoc"]           | 0;

    s.fuse.chargeEnable     = doc["chargeEnable"]     | false;
    s.fuse.chargeLimit      = doc["chargeCurrent"]    | 0;

    s.fuse.dischargeEnable  = doc["dischargeEnable"]  | false;
    s.fuse.dischargeLimit   = doc["dischargeCurrent"] | 0;

    s.fuse.loadEnable       = doc["loadEnable"]       | false;
    s.fuse.loadLimit        = doc["loadLimit"]        | 0;

    s.fuse.gridEnable       = doc["gridEnable"]       | false;
    s.fuse.gridLimit        = doc["gridLimit"]        | 0;

    s.encodeFuseBits();

    if(!vampire.sendAllParameters())
    {
        server.send(409, "application/json",
                    R"({"result":"error","message":"Vampire settings have not been loaded yet."})");
        return;
    }

    debugLog.add("Fuse settings updated");
    server.send(200, "application/json", R"({"result":"ok"})");
}

////////////////////////////////////////////////////////
// WiFi
////////////////////////////////////////////////////////

void handleSaveWifi()
{
    statusLed.activity();
    JsonDocument doc;

    const DeserializationError error =
        deserializeJson(doc, server.arg("plain"));

    if (error)
    {
        server.send(
            400,
            "application/json",
            R"({"result":"error","message":"Invalid JSON"})"
        );
        return;
    }

    String ssid = doc["ssid"] | "";
    String pass = doc["password"] | "";

    // Accidental spaces around an SSID are almost always a UI input error.
    // Do not trim the password because spaces may legally be part of it.
    ssid.trim();

    if (ssid.isEmpty())
    {
        server.send(
            400,
            "application/json",
            R"({"result":"error","message":"SSID is empty"})"
        );
        return;
    }

    wifi.saveCredentials(ssid, pass);

    debugLog.add("WiFi settings saved: " + ssid);

    server.sendHeader("Cache-Control", "no-store");
    server.sendHeader("Connection", "close");
    server.send(
        200,
        "application/json",
        R"({"result":"ok","message":"WiFi settings saved. ESP32 is restarting."})"
    );

    // Restart from loop(), after the HTTP response has had time to leave.
    restartRequested = true;
    restartRequestedAt = millis();
}

////////////////////////////////////////////////////////
// MQTT
////////////////////////////////////////////////////////

void handleMqttPage()
{
    statusLed.activity();
    server.sendHeader("Cache-Control", "no-store, no-cache, must-revalidate");
    server.send_P(200, "text/html; charset=utf-8", MQTT_HTML);
}

void handleGetMqtt()
{
    statusLed.activity();
    const MqttConfig &cfg = mqtt.config();

    JsonDocument doc;
    doc["enabled"] = cfg.enabled;
    doc["host"] = cfg.host;
    doc["port"] = cfg.port;
    doc["user"] = cfg.user;
    doc["period"] = cfg.periodSeconds;
    doc["configured_topic"] = cfg.topic;
    doc["state"] = mqtt.stateText();
    doc["topic"] = mqtt.topicFor(vampire.serialNumber());
    doc["connected"] = mqtt.connected();

    String out;
    serializeJson(doc, out);
    server.sendHeader("Cache-Control", "no-store");
    server.send(200, "application/json", out);
}

void handleSaveMqtt()
{
    statusLed.activity();

    JsonDocument doc;
    if (deserializeJson(doc, server.arg("plain")))
    {
        server.send(400, "application/json", R"({"result":"error","message":"Invalid JSON"})");
        return;
    }

    MqttConfig cfg = mqtt.config();
    cfg.enabled = doc["enabled"] | false;
    cfg.host = String((const char *)(doc["host"] | ""));
    cfg.host.trim();
    cfg.port = constrain((int)(doc["port"] | 1883), 1, 65535);
    cfg.user = String((const char *)(doc["user"] | ""));

    const String submittedPassword = String((const char *)(doc["password"] | ""));
    if (!submittedPassword.isEmpty())
        cfg.password = submittedPassword;

    cfg.periodSeconds = constrain((int)(doc["period"] | 10), 0, 65535);
    cfg.topic = String((const char *)(doc["topic"] | ""));
    cfg.topic.trim();

    if (cfg.enabled && cfg.host.isEmpty())
    {
        server.send(400, "application/json", R"({"result":"error","message":"Broker address is empty"})");
        return;
    }

    mqtt.save(cfg);

    JsonDocument reply;
    reply["result"] = "ok";
    reply["state"] = mqtt.stateText();
    String out;
    serializeJson(reply, out);
    server.send(200, "application/json", out);
}



////////////////////////////////////////////////////////
// Restart
////////////////////////////////////////////////////////

void handleRestart()
{
    statusLed.activity();
    debugLog.add("ESP32 restart requested from Web UI");

    server.sendHeader("Cache-Control", "no-store");
    server.sendHeader("Connection", "close");
    server.send(200, "application/json", R"({"result":"ok","message":"ESP32 is restarting"})");

    // Do not restart inside the HTTP callback: the response may never reach
    // the browser. The main loop performs the restart after the TCP reply.
    restartRequested = true;
    restartRequestedAt = millis();
}

////////////////////////////////////////////////////////
// Debug log
////////////////////////////////////////////////////////

void handleDebug()
{
    statusLed.activity();
    server.send(
        200,
        "text/plain",
        debugLog.get()
    );
}

////////////////////////////////////////////////////////
// Files
////////////////////////////////////////////////////////

void handleRoot()
{
    statusLed.activity();
    server.send_P(
        200,
        "text/html",
        INDEX_HTML
    );
}

void handleFusesHTML()
{
    statusLed.activity();

    // This page is relatively large and is opened while the main page may
    // still have pending polling requests. Closing the HTTP connection after
    // the response prevents stale keep-alive sockets from occupying the
    // synchronous WebServer.
    server.sendHeader("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");
    server.sendHeader("Pragma", "no-cache");
    server.sendHeader("Connection", "close");
    server.send_P(200, "text/html; charset=utf-8", FUSES_HTML);
}

////////////////////////////////////////////////////////
// Vampire firmware updater
////////////////////////////////////////////////////////

void enterVampireMaintenance()
{
    if (vampireMaintenanceMode)
        return;

    // Any valid command stops the continuous ATtrans stream.
    // Give Serial2 exclusively to the firmware updater.
    vampire.requestInfo();
    delay(80);
    while (Serial2.available())
        Serial2.read();

    vampireMaintenanceMode = true;
    mqtt.pause(true);
    vampire.setBridgeMode(true);
    btBridge.disable();
    debugLog.add("Vampire maintenance mode entered");
}

void leaveVampireMaintenance()
{
    if (vampireUpdater.busy())
        return;

    vampireUpdater.reset();
    vampireMaintenanceMode = false;
    mqtt.pause(false);
    vampire.setBridgeMode(false);
    vampire.requestInfo();
    vampire.requestSettings();
    vampire.startTelemetry();
    debugLog.add("Vampire normal mode restored");
}

void handleVampireUpdatePage()
{
    statusLed.activity();
    // Opening the page must not stop telemetry or Bluetooth. Maintenance mode
    // starts only when the actual Vampire flashing process is requested.
    server.send_P(200, "text/html", VAMPIRE_UPDATE_HTML);
}

void handleVampireFirmwareStart()
{
    statusLed.activity();
    enterVampireMaintenance();

    String error;
    if (!vampireUpdater.start(error))
    {
        server.send(409, "application/json", String("{\"result\":\"error\",\"message\":\"") + error + "\"}");
        return;
    }
    statusLed.setMode(StatusLedMode::VampireUpdate);
    server.send(200, "application/json", R"({"result":"ok"})");
}

void handleVampireFirmwareStatus()
{
    statusLed.activity();
    server.sendHeader("Cache-Control", "no-store");
    server.send(200, "application/json", vampireUpdater.statusJson());
}

void handleVampireFirmwareExit()
{
    statusLed.activity();
    if (vampireUpdater.flashing())
    {
        server.send(423, "application/json", R"({"result":"busy","message":"Firmware update is active"})");
        return;
    }
    leaveVampireMaintenance();
    statusLed.setMode(StatusLedMode::Normal);
    server.send(200, "application/json", R"({"result":"ok"})");
}


bool vampireLocalUploadOk = false;
String vampireLocalUploadError;
bool vampireUploadQuietMode = false;

static String jsonEscape(const String &value)
{
    String out;
    out.reserve(value.length() + 8);

    for (size_t i = 0; i < value.length(); ++i)
    {
        const char c = value.charAt(i);
        switch (c)
        {
            case '\\': out += "\\\\"; break;
            case '"':  out += "\\\""; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default:
                if (static_cast<uint8_t>(c) >= 0x20)
                    out += c;
                break;
        }
    }

    return out;
}

void handleVampireFirmwareUploadDone()
{
    statusLed.activity();
    Serial.printf("[VampireUpload] HTTP completion handler ok=%d heap=%u\n",
                  vampireLocalUploadOk ? 1 : 0,
                  (unsigned)ESP.getFreeHeap());
    if (!vampireLocalUploadOk)
    {
        server.send(400, "application/json", String("{\"result\":\"error\",\"message\":\"") + jsonEscape(vampireLocalUploadError) + "\"}");
        return;
    }
    server.send(200, "application/json", vampireUpdater.statusJson());
}

void handleVampireFirmwareUploadData()
{
    statusLed.activity();
    HTTPUpload &upload = server.upload();
    String error;

    if (upload.status == UPLOAD_FILE_START)
    {
        // Diagnostic quiet mode: SPIFFS writes and Bluetooth both use internal
        // ESP32 resources. Stop UART/BT activity before the first flash write,
        // but keep Wi-Fi and WebServer running so the POST can complete.
        vampireUploadQuietMode = true;
        vampireMaintenanceMode = true;
        vampire.setBridgeMode(true);
        btBridge.disable();
        WiFi.setSleep(false);
        while (Serial2.available()) Serial2.read();

        Serial.printf("[VampireUpload] START name=%s total=%u heap=%u\n",
                      upload.filename.c_str(),
                      (unsigned)upload.totalSize,
                      (unsigned)ESP.getFreeHeap());

        vampireLocalUploadError = "";
        vampireLocalUploadOk = vampireUpdater.beginLocalUpload(upload.filename, error);
        if (!vampireLocalUploadOk)
            vampireLocalUploadError = error;
    }
    else if (upload.status == UPLOAD_FILE_WRITE)
    {
        static uint32_t nextReport = 0;
        if (upload.totalSize >= nextReport)
        {
            Serial.printf("[VampireUpload] WRITE before total=%u chunk=%u heap=%u\n",
                          (unsigned)upload.totalSize,
                          (unsigned)upload.currentSize,
                          (unsigned)ESP.getFreeHeap());
            nextReport = upload.totalSize + 16384;
        }

        if (vampireLocalUploadOk && !vampireUpdater.writeLocalUpload(upload.buf, upload.currentSize, error))
        {
            vampireLocalUploadOk = false;
            vampireLocalUploadError = error;
            Serial.printf("[VampireUpload] WRITE ERROR total=%u: %s\n",
                          (unsigned)upload.totalSize, error.c_str());
        }
        delay(0);
    }
    else if (upload.status == UPLOAD_FILE_END)
    {
        Serial.printf("[VampireUpload] END before close total=%u heap=%u\n",
                      (unsigned)upload.totalSize,
                      (unsigned)ESP.getFreeHeap());
        if (vampireLocalUploadOk && !vampireUpdater.finishLocalUpload(error))
        {
            vampireLocalUploadOk = false;
            vampireLocalUploadError = error;
        }
        Serial.printf("[VampireUpload] END complete ok=%d heap=%u\n",
                      vampireLocalUploadOk ? 1 : 0,
                      (unsigned)ESP.getFreeHeap());
    }
    else if (upload.status == UPLOAD_FILE_ABORTED)
    {
        Serial.printf("[VampireUpload] ABORTED total=%u heap=%u\n",
                      (unsigned)upload.totalSize,
                      (unsigned)ESP.getFreeHeap());
        vampireUpdater.reset();
        vampireLocalUploadOk = false;
        vampireLocalUploadError = "Upload aborted.";
    }
}


void handleStatisticsPage()
{
    statusLed.activity();
    server.send_P(200, "text/html", STATISTICS_HTML);
}

void handleStatisticsJson()
{
    statusLed.activity();
    server.sendHeader("Cache-Control", "no-store, no-cache, must-revalidate");
    server.send(200, "application/json", energyStats.json());
}

void handleStatisticsCsv()
{
    statusLed.activity();
    server.sendHeader("Content-Disposition", "attachment; filename=openvampire_statistics.csv");
    server.send(200, "text/csv; charset=utf-8", energyStats.csv());
}

void handleStatisticsReset()
{
    statusLed.activity();
    energyStats.reset();
    server.sendHeader("Cache-Control", "no-store");
    server.send(200, "application/json", "{\"ok\":true}");
}

////////////////////////////////////////////////////////
// SETUP
////////////////////////////////////////////////////////

void setup()
{
    Serial.begin(115200);
    delay(50);

    Serial.printf("OpenVampireESP32 %s\n", FW_VERSION);

    statusLed.begin();

    vampire.begin();
    vampireUpdater.begin();
    btBridge.begin();
    mqtt.begin();
    energyStats.begin();

    // Bluetooth starts after ATinfo is parsed, using name SV-<serial>.

    WiFi.mode(WIFI_AP_STA);
    accessPointEnabled = WiFi.softAP(apSSID, apPASS);
    wifi.begin();
    wifi.connect();

    if (WiFi.status() == WL_CONNECTED)
    {
        staWasConnected = true;
        staConnectedSince = millis();
    }

    server.on("/", handleRoot);
    server.on("/fuses.html", handleFusesHTML);
    server.on("/vampire-update", HTTP_GET, handleVampireUpdatePage);
    server.on("/mqtt", HTTP_GET, handleMqttPage);
    server.on("/statistics", HTTP_GET, handleStatisticsPage);

    server.on("/api/status", HTTP_GET, handleStatus);
    server.on("/api/settings", HTTP_GET, handleGetSettings);
    server.on("/api/settings", HTTP_POST, handleSaveSettings);
    server.on("/api/protocol", HTTP_POST, handleSaveProtocol);
    server.on("/api/fuses", HTTP_GET, handleGetFuses);
    server.on("/api/fuses", HTTP_POST, handleSaveFuses);
    server.on("/api/trans", HTTP_GET, handleGetTelemetry);
    server.on("/api/savewifi", HTTP_POST, handleSaveWifi);
    server.on("/api/restart", HTTP_GET, handleRestart);
    server.on("/api/mqtt", HTTP_GET, handleGetMqtt);
    server.on("/api/mqtt", HTTP_POST, handleSaveMqtt);
    server.on("/api/statistics", HTTP_GET, handleStatisticsJson);
    server.on("/api/statistics.csv", HTTP_GET, handleStatisticsCsv);
    server.on("/api/statistics/reset", HTTP_POST, handleStatisticsReset);

    server.on("/api/bt", HTTP_GET, []()
        {
            statusLed.activity();
            JsonDocument doc;
            doc["enabled"] = btBridge.enabled();
            doc["connected"] = btBridge.isConnected();
            doc["name"] = btBridge.getDeviceName();
            doc["exclusive_bridge"] = vampire.bridgeMode();

            String out;
            serializeJson(doc, out);
            server.send(200, "application/json", out);
        });

    server.on("/api/bridge", HTTP_POST, handleBridge);
    server.on("/api/vampire-fw/upload", HTTP_POST, handleVampireFirmwareUploadDone, handleVampireFirmwareUploadData);
    server.on("/api/vampire-fw/start", HTTP_POST, handleVampireFirmwareStart);
    server.on("/api/vampire-fw/status", HTTP_GET, handleVampireFirmwareStatus);
    server.on("/api/vampire-fw/exit", HTTP_POST, handleVampireFirmwareExit);
    server.on("/debug", HTTP_GET, handleDebug);

    ota.begin();
    server.begin();

    vampire.requestInfo();
    vampire.requestSettings();

    debugLog.add("System boot");
    debugLog.add("WiFi started");
    debugLog.add("Web server started");
}

////////////////////////////////////////////////////////
// LOOP
////////////////////////////////////////////////////////

void loop()
{
    statusLed.update();
    updateAccessPointState();

    if (restartRequested && millis() - restartRequestedAt >= 750)
    {
        Serial.println("ESP32 restarting now");
        Serial.flush();
        ESP.restart();
    }

    if (vampireMaintenanceMode)
    {
        server.handleClient();
        vampireUpdater.update();
        delay(0);
        return;
    }

    // Move Bluetooth/UART bytes first, then give HTTP a short opportunity on
    // every loop iteration. No Wi-Fi power-mode or extra task changes are used
    // in this diagnostic build.
    btBridge.update();
    server.handleClient();

    static bool previousBtConnection = false;
    static bool disconnectResyncPending = false;
    static uint32_t disconnectResyncAt = 0;

    const bool btConnected = btBridge.isConnected();

    if (btConnected && !previousBtConnection)
    {
        disconnectResyncPending = false;
        vampire.setBridgeMode(true);
    }
    else if (!btConnected && previousBtConnection)
    {
        // Do not immediately send ATinfo/ATsettings in the same iteration in
        // which the Bluetooth RFCOMM session disappears. This avoids mixing
        // trailing application bytes with the first ESP-generated command.
        disconnectResyncPending = true;
        disconnectResyncAt = millis() + 500;
    }

    previousBtConnection = btConnected;

    if (btConnected)
    {
        delay(0);
        return;
    }

    if (disconnectResyncPending)
    {
        if ((int32_t)(millis() - disconnectResyncAt) < 0)
        {
            delay(0);
            return;
        }

        disconnectResyncPending = false;

        // Discard only bytes that arrived after the Bluetooth link closed.
        // Vampire::setBridgeMode(false) performs the normal ATinfo/settings
        // synchronization already present in the stable 0.12.4 code.
        while (Serial2.available())
            Serial2.read();

        vampire.setBridgeMode(false);
    }

    vampire.update();
    energyStats.update(vampire.getTelemetry());
    mqtt.update(vampire.getTelemetry(), vampire.serialNumber(), vampire.firmware());

}
