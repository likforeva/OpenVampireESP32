#include "EnergyStats.h"
#include <ArduinoJson.h>
#include <WiFi.h>
#include <time.h>
#include <esp_timer.h>

namespace {
constexpr uint32_t SAVE_PERIOD_MS = 15UL * 60UL * 1000UL;
constexpr double KWH_DIVISOR = 3600000.0;

template <typename T>
T clampPower(double v) {
    if (v < 0) v = 0;
    if (v > 65535) v = 65535;
    return static_cast<T>(v + 0.5);
}
}

void EnergyStats::begin() {
    prefs.begin("energy", false);
    load();

    // Ukraine/Eastern Europe timezone with automatic summer time.
    // configTzTime keeps the TZ rule active; configTime(0, 0, ...) would
    // force UTC and shift the graph/rollover time.
    configTzTime("EET-2EEST,M3.5.0/3,M10.5.0/4",
                 "pool.ntp.org", "time.google.com", "time.cloudflare.com");
}

void EnergyStats::load() {
    prefs.getBytes("today", &today, sizeof(today));
    prefs.getBytes("total", &total, sizeof(total));
    prefs.getBytes("days", days, sizeof(days));
    prefs.getBytes("months", months, sizeof(months));
    currentYear = prefs.getUShort("year", 0);
    currentMonth = prefs.getUChar("month", 0);
    currentDay = prefs.getUChar("day", 0);
    monthCount = prefs.getUChar("mcount", 0);
    if (monthCount > MONTHS_MAX) monthCount = MONTHS_MAX;
}

void EnergyStats::save(bool force) {
    if (!force && (uint32_t)(millis() - lastSaveMs) < SAVE_PERIOD_MS) return;
    lastSaveMs = millis();
    prefs.putBytes("today", &today, sizeof(today));
    prefs.putBytes("total", &total, sizeof(total));
    prefs.putBytes("days", days, sizeof(days));
    prefs.putBytes("months", months, sizeof(months));
    prefs.putUShort("year", currentYear);
    prefs.putUChar("month", currentMonth);
    prefs.putUChar("day", currentDay);
    prefs.putUChar("mcount", monthCount);
}

void EnergyStats::add(EnergySet &dst, const EnergySet &src) {
    dst.pv += src.pv;
    dst.load += src.load;
    dst.charge += src.charge;
    dst.discharge += src.discharge;
    dst.gridImport += src.gridImport;
    dst.gridExport += src.gridExport;
}

void EnergyStats::closeDay(uint8_t day) {
    if (day < 1 || day > DAYS_MAX) return;
    DayRecord &r = days[day - 1];
    r.day = day;
    r.pv = today.pv;
    r.load = today.load;
    r.charge = today.charge;
    r.discharge = today.discharge;
    r.gridImport = today.gridImport;
    r.gridExport = today.gridExport;
    today = EnergySet{};
}

void EnergyStats::closeMonth(uint16_t year, uint8_t month) {
    EnergySet sum;
    for (const DayRecord &d : days) {
        sum.pv += d.pv; sum.load += d.load; sum.charge += d.charge;
        sum.discharge += d.discharge; sum.gridImport += d.gridImport;
        sum.gridExport += d.gridExport;
    }
    // Include current day if month rolls over before closeDay was called.
    add(sum, today);

    if (monthCount >= MONTHS_MAX) {
        memmove(&months[0], &months[1], sizeof(MonthRecord) * (MONTHS_MAX - 1));
        monthCount = MONTHS_MAX - 1;
    }
    MonthRecord &r = months[monthCount++];
    r.year = year; r.month = month;
    r.pv = sum.pv; r.load = sum.load; r.charge = sum.charge;
    r.discharge = sum.discharge; r.gridImport = sum.gridImport;
    r.gridExport = sum.gridExport;
    memset(days, 0, sizeof(days));
    today = EnergySet{};
}

void EnergyStats::updateClockAndRollovers() {
    struct tm now{};
    if (!getLocalTime(&now, 5)) return;
    const uint16_t year = now.tm_year + 1900;
    const uint8_t month = now.tm_mon + 1;
    const uint8_t day = now.tm_mday;
    clockReady = year >= 2024;
    if (!clockReady) return;

    if (currentYear == 0) {
        currentYear = year; currentMonth = month; currentDay = day;
        save(true);
        return;
    }

    if (year != currentYear || month != currentMonth) {
        closeMonth(currentYear, currentMonth);
        currentYear = year; currentMonth = month; currentDay = day;
        save(true);
    } else if (day != currentDay) {
        closeDay(currentDay);
        currentDay = day;
        save(true);
    }
}

void EnergyStats::update(const Telemetry &t) {
    updateClockAndRollovers();
    const uint64_t nowUs = esp_timer_get_time();
    if (!t.valid || !clockReady) {
        haveSample = false;
        lastSampleUs = nowUs;
        return;
    }

    if (!haveSample) {
        haveSample = true;
        lastSampleUs = nowUs;
        return;
    }

    double dt = (nowUs - lastSampleUs) / 1000000.0;
    lastSampleUs = nowUs;
    if (dt <= 0 || dt > 30.0) return; // do not integrate gaps/restarts

    const double batV = t.batteryVoltage / 10.0;
    const double pvW = t.pv1Power + t.pv2Power;
    const double loadW = t.inverterLoad;
    const double chargeW = batV * max<int16_t>(0, t.chargeCurrent);
    const double dischargeW = batV * max<int16_t>(0, t.dischargeCurrent);
    const double gridW = t.gridPower;

    EnergySet delta;
    delta.pv = pvW * dt / KWH_DIVISOR;
    delta.load = loadW * dt / KWH_DIVISOR;
    delta.charge = chargeW * dt / KWH_DIVISOR;
    delta.discharge = dischargeW * dt / KWH_DIVISOR;
    if (gridW >= 0) delta.gridImport = gridW * dt / KWH_DIVISOR;
    else delta.gridExport = (-gridW) * dt / KWH_DIVISOR;
    add(today, delta);
    add(total, delta);

    struct tm now{};
    if (getLocalTime(&now, 5)) {
        int slot = (now.tm_hour * 60 + now.tm_min) / 5;
        if (slot >= 0 && slot < GRAPH_POINTS) {
            GraphPoint &p = graph[slot];
            p.minute = now.tm_hour * 60 + now.tm_min;
            p.pv = clampPower<uint16_t>(pvW);
            p.load = clampPower<uint16_t>(loadW);
            p.charge = clampPower<uint16_t>(chargeW);
            p.discharge = clampPower<uint16_t>(dischargeW);
            double g = constrain(gridW, -32768.0, 32767.0);
            p.grid = static_cast<int16_t>(g);
            p.valid = 1;
            lastGraphSlot = slot;
        }
    }
    save(false);
}

String EnergyStats::json() const {
    JsonDocument doc;
    doc["time_ready"] = clockReady;
    doc["date"] = String(currentYear) + "-" + String(currentMonth) + "-" + String(currentDay);
    doc["current_year"] = currentYear;
    doc["current_month"] = currentMonth;
    doc["current_day"] = currentDay;

    auto putSet = [](JsonObject o, const EnergySet &e) {
        o["pv"] = e.pv; o["load"] = e.load; o["charge"] = e.charge;
        o["discharge"] = e.discharge; o["grid_import"] = e.gridImport;
        o["grid_export"] = e.gridExport;
    };
    putSet(doc["today"].to<JsonObject>(), today);
    putSet(doc["total"].to<JsonObject>(), total);

    EnergySet month = today;
    for (const DayRecord &d : days) {
        month.pv += d.pv; month.load += d.load; month.charge += d.charge;
        month.discharge += d.discharge; month.gridImport += d.gridImport;
        month.gridExport += d.gridExport;
    }
    putSet(doc["month"].to<JsonObject>(), month);

    JsonArray da = doc["days"].to<JsonArray>();
    for (const DayRecord &d : days) {
        if (!d.day) continue;
        JsonObject o = da.add<JsonObject>();
        o["day"] = d.day; o["pv"] = d.pv; o["load"] = d.load;
        o["charge"] = d.charge; o["discharge"] = d.discharge;
        o["grid_import"] = d.gridImport; o["grid_export"] = d.gridExport;
    }
    // Include the still-open current day so the monthly graph is visible
    // before midnight instead of showing only completed days.
    if (currentDay >= 1 && currentDay <= DAYS_MAX) {
        JsonObject o = da.add<JsonObject>();
        o["day"] = currentDay; o["pv"] = today.pv; o["load"] = today.load;
        o["charge"] = today.charge; o["discharge"] = today.discharge;
        o["grid_import"] = today.gridImport; o["grid_export"] = today.gridExport;
    }

    JsonArray ma = doc["months"].to<JsonArray>();
    for (uint8_t i = 0; i < monthCount; ++i) {
        const MonthRecord &m = months[i];
        JsonObject o = ma.add<JsonObject>();
        o["year"] = m.year; o["month"] = m.month; o["pv"] = m.pv;
        o["load"] = m.load; o["charge"] = m.charge; o["discharge"] = m.discharge;
        o["grid_import"] = m.gridImport; o["grid_export"] = m.gridExport;
    }

    JsonArray ga = doc["graph"].to<JsonArray>();
    for (const GraphPoint &p : graph) {
        if (!p.valid) continue;
        JsonObject o = ga.add<JsonObject>();
        o["m"] = p.minute; o["pv"] = p.pv; o["load"] = p.load;
        o["charge"] = p.charge; o["discharge"] = p.discharge; o["grid"] = p.grid;
    }
    String out; serializeJson(doc, out); return out;
}


void EnergyStats::reset() {
    today = EnergySet{};
    total = EnergySet{};
    memset(days, 0, sizeof(days));
    memset(months, 0, sizeof(months));
    memset(graph, 0, sizeof(graph));
    monthCount = 0;
    lastGraphSlot = -1;
    haveSample = false;
    lastSampleUs = esp_timer_get_time();
    prefs.clear();
    save(true);
}

String EnergyStats::csv() const {
    // UTF-8 BOM + Excel separator hint. Semicolon is required by many
    // regional Excel installations where comma is the decimal separator.
    String out = "\xEF\xBB\xBFsep=;\r\n";
    out += "type;date;pv_kwh;load_kwh;charge_kwh;discharge_kwh;grid_import_kwh;grid_export_kwh\r\n";

    auto number = [](double value) {
        String text(value, 3);
        text.replace('.', ',');
        return text;
    };

    for (const DayRecord &d : days) {
        if (!d.day) continue;
        out += "day;" + String(currentYear) + "-" + String(currentMonth) + "-" + String(d.day) + ";";
        out += number(d.pv) + ";" + number(d.load) + ";" + number(d.charge) + ";";
        out += number(d.discharge) + ";" + number(d.gridImport) + ";" + number(d.gridExport) + "\r\n";
    }
    for (uint8_t i = 0; i < monthCount; ++i) {
        const MonthRecord &m = months[i];
        out += "month;" + String(m.year) + "-" + String(m.month) + ";";
        out += number(m.pv) + ";" + number(m.load) + ";" + number(m.charge) + ";";
        out += number(m.discharge) + ";" + number(m.gridImport) + ";" + number(m.gridExport) + "\r\n";
    }
    return out;
}
