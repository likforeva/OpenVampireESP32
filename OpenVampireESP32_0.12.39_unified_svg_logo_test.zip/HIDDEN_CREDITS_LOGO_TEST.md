# 0.12.36 Hidden credits and logo test

- ESP status text is visually identical to surrounding header text; no underline, color highlight, bold emphasis, tooltip, or pointer cursor.
- Clicking ESP still opens the hidden credits window.
- Reworked the Stonushie initial S as an inline SVG logo with two rails, highlights and sleepers crossing the letter.
- Retains the monthly chart labels-above-bars fix from 0.12.35.
