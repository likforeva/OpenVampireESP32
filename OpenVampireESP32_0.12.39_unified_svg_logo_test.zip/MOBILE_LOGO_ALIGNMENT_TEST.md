# 0.12.38 Mobile logo alignment test

- Enlarged the SVG letter S on narrow screens.
- Vertically aligned the S with the `tonushie` text.
- Preserved the existing rail direction and sleeper geometry.
- Desktop logo layout is unchanged.
