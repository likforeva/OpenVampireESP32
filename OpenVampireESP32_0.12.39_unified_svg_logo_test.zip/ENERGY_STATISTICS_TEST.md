# 0.12.29 Energy Statistics Test

Added autonomous energy statistics without Home Assistant:

- current-day energy totals;
- current-month totals;
- all-time totals;
- current-month daily archive (up to 31 days);
- rolling archive of 24 monthly totals;
- current-day 5-minute power graph;
- CSV export.

Calculated channels:

- PV = PW1 + PW2;
- Load = LOAD;
- Battery charge = BAT × CHR;
- Battery discharge = BAT × DSC;
- Grid import/export are accumulated separately according to the sign of Grid Power.

Statistics begin after NTP time synchronization. Counters are persisted every 15 minutes and at day/month rollover. Detailed 5-minute graph data is kept in RAM and is cleared after ESP32 restart.
