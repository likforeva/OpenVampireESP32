# 0.12.30 Statistics UI Test

- Selectable power graph series: PV, Load, Battery charge, Battery discharge, Grid.
- Any one or several graph series can be displayed simultaneously.
- Statistics page text is bold for improved readability.
- Energy Statistics button moved next to Inverter Type selector.
- Inverter selector shifted slightly left for a more balanced layout.
- Statistics entry removed from the hamburger menu to avoid duplication.
