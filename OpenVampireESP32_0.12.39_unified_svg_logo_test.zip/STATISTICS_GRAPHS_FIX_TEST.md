# 0.12.32 Statistics Graphs Fix Test

- Fixed local time: uses configTzTime so Ukraine summer/winter time is applied.
- Current day is included in the current-month graph before midnight.
- A single available point is now rendered as a visible marker instead of an invisible zero-length line.
- First and last points are marked for easier visual confirmation while a graph is filling after reboot.
