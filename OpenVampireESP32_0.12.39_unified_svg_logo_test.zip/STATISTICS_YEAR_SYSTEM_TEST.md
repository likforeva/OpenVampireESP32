# 0.12.33 Statistics Year & System Test

- Current-month chart changed to daily bars; one selectable energy metric at a time.
- Added annual monthly bar chart with metric and year selection.
- Monthly archive expanded to a rolling 120 months (10 years).
- Added free RAM to the main header.
- Clicking RAM opens detailed heap, flash, Wi-Fi, uptime and firmware information.
