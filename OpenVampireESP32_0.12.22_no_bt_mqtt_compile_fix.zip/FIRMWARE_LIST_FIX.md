# Firmware list parser fix

Version: `0.10.1-fw-list-fix-test`

Changes:

- ESP32 now downloads the firmware catalog with `Accept-Encoding: identity` so a compressed response is not passed to the browser without the proper encoding header.
- HTTP redirects are followed.
- HTTPS is used as an automatic fallback.
- A browser-like User-Agent is sent.
- The firmware catalog is parsed on the ESP32 and returned to the local page as JSON.
- Relative links such as `href="sv_v272.bin"` are converted to complete firmware URLs.
- The updater page no longer attempts to parse the remote HTML itself.
- Errors from the firmware catalog endpoint are displayed on the updater page.
