# Vampire web updater test build

This test adds `/vampire-update`.

- Entering the page stops normal Vampire traffic and disables Bluetooth.
- The official firmware list is proxied from `http://solarvampire.net/FW/fw.htm`.
- Clicking a `.bin` entry downloads the complete file to SPIFFS and validates its ASCII-hex block structure.
- Only after validation does the UPDATE button become available.
- Update sends `ATboot`, waits for a boot banner containing `SN:` plus 8 characters, then sends every record as a 2-byte big-endian length followed by decoded binary payload.
- ACK `0x11` is required after every block. ACK on the last block completes the update.
- The normal-mode button is disabled during active flashing.

This is a test build. Keep stable power on both ESP32 and Vampire during flashing.
