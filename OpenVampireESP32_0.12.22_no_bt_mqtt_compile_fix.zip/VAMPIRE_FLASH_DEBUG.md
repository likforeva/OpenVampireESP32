# 0.12.4 Vampire flash diagnostic

- Version string updated to `0.12.4-vampire-flash-debug`.
- Detailed `ATboot` transmit and raw bootloader receive logging.
- Logs every block length, send completion and ACK byte.
- Timeout messages distinguish missing boot banner from missing block ACK.
- Added a Copy log button to the Vampire update page.
