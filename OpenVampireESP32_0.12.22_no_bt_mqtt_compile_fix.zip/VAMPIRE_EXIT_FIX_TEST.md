# 0.12.17 Vampire exit fix test

- The exit button is blocked only during actual Vampire flashing (boot banner, block transfer, ACK wait).
- Validation no longer prevents leaving the update page.
- The exit request has a 3 second browser timeout and always returns to the main page unless the firmware transfer is actively running.
- Added cache-busting navigation back to the main page.
