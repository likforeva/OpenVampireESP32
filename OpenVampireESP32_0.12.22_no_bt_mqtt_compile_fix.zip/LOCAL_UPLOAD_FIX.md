# Local firmware upload fix

Version: `0.10.3-local-upload-fix-test`

- Keeps the SPIFFS upload file open for the complete multipart upload instead of reopening it for every chunk.
- Flushes and closes the file before validation.
- Adds a 512 KiB size limit and yields during writes.
- Uses XMLHttpRequest with upload progress and clearer connection errors.
