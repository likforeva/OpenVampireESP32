# v17 firmware frame buffering

- UART RX and TX buffers enlarged to 4096 bytes before Serial2.begin().
- This fits the complete first updater frame: 2-byte length + 2066-byte payload.
- Prevents HardwareSerial::write() from blocking while the ESP32 drains the Bluetooth SPP RX queue.
- Added total byte counters beyond the 192-byte diagnostic trace.
- Added logging of the first firmware payload length and Vampire ACK byte 0x11.
- Monitoring application's adaptive text mode retained.
- Firmware boot banner handling from v16 retained.


## v17b
- Fixed premature boot-banner flush after only one UART byte.
- The banner is now considered complete only after `SN:` plus 8 serial characters are collected.
- UART scheduling delays can no longer turn `BVV... SN:...` into a 1-byte Bluetooth packet.


## v18 firmware high-priority pump
- Keeps servicing Bluetooth continuously after the first binary firmware bytes.
- Handles the observed 987 + 987 + 94-byte RFCOMM fragmentation of the 2068-byte first frame.
- Waits for the complete first frame and forwards Vampire ACK 0x11 before returning to the normal loop.
- Uses the existing 4096-byte UART TX buffer.
