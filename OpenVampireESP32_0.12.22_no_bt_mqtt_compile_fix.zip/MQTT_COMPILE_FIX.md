# MQTT compile fix

Version: 0.12.22-no-bt-mqtt-compile-fix

Fixed PubSubClient const-qualification build errors. PubSubClient::connected() is not declared const, so MqttManager::connected() and MqttManager::stateText() are now non-const. MQTT behavior is unchanged.
