# 0.12.19 fuses page and AP timeout test

- Fuses page responses use no-cache and close the HTTP connection after delivery.
- Fuses API requests use cache busting and an AbortController timeout.
- The back button returns directly to a fresh main page rather than browser history.
- The OpenVampire AP is disabled five minutes after a stable router connection.
- If the router connection is later lost, the OpenVampire AP is restored automatically.
