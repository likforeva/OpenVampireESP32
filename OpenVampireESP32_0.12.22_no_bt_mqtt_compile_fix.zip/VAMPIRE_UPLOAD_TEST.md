# Vampire upload diagnostic 0.12.3-test

- Stops Bluetooth/UART telemetry before SPIFFS upload starts.
- Keeps Wi-Fi and WebServer active.
- Logs START, periodic WRITE, END and HTTP completion.
- Firmware validation remains deferred until after HTTP response.
