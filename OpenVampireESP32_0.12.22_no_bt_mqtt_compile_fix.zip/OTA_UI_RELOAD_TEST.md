# 0.12.10 OTA UI reload test

- OTA controls are visibly disabled and non-clickable during upload/reboot.
- File input, Upload and Close remain locked after a successful upload.
- The browser waits 2.5 seconds, then probes the ESP32 every second with cache disabled.
- When the ESP32 is reachable again, the page reloads automatically with a cache-busting URL.
- A 90-second timeout leaves a clear manual-reload message.
