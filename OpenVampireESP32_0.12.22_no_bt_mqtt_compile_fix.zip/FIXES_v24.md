# v24

Based directly on the firmware-transfer implementation from v18, which completed a real Vampire update.

Changes intentionally limited to:

- restore normal bridge/HTTP operation when a Bluetooth firmware session disconnects after binary payload started;
- preserve reconnect only when disconnect happened after ATboot but before payload;
- repeatedly request ATinfo and ATgsets when ESP32 boots before Vampire;
- treat Vampire AT+NAME startup command as a full resynchronization trigger.

The v18 firmware pump itself is unchanged.
