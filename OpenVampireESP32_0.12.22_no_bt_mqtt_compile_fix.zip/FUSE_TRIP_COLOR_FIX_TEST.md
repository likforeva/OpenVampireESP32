# Fuse trip color fix test

Version: 0.12.16-fuse-trip-color-fix-test

When a fuse condition is active, the real value, comparison symbol and configured limit are all shown in red and bold. Disabled fuses remain gray.
