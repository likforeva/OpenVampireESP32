# Telemetry parser test build

Base: `OpenVampireESP32_v24_wifi_save_fixed(1).zip`.

Changes:

- implemented parsing of all three `ATtrans` frame variants (`extpr=0/1/2`);
- validates the two-digit hexadecimal checksum;
- parses PV1/PV2 voltage, battery voltage/SOC, charge/discharge current,
  inverter load, regulator output, PV currents, and signed grid power;
- calculates PV power from voltage × PV current when the extended fields exist;
- removed the unnecessary second `ATtrans` command after the one-time JSON ACK;
- prevents continuous telemetry frames from flooding the web debug log;
- added `pv1_current` and `pv2_current` to `/api/trans` JSON;
- firmware version: `0.9.1-telemetry-test`.

The project was not compiled in this environment because PlatformIO is not installed.
