# 0.12.12 Wi-Fi LED test

Onboard blue LED is configured on GPIO2.

Normal indication:
- not connected to the configured Wi-Fi router: LED is continuously on;
- connected and idle: LED is off;
- HTTP/OTA network activity: short flash.

Update indication:
- Vampire firmware update: fast blink (200 ms phases);
- ESP32 OTA update: very fast blink (100 ms phases).

The implementation is non-blocking and does not use delays or interrupts.
To use another GPIO, change `WIFI_LED_PIN` in `include/Config.h`.
If the LED logic is inverted, change `WIFI_LED_ACTIVE_LOW` from 0 to 1.
