# WiFi settings save fix

Changed files:

- `src/main.cpp`
  - validates JSON and non-empty SSID;
  - saves credentials through `WifiManager`;
  - returns a JSON success/error response;
  - schedules a delayed ESP32 restart after the HTTP response is sent.

- `include/index_html.h`
  - validates SSID in the browser;
  - checks the HTTP response instead of always reporting success;
  - shows an error when saving fails;
  - informs the user that ESP32 will restart after a successful save.

Expected behavior:

1. Connect to the `OpenVampire` access point.
2. Open the web interface and save the router SSID/password.
3. ESP32 restarts automatically.
4. During the next boot, `wifi.begin()` loads the saved credentials and `wifi.connect()` connects to the router.
5. The `OpenVampire` access point remains available because the firmware uses `WIFI_AP_STA` mode.
