# OpenVampireESP32 0.11.1

- Исправлена ошибка компиляции: добавлена функция `jsonEscape()` до первого использования в `main.cpp`.
- Ошибки локальной загрузки Vampire теперь безопасно экранируются в JSON.

# OpenVampireESP32 0.11.0

## Изменено

- Удалено обновление Vampire через Bluetooth.
- Из BTBridge удалены boot-banner, ATboot, повторное подключение и восстановление режима прошивки.
- Bluetooth оставлен для совместимости с Android-приложением управления.
- Удалены загрузка и проксирование прошивок с solarvampire.net.
- Удалены HTTPClient и WiFiClientSecure из обновляющего модуля.
- Страница обновления Vampire теперь работает только с локальным `.bin`.
- Добавлена отдельная кнопка открытия официальной страницы прошивок.
- OTA-обновление самой ESP32 сохранено.

## Сохранено

- Телеметрия и настройки Vampire.
- Настройки защит (Fuses).
- Wi-Fi AP/STA.
- Bluetooth-мост для Android-приложения.
- Браузерное OTA ESP32.
- Локальное обновление Vampire через браузер.


## 0.12.0 update transport stability
- Vampire page opening and local file upload no longer enter UART maintenance mode.
- Vampire maintenance begins only after pressing the actual update button.
- Vampire blocks are transmitted in 128-byte cooperative steps so the web server remains serviced.
- ESP32 OTA now checks available OTA partition space, yields after flash writes, records detailed serial errors, and uses a 120 second browser timeout.
- Added OTA free-heap and upload diagnostics to Serial.


## 0.12.1 OTA begin fix
- OTA now uses `Update.begin(UPDATE_SIZE_UNKNOWN, U_FLASH)` instead of preparing the whole OTA partition at upload start.
- Added diagnostics before and after `Update.begin()`.
- Added 64 KiB write progress diagnostics.
