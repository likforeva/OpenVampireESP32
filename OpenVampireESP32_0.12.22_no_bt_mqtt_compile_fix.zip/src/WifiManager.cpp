#include "WifiManager.h"
#include <Preferences.h>
#include <WiFi.h>

Preferences prefs;

void WifiManager::begin()
{
    prefs.begin("wifi", false);

    _ssid = prefs.getString("ssid", "");
    _password = prefs.getString("pass", "");
}

bool WifiManager::hasCredentials()
{
    return _ssid.length() > 0;
}

void WifiManager::saveCredentials(const String &ssid,
                                  const String &password)
{
    _ssid = ssid;
    _password = password;

    prefs.putString("ssid", ssid);
    prefs.putString("pass", password);
}

String WifiManager::getSSID()
{
    return _ssid;
}

String WifiManager::getPassword()
{
    return _password;
}
bool WifiManager::connect()
{
    if (_ssid.isEmpty())
        return false;

    Serial.println("Connecting to WiFi...");
    Serial.println(_ssid);

    WiFi.begin(_ssid.c_str(), _password.c_str());

    unsigned long start = millis();

    while (WiFi.status() != WL_CONNECTED)
    {
        delay(500);
        Serial.print(".");

        if (millis() - start > 20000)
        {
            Serial.println();
            Serial.println("WiFi connection timeout");
            return false;
        }
    }

    Serial.println();
    Serial.println("WiFi connected");
    Serial.print("IP: ");
    Serial.println(WiFi.localIP());

    return true;
}

bool WifiManager::isConnected()
{
    return WiFi.status() == WL_CONNECTED;
}