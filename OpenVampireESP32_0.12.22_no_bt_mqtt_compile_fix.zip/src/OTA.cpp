#include "OTA.h"

#include <WiFi.h>
#include <Update.h>
#include "BTBridge.h"
#include "StatusLed.h"

extern bool vampireMaintenanceMode;

namespace {
bool otaUploadStarted = false;
bool otaUploadFailed = false;
String otaUploadError;

void setOtaError(const String &message)
{
    otaUploadFailed = true;
    otaUploadError = message;
    Serial.println("[OTA] ERROR: " + message);
}
}

OTA::OTA(WebServer &server)
{
    _server = &server;
}

void OTA::begin()
{
    _server->on("/update", HTTP_GET, [this]() { handlePage(); });

    _server->on("/update", HTTP_POST,
    [this]()
    {
        const bool ok = otaUploadStarted && !otaUploadFailed && !Update.hasError();
        const String message = ok ? "Firmware received. ESP32 is rebooting."
                                  : (otaUploadError.length() ? otaUploadError : "Firmware update failed.");

        _server->sendHeader("Connection", "close");
        _server->send(ok ? 200 : 500,
                      "application/json",
                      String("{\"ok\":") + (ok ? "true" : "false") +
                      ",\"message\":\"" + message + "\"}");

        if (!ok)
            statusLed.setMode(StatusLedMode::Normal);

        if (ok)
        {
            Serial.println("[OTA] HTTP response sent; restart scheduled");
            delay(250);
            ESP.restart();
        }
    },
    [this]() { handleUpload(); });
}

void OTA::handlePage()
{
    statusLed.activity();
    const char *page = R"rawliteral(
<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>OpenVampire OTA</title><style>
body{font-family:Arial,sans-serif;background:#202124;color:white;padding:30px;max-width:620px;margin:auto}.card{background:#2b2d31;padding:24px;border-radius:12px}input{margin:18px 0;width:100%}button{padding:12px 25px;font-size:18px}button:disabled{opacity:.45;cursor:not-allowed;pointer-events:none}input:disabled{opacity:.55;cursor:not-allowed}.progressWrap{display:none;margin-top:18px}.progressOuter{height:22px;background:#111;border-radius:11px;overflow:hidden}.progressBar{height:100%;width:0;background:#43a047}.progressText{margin-top:8px;text-align:center}.result{display:none;margin-top:18px;padding:14px;border-radius:8px;background:#17181b}
</style></head><body><div class="card"><h2>OpenVampire ESP32</h2><h3>Firmware Update</h3>
<input id="file" type="file" accept=".bin,application/octet-stream"><button id="uploadBtn" disabled>Upload</button>
<div id="progressWrap" class="progressWrap"><div class="progressOuter"><div id="progressBar" class="progressBar"></div></div><div id="progressText" class="progressText">0%</div></div><div id="result" class="result"></div></div>
<script>
const btn=document.getElementById('uploadBtn');
function setProgress(v){const p=Math.max(0,Math.min(100,Math.round(v)));document.getElementById('progressBar').style.width=p+'%';document.getElementById('progressText').textContent=p+'%'}
function showResult(m,ok){const e=document.getElementById('result');e.style.display='block';e.textContent=m;e.style.border='1px solid '+(ok?'#43a047':'#e53935')}
const file=document.getElementById('file');let active=false;file.addEventListener('change',()=>{if(!active)btn.disabled=!file.files.length});function lock(v){active=v;file.disabled=v;btn.disabled=v||!file.files.length;btn.textContent=v?'Uploading...':'Upload'}btn.addEventListener('click',()=>{if(active)return;const f=file.files[0];if(!f){alert('Select firmware.bin');return;}lock(true);document.getElementById('progressWrap').style.display='block';document.getElementById('result').style.display='none';setProgress(0);const d=new FormData();d.append('update',f);const x=new XMLHttpRequest();x.open('POST','/update',true);x.timeout=120000;x.upload.onprogress=e=>{if(e.lengthComputable)setProgress(e.loaded*100/e.total)};x.onload=()=>{let r={};try{r=JSON.parse(x.responseText||'{}')}catch(e){}if(x.status>=200&&x.status<300&&r.ok){setProgress(100);showResult(r.message||'Firmware updated. ESP32 is rebooting...',true);waitForEsp()}else{lock(false);showResult(r.message||('Update failed. HTTP '+x.status),false)}};x.onerror=()=>{lock(false);showResult('Connection error during firmware update.',false)};x.ontimeout=()=>{lock(false);showResult('Firmware upload timeout.',false)};x.onabort=()=>{lock(false);showResult('Firmware upload was aborted.',false)};x.send(d)});

async function waitForEsp(){await new Promise(r=>setTimeout(r,2500));const started=Date.now();while(active){try{const r=await fetch('/?ota_probe='+Date.now(),{cache:'no-store',headers:{'Cache-Control':'no-cache'}});if(r.ok){showResult('ESP32 is online. Reloading page...',true);await new Promise(x=>setTimeout(x,500));location.replace('/update?ota_done='+Date.now());return}}catch(e){}if(Date.now()-started>90000){showResult('Firmware was installed, but automatic reconnect timed out. Reload the page manually.',false);active=false;return}await new Promise(r=>setTimeout(r,1000))}}
</script></body></html>)rawliteral";
    _server->send(200, "text/html", page);
}

void OTA::handleUpload()
{
    statusLed.activity(120);
    HTTPUpload &upload = _server->upload();

    switch (upload.status)
    {
        case UPLOAD_FILE_START:
        {
            otaUploadStarted = true;
            statusLed.setMode(StatusLedMode::EspOta);
            otaUploadFailed = false;
            otaUploadError = "";
            Serial.printf("[OTA] Start: %s, free heap: %u\n", upload.filename.c_str(), ESP.getFreeHeap());

            // Put the firmware into a quiet maintenance state before any flash
            // erase/write begins. Classic Bluetooth is memory-heavy and can
            // continue scheduling work while flash cache is temporarily disabled.
            vampireMaintenanceMode = true;
            btBridge.disable();
            WiFi.setSleep(false);

            // The upload arrives through STA (192.168.x.x). Disable the local AP
            // to reduce radio/task load, but keep the STA connection alive.
            if (WiFi.getMode() == WIFI_AP_STA)
            {
                WiFi.softAPdisconnect(true);
                WiFi.mode(WIFI_STA);
            }

            delay(20);
            Serial.printf("[OTA] Maintenance mode active, heap: %u, RSSI: %d\n",
                          ESP.getFreeHeap(), WiFi.RSSI());

            const uint32_t freeSketchSpace = ESP.getFreeSketchSpace();
            Serial.printf("[OTA] Free sketch space: %u bytes\n", freeSketchSpace);

            // Do not pass the complete OTA partition size here. On some ESP32
            // core/flash combinations Update.begin(partitionSize) can spend a long
            // time preparing/erasing the partition before the HTTP handler gets a
            // chance to service TCP. The browser then stalls part-way through the
            // upload even though no firmware bytes have been processed yet.
            // UPDATE_SIZE_UNKNOWN lets Update erase/write sectors incrementally.
            Serial.println("[OTA] Calling Update.begin(UPDATE_SIZE_UNKNOWN)...");
            if (freeSketchSpace < 0x20000 || !Update.begin(UPDATE_SIZE_UNKNOWN, U_FLASH))
            {
                Update.printError(Serial);
                setOtaError("Unable to start OTA update. Check OTA partition size.");
            }
            else
            {
                Serial.printf("[OTA] Update.begin OK, free heap: %u\n", ESP.getFreeHeap());
            }
            delay(0);
            break;
        }

        case UPLOAD_FILE_WRITE:
            if (!otaUploadFailed)
            {
                const size_t written = Update.write(upload.buf, upload.currentSize);
                if (written != upload.currentSize)
                {
                    Update.printError(Serial);
                    setOtaError("Flash write failed during OTA.");
                }
            }
            yield();
            break;

        case UPLOAD_FILE_END:
            if (!otaUploadFailed)
            {
                if (!Update.end(true))
                {
                    Update.printError(Serial);
                    setOtaError("OTA finalization failed.");
                }
                else
                {
                    Serial.printf("[OTA] Success: %u bytes, free heap: %u\n", upload.totalSize, ESP.getFreeHeap());
                }
            }
            yield();
            break;

        case UPLOAD_FILE_ABORTED:
            Update.abort();
            setOtaError("OTA upload was aborted.");
            yield();
            break;

        default:
            break;
    }
}
