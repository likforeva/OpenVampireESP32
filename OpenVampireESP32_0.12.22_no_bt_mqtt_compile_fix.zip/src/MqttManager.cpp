#include "MqttManager.h"
#include <WiFi.h>
#include <ArduinoJson.h>

MqttManager::MqttManager() : client(wifiClient)
{
}

void MqttManager::begin()
{
    load();
    client.setBufferSize(768);
    client.setKeepAlive(20);
    client.setSocketTimeout(2);
}

void MqttManager::load()
{
    prefs.begin("mqtt", true);
    cfg.enabled = prefs.getBool("enabled", false);
    cfg.host = prefs.getString("host", "");
    cfg.port = prefs.getUShort("port", 1883);
    cfg.user = prefs.getString("user", "");
    cfg.password = prefs.getString("pass", "");
    cfg.periodSeconds = prefs.getUShort("period", 10);
    prefs.end();
}

void MqttManager::save(const MqttConfig &newConfig)
{
    const bool reconnectRequired =
        cfg.host != newConfig.host ||
        cfg.port != newConfig.port ||
        cfg.user != newConfig.user ||
        cfg.password != newConfig.password ||
        cfg.enabled != newConfig.enabled;

    cfg = newConfig;

    prefs.begin("mqtt", false);
    prefs.putBool("enabled", cfg.enabled);
    prefs.putString("host", cfg.host);
    prefs.putUShort("port", cfg.port);
    prefs.putString("user", cfg.user);
    prefs.putString("pass", cfg.password);
    prefs.putUShort("period", cfg.periodSeconds);
    prefs.end();

    if (reconnectRequired && client.connected())
        client.disconnect();

    lastConnectAttempt = 0;
    lastPublish = 0;
}

void MqttManager::pause(bool paused)
{
    isPaused = paused;
    if (paused && client.connected())
        client.disconnect();
}

String MqttManager::topicFor(const String &serialNumber) const
{
    String sn = serialNumber;
    if (sn.isEmpty())
        sn = "UNKNOWN";
    return "tele/VAMPIRE/SV-" + sn + "/STATE";
}

bool MqttManager::connect(const String &serialNumber)
{
    if (cfg.host.isEmpty())
        return false;

    client.setServer(cfg.host.c_str(), cfg.port);

    String clientId = "OpenVampire-" + serialNumber;
    if (clientId.endsWith("-"))
        clientId += String((uint32_t)ESP.getEfuseMac(), HEX);

    if (cfg.user.isEmpty())
        return client.connect(clientId.c_str());

    return client.connect(clientId.c_str(), cfg.user.c_str(), cfg.password.c_str());
}

void MqttManager::publishTelemetry(const Telemetry &t, const String &serialNumber)
{
    JsonDocument doc;

    const float pv1Current = t.pv1Current / 10.0f;
    const float pv2Current = t.pv2Current / 10.0f;
    const float batteryVoltage = t.batteryVoltage / 10.0f;

    doc["PV1"] = t.pv1Voltage;
    doc["PV2"] = t.pv2Voltage;
    doc["PC1"] = pv1Current;
    doc["PC2"] = pv2Current;
    doc["PW1"] = (float)t.pv1Voltage * pv1Current;
    doc["PW2"] = (float)t.pv2Voltage * pv2Current;
    doc["BAT"] = batteryVoltage;
    doc["SOC"] = t.batterySOC;
    doc["CHR"] = t.chargeCurrent;
    doc["DSC"] = t.dischargeCurrent;
    doc["LOAD"] = t.inverterLoad;
    doc["OUT"] = t.regulatorOutput;

    char payload[512];
    const size_t length = serializeJson(doc, payload, sizeof(payload));
    client.publish(topicFor(serialNumber).c_str(), reinterpret_cast<const uint8_t *>(payload), length, false);
}

void MqttManager::update(const Telemetry &telemetry, const String &serialNumber)
{
    if (!cfg.enabled || isPaused || WiFi.status() != WL_CONNECTED)
    {
        if (client.connected())
            client.disconnect();
        return;
    }

    if (!client.connected())
    {
        if ((uint32_t)(millis() - lastConnectAttempt) < 10000)
            return;

        lastConnectAttempt = millis();
        if (!connect(serialNumber))
            return;
    }

    client.loop();

    if (!telemetry.valid)
        return;

    const uint32_t periodMs =
        (cfg.periodSeconds == 0 ? 60UL : (uint32_t)cfg.periodSeconds) * 1000UL;

    if ((uint32_t)(millis() - lastPublish) < periodMs)
        return;

    lastPublish = millis();
    publishTelemetry(telemetry, serialNumber);
}

String MqttManager::stateText()
{
    if (!cfg.enabled)
        return "disabled";
    if (isPaused)
        return "paused";
    if (WiFi.status() != WL_CONNECTED)
        return "wifi_offline";
    if (cfg.host.isEmpty())
        return "not_configured";
    return client.connected() ? "connected" : "disconnected";
}
