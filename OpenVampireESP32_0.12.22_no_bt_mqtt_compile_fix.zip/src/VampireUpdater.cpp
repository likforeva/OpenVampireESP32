#include "VampireUpdater.h"
#include <ArduinoJson.h>
#include <SPIFFS.h>

static const char *FW_PATH = "/vampire_fw.bin";
static const uint32_t BANNER_TIMEOUT_MS = 8000;
static const uint32_t ACK_TIMEOUT_MS = 5000;
static const uint32_t PROGRESS_LOG_INTERVAL_MS = 1000;

VampireUpdater::VampireUpdater(HardwareSerial &serial) : _serial(&serial) {}

void VampireUpdater::begin() { SPIFFS.begin(true); }

void VampireUpdater::addLog(const String &line) {
    if (!_log.isEmpty()) _log += '\n';
    _log += line;
    if (_log.length() > 7000) _log.remove(0, _log.length() - 7000);
    Serial.println("[VampireUpdater] " + line);
}

int VampireUpdater::hexValue(char c) const {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

bool VampireUpdater::readHexByte(uint8_t &value) {
    int a = _file.read(), b = _file.read();
    if (a < 0 || b < 0) return false;
    int hi = hexValue((char)a), lo = hexValue((char)b);
    if (hi < 0 || lo < 0) return false;
    value = (uint8_t)((hi << 4) | lo);
    _asciiRead += 2;
    return true;
}

bool VampireUpdater::readHexWord(uint16_t &value) {
    char h[4];
    if (_file.readBytes(h, 4) != 4) return false;
    int a=hexValue(h[0]), b=hexValue(h[1]), c=hexValue(h[2]), d=hexValue(h[3]);
    if (a<0||b<0||c<0||d<0) return false;
    value = (uint16_t)((a<<12)|(b<<8)|(c<<4)|d);
    _asciiRead += 4;
    return true;
}

bool VampireUpdater::validateFile(String &error) {
    File f = SPIFFS.open(FW_PATH, FILE_READ);
    if (!f || f.size() < 8) { error = "Firmware file is empty or unavailable."; return false; }
    uint32_t pos = 0; uint16_t blocks = 0;
    while (pos < f.size()) {
        char h[4];
        if (f.readBytes(h, 4) != 4) { error = "Incomplete block length at end of file."; f.close(); return false; }
        pos += 4;
        uint16_t n = 0;
        for (int i=0;i<4;i++) { int v=hexValue(h[i]); if(v<0){error="Invalid hexadecimal block length.";f.close();return false;} n=(n<<4)|v; }
        if (n == 0 || pos + (uint32_t)n * 2 > f.size()) { error = "Invalid or truncated firmware block."; f.close(); return false; }
        for (uint32_t i=0;i<(uint32_t)n*2;i++) {
            int c=f.read();
            if(c<0||hexValue((char)c)<0){error="Firmware contains non-hexadecimal data.";f.close();return false;}
            if ((i & 0x3FFu) == 0) yield();
        }
        pos += (uint32_t)n * 2; blocks++;
    }
    f.close();
    if (pos != _fileSize || blocks == 0) { error = "Firmware structure is invalid."; return false; }
    _blockCount = blocks;
    return true;
}


bool VampireUpdater::beginLocalUpload(const String &filename, String &error) {
    reset();
    SPIFFS.remove(FW_PATH);
    _uploadFile = SPIFFS.open(FW_PATH, FILE_WRITE);
    if (!_uploadFile) {
        error = "Unable to create firmware file in flash.";
        fail(error);
        return false;
    }
    _selectedVersion = filename.length() ? filename : "local firmware";
    _fileSize = 0;
    _localUploadActive = true;
    addLog("Selected local firmware: " + _selectedVersion);
    addLog("Uploading firmware file...");
    return true;
}

bool VampireUpdater::writeLocalUpload(const uint8_t *data, size_t length, String &error) {
    if (!_localUploadActive || !_uploadFile) {
        error = "Local upload was not started.";
        return false;
    }

    // The Vampire ASCII-HEX images are small, but reject an unexpectedly large
    // upload before it can exhaust the SPIFFS partition.
    static const size_t MAX_LOCAL_FW_SIZE = 512 * 1024;
    if (_fileSize + length > MAX_LOCAL_FW_SIZE) {
        error = "Firmware file is too large (maximum 512 KiB).";
        _uploadFile.close();
        _localUploadActive = false;
        fail(error);
        return false;
    }

    const size_t written = _uploadFile.write(data, length);
    if (written != length) {
        error = "Flash write error.";
        _uploadFile.close();
        _localUploadActive = false;
        fail(error);
        return false;
    }
    _fileSize += written;
    yield();
    return true;
}

bool VampireUpdater::finishLocalUpload(String &error) {
    if (!_localUploadActive) {
        error = "Local upload was not started.";
        return false;
    }
    _localUploadActive = false;
    if (_uploadFile) {
        _uploadFile.flush();
        _uploadFile.close();
    }

    addLog("Firmware uploaded: " + String(_fileSize) + " bytes.");
    addLog("Upload completed. Checking firmware structure...");

    // Do not validate the complete image inside WebServer's upload callback.
    // The browser has already sent 100%, but the HTTP response is still pending;
    // a long SPIFFS scan here can make mobile browsers report a broken connection.
    // Validation is deferred to update(), after the response has been returned.
    _state = State::VALIDATING;
    return true;
}

bool VampireUpdater::start(String &error) {
    if(_state != State::READY){error="Firmware is not ready.";return false;}
    while(_serial->available()) _serial->read();
    addLog("Starting Vampire update: " + String(_blockCount) + " blocks, " + String(_fileSize) + " bytes ASCII-HEX.");
    addLog("UART: 38400 baud. Clearing receive buffer...");
    _serial->print("ATboot\r");
    _serial->flush();
    addLog("TX: ATboot\r");
    addLog("Waiting up to " + String(BANNER_TIMEOUT_MS) + " ms for bootloader banner containing SN:...");
    _banner=""; _state=State::WAIT_BANNER; _stateSince=millis(); return true;
}

void VampireUpdater::fail(const String &message){ _error=message; addLog("ERROR: " + message); _state=State::ERROR; if(_file) _file.close(); }

void VampireUpdater::update() {
    if (_state == State::VALIDATING) {
        String error;
        if (!validateFile(error)) {
            fail(error);
            return;
        }
        addLog("Firmware OK. " + String(_blockCount) + " blocks detected.");
        addLog("Ready for update.");
        _state = State::READY;
        return;
    }
    if(_state==State::WAIT_BANNER){
        while(_serial->available()){
            uint8_t raw=(uint8_t)_serial->read();
            char c=(char)raw;
            if(_banner.length()<256) _banner+=c;
            Serial.printf("[VampireUpdater] BOOT RX: 0x%02X", raw);
            if(raw >= 32 && raw <= 126) Serial.printf(" ('%c')", c);
            Serial.println();
        }
        int p=_banner.indexOf("SN:");
        if(p>=0 && _banner.length() >= (size_t)(p+11)){
            String bootId = _banner.substring(p, min((size_t)(p + 11), _banner.length()));
            addLog("Bootloader banner detected: " + bootId);
            addLog("Opening firmware and preparing block 1/" + String(_blockCount) + "...");
            _file=SPIFFS.open(FW_PATH, FILE_READ); if(!_file){fail("Unable to reopen firmware file.");return;}
            _asciiRead=0; _blockIndex=0; _state=State::SENDING;
        } else if(millis()-_stateSince>BANNER_TIMEOUT_MS) {
            String printable;
            for(size_t i=0;i<_banner.length();i++){
                uint8_t c=(uint8_t)_banner[i];
                if(c>=32 && c<=126) printable+=(char)c;
                else { char b[7]; snprintf(b,sizeof(b),"<%02X>",c); printable+=b; }
            }
            if(printable.length()) addLog("Received before timeout: " + printable);
            else addLog("No bytes received from Vampire after ATboot.");
            fail("Timeout waiting for bootloader greeting.");
        }
    }
    if(_state==State::SENDING){
        // Send only a small piece per loop iteration. This keeps Wi-Fi, the web
        // status endpoint and the task watchdog alive even for large blocks.
        if(!_blockHeaderSent){
            if(!_file.available()) { fail("Unexpected end of firmware file."); return; }
            if(!readHexWord(_blockLength)){fail("Cannot read block length.");return;}
            if(_blockLength == 0){fail("Firmware block has zero length.");return;}
            addLog("Block " + String(_blockIndex + 1) + "/" + String(_blockCount) + ": length=" + String(_blockLength) + " bytes, sending...");
            uint8_t len[2]={(uint8_t)(_blockLength>>8),(uint8_t)_blockLength};
            if(_serial->write(len,2) != 2){fail("Unable to send block length.");return;}
            _blockBytesRemaining=_blockLength;
            _blockHeaderSent=true;
        }

        uint8_t buf[128];
        const size_t chunk=min((uint16_t)sizeof(buf),_blockBytesRemaining);
        for(size_t i=0;i<chunk;i++){
            if(!readHexByte(buf[i])){fail("Cannot decode firmware payload.");return;}
        }
        if(chunk && _serial->write(buf,chunk) != chunk){fail("UART write failed.");return;}
        _blockBytesRemaining -= chunk;
        yield();

        if(_blockBytesRemaining == 0){
            _serial->flush();
            _blockHeaderSent=false;
            _blockIndex++;
            addLog("Block " + String(_blockIndex) + "/" + String(_blockCount) + " sent. Waiting for OK...");
            _state=State::WAIT_ACK;
            _stateSince=millis();
        }
        return;
    }
    if(_state==State::WAIT_ACK){
        while(_serial->available()){
            uint8_t c=(uint8_t)_serial->read();
            Serial.printf("[VampireUpdater] ACK RX for block %u: 0x%02X\n", _blockIndex, c);
            if(c==0x11){ addLog("Block " + String(_blockIndex) + "/" + String(_blockCount) + " ACK 0x11 OK.");
                if(_blockIndex>=_blockCount){ _file.close(); addLog("Firmware update completed successfully."); _state=State::SUCCESS; }
                else _state=State::SENDING;
                return;
            }
        }
        if(millis()-_stateSince>ACK_TIMEOUT_MS) {
            fail("Timeout waiting for ACK 0x11 on block " + String(_blockIndex) + ".");
        }
    }
}

void VampireUpdater::reset(){ if(_file) _file.close(); if(_uploadFile) _uploadFile.close(); _localUploadActive=false; _blockBytesRemaining=0; _blockHeaderSent=false; _state=State::IDLE; _log=""; _error=""; _selectedVersion=""; _fileSize=0; _blockCount=0; _blockIndex=0; _banner=""; }
bool VampireUpdater::busy() const { return _state==State::VALIDATING||_state==State::WAIT_BANNER||_state==State::SENDING||_state==State::WAIT_ACK; }
bool VampireUpdater::flashing() const { return _state==State::WAIT_BANNER||_state==State::SENDING||_state==State::WAIT_ACK; }
bool VampireUpdater::ready() const { return _state==State::READY; }
bool VampireUpdater::finished() const { return _state==State::SUCCESS||_state==State::ERROR; }
String VampireUpdater::stateName() const { switch(_state){case State::IDLE:return"idle";case State::VALIDATING:return"validating";case State::READY:return"ready";case State::WAIT_BANNER:return"wait_banner";case State::SENDING:return"sending";case State::WAIT_ACK:return"wait_ack";case State::SUCCESS:return"success";case State::ERROR:return"error";} return"unknown"; }
String VampireUpdater::statusJson() const { JsonDocument d; d["state"]=stateName(); d["ready"]=ready(); d["busy"]=busy(); d["flashing"]=flashing(); d["success"]=_state==State::SUCCESS; d["error"]=_error; d["log"]=_log; d["version"]=_selectedVersion; d["block"]=_blockIndex; d["blocks"]=_blockCount; d["progress"]=_blockCount?(_blockIndex*100/_blockCount):0; String o; serializeJson(d,o); return o; }
