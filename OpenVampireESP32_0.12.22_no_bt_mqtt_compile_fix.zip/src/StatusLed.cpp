#include "StatusLed.h"

#include <WiFi.h>
#include "Config.h"

StatusLed statusLed;

void StatusLed::begin()
{
    pinMode(WIFI_LED_PIN, OUTPUT);
    _initialized = true;
    _lastOutput = true;
    write(false);
}

void StatusLed::write(bool on)
{
    if (!_initialized)
        return;

    if (on == _lastOutput)
        return;

    _lastOutput = on;
    digitalWrite(WIFI_LED_PIN,
                 WIFI_LED_ACTIVE_LOW ? (on ? LOW : HIGH)
                                     : (on ? HIGH : LOW));
}

void StatusLed::activity(uint32_t durationMs)
{
    const uint32_t until = millis() + durationMs;
    if ((int32_t)(until - _activityUntil) > 0)
        _activityUntil = until;
}

void StatusLed::setMode(StatusLedMode mode)
{
    _mode = mode;
}

void StatusLed::update()
{
    const uint32_t now = millis();
    bool on = false;

    switch (_mode)
    {
        case StatusLedMode::EspOta:
            // 100 ms on / 100 ms off.
            on = ((now / 100U) & 1U) == 0U;
            break;

        case StatusLedMode::VampireUpdate:
            // 200 ms on / 200 ms off.
            on = ((now / 200U) & 1U) == 0U;
            break;

        case StatusLedMode::Normal:
        default:
            if (WiFi.status() != WL_CONNECTED)
            {
                // Not connected to the configured router: steady light.
                on = true;
            }
            else
            {
                // Connected and idle: off. Network activity creates a short flash.
                on = (int32_t)(now - _activityUntil) < 0;
            }
            break;
    }

    write(on);
}
