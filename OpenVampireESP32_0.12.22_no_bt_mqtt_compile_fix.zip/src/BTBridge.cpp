#include "BTBridge.h"

BTBridge btBridge;

void BTBridge::begin() {}
void BTBridge::enable() {}
void BTBridge::disable() {}
void BTBridge::restart() {}
void BTBridge::update() {}

void BTBridge::setDeviceName(const String &name)
{
    if (!name.isEmpty())
        deviceName = name;
}

const String &BTBridge::getDeviceName() const
{
    return deviceName;
}

bool BTBridge::enabled() const
{
    return false;
}

bool BTBridge::isConnected() const
{
    return false;
}

void BTBridge::writeFromVampire(uint8_t value)
{
    (void)value;
}
