#include "DebugLog.h"

DebugLog debugLog;

////////////////////////////////////////////////////////

void DebugLog::add(const String &text)
{
    buffer += text;
    buffer += "\n";

    if(buffer.length() > MAX_SIZE)
    {
        buffer.remove(0, buffer.length() - MAX_SIZE);
    }
}

////////////////////////////////////////////////////////

String DebugLog::get() const
{
    return buffer;
}

////////////////////////////////////////////////////////

void DebugLog::clear()
{
    buffer = "";
}