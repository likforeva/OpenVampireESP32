#include "Vampire.h"
#include "DebugLog.h"
#include "BTBridge.h"

////////////////////////////////////////////////////////
// Constructor
////////////////////////////////////////////////////////

Vampire::Vampire(HardwareSerial &serial)
{
    _serial = &serial;

    fw = "";
    sn = "";

    rxBuffer = "";

    lastInfoRequest = 0;

    settings.valid = false;
    telemetry.valid = false;
    memset(lastSentP, 0, sizeof(lastSentP));
}

////////////////////////////////////////////////////////
// UART
////////////////////////////////////////////////////////

void Vampire::begin()
{
    // The updater sends a complete first firmware frame of 2068 binary bytes
    // (2-byte length + 2066-byte payload) without waiting between bytes.
    // The default ESP32 UART TX buffer is too small: HardwareSerial::write()
    // then blocks for hundreds of milliseconds and the Bluetooth SPP receive
    // queue can overflow/disconnect. Keep a buffer larger than the largest
    // known updater frame so Bluetooth can be drained immediately while UART
    // shifts the frame out at 38400 baud in the background.
    _serial->setRxBufferSize(4096);
    _serial->setTxBufferSize(4096);

    _serial->begin(
        VAMPIRE_BAUD,
        SERIAL_8N1,
        VAMPIRE_RX_PIN,
        VAMPIRE_TX_PIN
    );

    debugLog.add("UART started (38400), RX/TX buffers = 4096");
}

////////////////////////////////////////////////////////
// Send command
////////////////////////////////////////////////////////

bool Vampire::sendCommand(const String &cmd)
{
    if (bridgeModeEnabled)
    {
        debugLog.add("ESP command blocked during Bluetooth bridge: " + cmd);
        return false;
    }

    _serial->print(cmd);
    _serial->print('\r');

    debugLog.add(">> " + cmd);

    return true;
}

////////////////////////////////////////////////////////
// Main update
////////////////////////////////////////////////////////

void Vampire::update()
{
   
    while (_serial->available())
    {
        char c = _serial->read();
        lastRxByteAt = millis();

        // UART is parsed only while Bluetooth is disconnected. During an
        // active Bluetooth session BTBridge owns Serial2 as a raw binary link.
        Serial.print(c);

        if (c == '\r')
            continue;

        if (c == '\n')
        {
            if (rxBuffer.length())
            {
                processLine(rxBuffer);
                rxBuffer = "";
            }
        }
        else
        {
            // During a Vampire firmware update the stream can be binary and
            // may contain no line endings. Never let the optional text parser
            // consume unbounded RAM; forwarding to Bluetooth is unaffected.
            if (rxBuffer.length() < 512)
                rxBuffer += c;
            else
                rxBuffer = "";
        }
    }

    // HC-06 configuration commands are often emitted without a line ending.
    // Process only recognizable module commands after a short idle gap; normal
    // protocol frames continue to wait for their newline.
    if (!rxBuffer.isEmpty() && millis() - lastRxByteAt >= 25 &&
        (rxBuffer == "AT" || rxBuffer.indexOf("AT+") >= 0))
    {
        processLine(rxBuffer);
        rxBuffer = "";
    }

    if(queueActive && queueWaitingReply &&
       millis() - queueWaitStarted > VAMPIRE_COMMAND_TIMEOUT)
    {
        debugLog.add("Command queue timeout");
        queueClear();
        requestSettings();
    }

    //--------------------------------------------------
    // Request info after boot
    //--------------------------------------------------

    if (!bridgeModeEnabled && (fw.isEmpty() || !settings.valid))
    {
        if (millis() - lastInfoRequest > VAMPIRE_INFO_PERIOD)
        {
            lastInfoRequest = millis();

            // ESP32 can start before Vampire. Keep probing until both device
            // information and settings have been received.
            if (millis() - lastRxByteAt > 100)
                rxBuffer = "";
            requestInfo();
            requestSettings();
        }
    }
     //--------------------------------------------------
     // Telemetry polling
     //--------------------------------------------------

        /*if (!fw.isEmpty())
         {
             if (millis() - lastTelemetryRequest > VAMPIRE_TRANS_PERIOD)
                {
                     lastTelemetryRequest = millis();

                    startTelemetry();
                 }
         }
*/
}
     ////////////////////////////////////////////////////////
     // Basic commands
     ////////////////////////////////////////////////////////

     bool Vampire::requestInfo()
     {
         return sendCommand(CMD_INFO);
      }

     bool Vampire::requestSettings()
     {
         return sendCommand(CMD_GET_SETTINGS);
      }

////////////////////////////////////////////////////////
// Start telemetry
////////////////////////////////////////////////////////


bool Vampire::startTelemetry()
{
    return sendCommand(CMD_TELEMETRY);
}

////////////////////////////////////////////////////////
// Send one parameter
////////////////////////////////////////////////////////

bool Vampire::sendParameter(uint8_t number, uint16_t value)
{
    char cmd[32];

    sprintf(cmd, "AT%02dpar%d", number, value);

    return sendCommand(String(cmd));
}

////////////////////////////////////////////////////////
// Send all settings
////////////////////////////////////////////////////////

bool Vampire::sendAllParameters()
{
    if (queueActive)
    {
        debugLog.add("Settings queue is already active");
        return false;
    }

    if(!settings.valid)
    {
        debugLog.add("Settings not loaded");

        return false;
    }

    debugLog.add("===== SEND ALL PARAMETERS =====");

    //--------------------------------------------------
    // Update P11 from FuseSettings
    //--------------------------------------------------

          settings.encodeFuseBits();

     //--------------------------------------------------
     // Build queue
     //--------------------------------------------------

     queueClear();

    const bool firstSend = !lastSentValid;

    // Send the operating mode first. It is the most important setting and
    // must not wait behind a full list of P0...P17 commands.
    if (firstSend || lastSentMode != settings.mode)
    {
        queueAddMode(settings.mode);
    }

    for (uint8_t i = 0; i < 18; i++)
    {
        if (firstSend || lastSentP[i] != settings.p[i])
        {
            queueAddParameter(i, settings.p[i]);
        }
    }

    // Do not update lastSent* here. A value becomes the confirmed baseline
    // only after the controller replies OK to the corresponding command.

//--------------------------------------------------
// Start sending
//--------------------------------------------------

if (queueCount == 0)
{
    debugLog.add("Nothing changed");

    return true;
}

debugLog.add("Changed settings queued: " + String(queueCount));
queueStart();

debugLog.add("Queue created");

return true;
}

////////////////////////////////////////////////////////
// Process received line
////////////////////////////////////////////////////////

void Vampire::processLine(String line)
{
    // Vampire configures the original HC-06 compatible Bluetooth module over
    // this same UART. ESP32 must emulate those module-side AT replies instead
    // of treating the commands as controller data. Some firmware revisions
    // prefix the command with startup noise, therefore search inside the line.
    const int btAt = line.indexOf("AT+");
    if (line == "AT" || btAt >= 0)
    {
        String command = (line == "AT") ? line : line.substring(btAt);
        command.trim();

        String reply;
        if (command == "AT")
            reply = "OK";
        else if (command.startsWith("AT+NAME"))
            reply = "OKsetname";
        else if (command.startsWith("AT+PIN"))
            reply = "OKsetPIN";
        else if (command.startsWith("AT+BAUD"))
        {
            const char code = command.length() > 7 ? command.charAt(7) : '4';
            switch (code)
            {
                case '1': reply = "OK1200"; break;
                case '2': reply = "OK2400"; break;
                case '3': reply = "OK4800"; break;
                case '4': reply = "OK9600"; break;
                case '5': reply = "OK19200"; break;
                case '6': reply = "OK38400"; break;
                case '7': reply = "OK57600"; break;
                case '8': reply = "OK115200"; break;
                default: reply = "OK38400"; break;
            }
        }
        else if (command.startsWith("AT+VERSION"))
            reply = "linvorV1.8";

        if (!reply.isEmpty())
        {
            _serial->print(reply);
            _serial->flush();

            uint32_t newBaud = 0;
            if (command.startsWith("AT+BAUD") && command.length() > 7)
            {
                switch (command.charAt(7))
                {
                    case '1': newBaud = 1200; break;
                    case '2': newBaud = 2400; break;
                    case '3': newBaud = 4800; break;
                    case '4': newBaud = 9600; break;
                    case '5': newBaud = 19200; break;
                    case '6': newBaud = 38400; break;
                    case '7': newBaud = 57600; break;
                    case '8': newBaud = 115200; break;
                }
            }

            if (newBaud != 0)
            {
                delay(5);
                _serial->updateBaudRate(newBaud);
            }

            debugLog.add("BT module emulation: " + command + " -> " + reply +
                         (newBaud ? " ; UART=" + String(newBaud) : ""));

            if (command.startsWith("AT+NAME"))
            {
                // Vampire sends AT+NAME whenever it starts. Discard stale state
                // and force a complete rediscovery without rebooting ESP32.
                fw = "";
                sn = "";
                settings.valid = false;
                telemetry.valid = false;
                telemetryStarted = false;
                telemetryStartAcks = 0;
                lastInfoRequest = millis() - VAMPIRE_INFO_PERIOD;
                debugLog.add("Vampire startup detected; scheduling full resync");
            }
            return;
        }
    }

    debugLog.add("<< " + line);

    //-----------------------------------------
    // OK
    //-----------------------------------------

    if(line == "OK")
    {
        debugLog.add("Command accepted");

        if(queueActive && queueWaitingReply)
        {
            // queuePosition points to the next item because queueNext()
            // increments it immediately after sending the current command.
            if (queuePosition > 0)
            {
                const QueueItem &accepted = queue[queuePosition - 1];

                if (accepted.isMode)
                {
                    lastSentMode = accepted.parameter;
                }
                else if (accepted.parameter < 18)
                {
                    lastSentP[accepted.parameter] = accepted.value;
                }

                lastSentValid = true;
            }

            queueWaitingReply = false;
            queueNext();
        }
        return;
    }

    //-----------------------------------------
    // ERROR
    //-----------------------------------------

    if(line.startsWith("ERR"))
    {
        debugLog.add("Command ERROR: " + line);
        queueClear();
        return;
    }

    //-----------------------------------------
    // SETTINGS
    //-----------------------------------------

    if(line.startsWith(">"))
    {
        if(line.length() > 20)
        {
            parseSettings(line);
            return;
        }
    }


    //--------------------------------------------------
    // Telemetry
    //--------------------------------------------------

     if(line.startsWith("*"))
     {
        parseTelemetry(line);

         return;
     }
    //-----------------------------------------
    // INFO
    //-----------------------------------------

    if(line.startsWith("{"))
    {
        parseInfo(line);
        return;
    }
}

////////////////////////////////////////////////////////
// Parse ATinfo
////////////////////////////////////////////////////////

bool Vampire::parseInfo(const String &line)
{
    int p;

    //-----------------------------------------
    // Firmware
    //-----------------------------------------

    p = line.indexOf("\"FW\"");

    if (p >= 0)
    {
        int q1 = line.indexOf("\"", p + 4);
        int q2 = line.indexOf("\"", q1 + 1);

        if (q1 > 0 && q2 > q1)
        {
            fw = line.substring(q1 + 1, q2);

            debugLog.add("FW = " + fw);
        }
    }

    //-----------------------------------------
    // Serial number
    //-----------------------------------------

    p = line.indexOf("\"SN\"");

    if (p >= 0)
    {
        int q1 = line.indexOf("\"", p + 4);
        int q2 = line.indexOf("\"", q1 + 1);

        if (q1 > 0 && q2 > q1)
        {
            sn = line.substring(q1 + 1, q2);

            debugLog.add("SN = " + sn);

            const String expectedName = "SV-" + sn;

            if (btBridge.getDeviceName() != expectedName)
                btBridge.setDeviceName(expectedName);

            // Start Bluetooth only after the serial number is known, so the
            // phone always discovers the original-compatible SV-<SN> name.
            if (!btBridge.enabled())
                btBridge.enable();
        }
    }

 //-----------------------------------------
    // Telemetry start acknowledge
    //-----------------------------------------

    if (line.indexOf("\"ATtrans\"") >= 0)
    {
        // ATtrans is acknowledged once; telemetry frames follow automatically.
        telemetryStartAcks = 1;
        telemetryStarted = true;
        debugLog.add("ATtrans OK; telemetry stream active");
        return true;
    }
    return true;
}

////////////////////////////////////////////////////////
// Parse ATgsets
////////////////////////////////////////////////////////

bool Vampire::parseSettings(const String &line)
{
    debugLog.add("SETTINGS received");

    String s = line;

    //----------------------------------------
    // удалить >
    //----------------------------------------

    if(s.startsWith(">"))
        s.remove(0,1);

    uint8_t index = 0;

    while(s.length())
    {
        int p = s.indexOf(' ');

        String token;

        if(p < 0)
        {
            token = s;
            s = "";
        }
        else
        {
            token = s.substring(0,p);

            s.remove(0,p+1);

            while(s.startsWith(" "))
                s.remove(0,1);
        }

        switch(index)
        {
            //----------------------------------
            // P30 Mode
            //----------------------------------

            case 0:

                settings.mode = token.toInt();

                break;

            //----------------------------------
            // P0...P17
            //----------------------------------

            case 1:  settings.p[0]  = token.toInt(); break;
            case 2:  settings.p[1]  = token.toInt(); break;
            case 3:  settings.p[2]  = token.toInt(); break;
            case 4:  settings.p[3]  = token.toInt(); break;
            case 5:  settings.p[4]  = token.toInt(); break;
            case 6:  settings.p[5]  = token.toInt(); break;
            case 7:  settings.p[6]  = token.toInt(); break;
            case 8:  settings.p[7]  = token.toInt(); break;
            case 9:  settings.p[8]  = token.toInt(); break;
            case 10: settings.p[9]  = token.toInt(); break;
            case 11: settings.p[10] = token.toInt(); break;
            case 12: settings.p[11] = token.toInt(); break;
            case 13: settings.p[12] = token.toInt(); break;
            case 14: settings.p[13] = token.toInt(); break;
            case 15: settings.p[14] = token.toInt(); break;
            case 16: settings.p[15] = token.toInt(); break;
            case 17: settings.p[16] = token.toInt(); break;
            case 18: settings.p[17] = token.toInt(); break;
        }

        index++;
    }

    if(index < 19)
    {
        debugLog.add("Invalid settings frame: expected 19 values, got " + String(index));
        return false;
    }

    //----------------------------------------
    // Decode P11
    //----------------------------------------

    settings.decodeFuseBits();

    settings.valid = true;

    // This full settings frame is the real state stored in the Vampire.
    // The controller sends it automatically after a successful parameter or
    // mode change, so use it as the acknowledgement and synchronize the cache
    // immediately. This keeps change detection correct without an extra
    // ATgsets request after the queue finishes.
    memcpy(lastSentP, settings.p, sizeof(lastSentP));
    lastSentMode = settings.mode;
    lastSentValid = true;

    //----------------------------------------
    // Debug
    //----------------------------------------

    debugLog.add("Mode = " + String(settings.mode));

    for(int i=0;i<18;i++)
    {
        debugLog.add(
            "P" + String(i) + " = " +
            String(settings.p[i])
        );
    }

    //--------------------------------------------------
    // Continue queue
    //--------------------------------------------------

      if(queueActive && queueWaitingReply)
      {
        queueWaitingReply = false;

        queueNext();
      }

     //--------------------------------------------------
     // Start realtime stream
     //--------------------------------------------------

      if(!telemetryStarted)
      {
         telemetryStarted = true;
         telemetryStartAcks = 0;

         debugLog.add("Starting telemetry stream");

         startTelemetry();
       }
    return true;
}

////////////////////////////////////////////////////////
// Parse telemetry
////////////////////////////////////////////////////////

bool Vampire::parseTelemetry(const String &line)
{
    // Supported frames (without CR/LF):
    // extpr=0: *AAA BBB CCC DDD EEE FFFFF GGG HHH SS
    // extpr=1: *AAA BBB CCC DDD EEE FFFFF GGG HHH III JJJ SS
    // extpr=2: *AAA BBB CCC DDD EEE FFFFF GGG HHH III JJJ sKKKKK SS
    if (!line.startsWith("*") || line.length() < 39)
    {
        telemetry.valid = false;
        debugLog.add("Invalid telemetry frame length: " + String(line.length()));
        return false;
    }

    const int crcSeparator = line.lastIndexOf(' ');
    if (crcSeparator <= 1 || crcSeparator + 3 != (int)line.length())
    {
        telemetry.valid = false;
        debugLog.add("Invalid telemetry CRC field");
        return false;
    }

    const String crcText = line.substring(crcSeparator + 1);
    char *crcEnd = nullptr;
    const unsigned long receivedCrc = strtoul(crcText.c_str(), &crcEnd, 16);
    if (crcText.length() != 2 || crcEnd == nullptr || *crcEnd != '\0' || receivedCrc > 0xFF)
    {
        telemetry.valid = false;
        debugLog.add("Invalid telemetry CRC value: " + crcText);
        return false;
    }

    // Sum all transmitted ASCII bytes after '*' and before the two CRC digits.
    // The separating space immediately before CRC is part of the transmitted
    // frame and therefore participates in the checksum.
    uint8_t calculatedCrc = 0;
    for (int i = 1; i <= crcSeparator; ++i)
        calculatedCrc = uint8_t(calculatedCrc + uint8_t(line.charAt(i)));

    // Some protocol notes are ambiguous about whether the separator before
    // SS participates in the sum. Accept both interpretations, while still
    // rejecting any frame whose data checksum is wrong.
    const uint8_t calculatedWithoutSeparator =
        uint8_t(calculatedCrc - uint8_t(' '));

    if (calculatedCrc != uint8_t(receivedCrc) &&
        calculatedWithoutSeparator != uint8_t(receivedCrc))
    {
        telemetry.valid = false;
        char msg[80];
        snprintf(msg, sizeof(msg),
                 "Telemetry CRC error: got %02lX expected %02X/%02X",
                 receivedCrc, calculatedCrc, calculatedWithoutSeparator);
        debugLog.add(msg);
        return false;
    }

    String payload = line.substring(1, crcSeparator);
    String token[11];
    uint8_t tokenCount = 0;

    int start = 0;
    while (start < (int)payload.length() && tokenCount < 11)
    {
        while (start < (int)payload.length() && payload.charAt(start) == ' ')
            ++start;
        if (start >= (int)payload.length())
            break;

        int end = payload.indexOf(' ', start);
        if (end < 0)
            end = payload.length();

        token[tokenCount++] = payload.substring(start, end);
        start = end + 1;
    }

    // 8 fields for extpr=0, 10 for extpr=1, 11 for extpr=2.
    if (tokenCount != 8 && tokenCount != 10 && tokenCount != 11)
    {
        telemetry.valid = false;
        debugLog.add("Invalid telemetry field count: " + String(tokenCount));
        return false;
    }

    auto unsignedDecimal = [](const String &value, uint32_t &result) -> bool
    {
        if (value.isEmpty())
            return false;
        uint32_t parsed = 0;
        for (size_t i = 0; i < value.length(); ++i)
        {
            const char c = value.charAt(i);
            if (c < '0' || c > '9')
                return false;
            parsed = parsed * 10U + uint32_t(c - '0');
        }
        result = parsed;
        return true;
    };

    uint32_t value[10] = {0};
    const uint8_t unsignedCount = tokenCount == 8 ? 8 : 10;
    for (uint8_t i = 0; i < unsignedCount; ++i)
    {
        if (!unsignedDecimal(token[i], value[i]))
        {
            telemetry.valid = false;
            debugLog.add("Invalid telemetry number in field " + String(i));
            return false;
        }
    }

    int32_t gridPower = 0;
    if (tokenCount == 11)
    {
        const String &grid = token[10];
        if (grid.length() != 6 || (grid.charAt(0) != '0' && grid.charAt(0) != '-'))
        {
            telemetry.valid = false;
            debugLog.add("Invalid grid power field: " + grid);
            return false;
        }

        uint32_t magnitude = 0;
        if (!unsignedDecimal(grid.substring(1), magnitude) || magnitude > 32767U)
        {
            telemetry.valid = false;
            debugLog.add("Invalid grid power magnitude: " + grid);
            return false;
        }
        gridPower = grid.charAt(0) == '-' ? -int32_t(magnitude) : int32_t(magnitude);
    }

    telemetry.pv1Voltage = uint16_t(value[0]);
    telemetry.batteryVoltage = uint16_t(value[1]);
    telemetry.batterySOC = uint16_t(value[2]);
    telemetry.chargeCurrent = int16_t(value[3]);
    telemetry.dischargeCurrent = int16_t(value[4]);
    telemetry.inverterLoad = uint16_t(value[5]);
    telemetry.regulatorOutput = uint16_t(value[6]);
    telemetry.pv2Voltage = uint16_t(value[7]);

    if (tokenCount >= 10)
    {
        telemetry.pv1Current = uint16_t(value[8]);
        telemetry.pv2Current = uint16_t(value[9]);
        telemetry.pv1Power = (uint32_t(telemetry.pv1Voltage) * telemetry.pv1Current + 5U) / 10U;
        telemetry.pv2Power = (uint32_t(telemetry.pv2Voltage) * telemetry.pv2Current + 5U) / 10U;
    }
    else
    {
        telemetry.pv1Current = 0;
        telemetry.pv2Current = 0;
        telemetry.pv1Power = 0;
        telemetry.pv2Power = 0;
    }

    telemetry.gridPower = int16_t(gridPower);
    telemetry.valid = true;
    return true;
}

////////////////////////////////////////////////////////
// Get settings
////////////////////////////////////////////////////////

const Settings& Vampire::getSettings() const
{
    return settings;
}

Settings& Vampire::getSettings()
{
    return settings;
}

////////////////////////////////////////////////////////
// Get telemetry
////////////////////////////////////////////////////////

const Telemetry& Vampire::getTelemetry() const
{
    return telemetry;
}

////////////////////////////////////////////////////////
// Firmware
////////////////////////////////////////////////////////

String Vampire::firmware() const
{
    return fw;
}

////////////////////////////////////////////////////////
// Serial number
////////////////////////////////////////////////////////

String Vampire::serialNumber() const
{
    return sn;
}

////////////////////////////////////////////////////////
// Queue clear
////////////////////////////////////////////////////////

void Vampire::queueClear()
{
    queueCount = 0;

    queuePosition = 0;

    queueActive = false;
    queueWaitingReply = false;
    queueWaitStarted = 0;
}

////////////////////////////////////////////////////////
// Add parameter
////////////////////////////////////////////////////////

void Vampire::queueAddParameter(
    uint8_t number,
    uint16_t value
)
{
    if(queueCount >= 20)
        return;

    queue[queueCount].isMode = false;

    queue[queueCount].parameter = number;

    queue[queueCount].value = value;

    queueCount++;
}

////////////////////////////////////////////////////////
// Add mode
////////////////////////////////////////////////////////

void Vampire::queueAddMode(
    uint8_t mode
)
{
    if(queueCount >= 20)
        return;

    queue[queueCount].isMode = true;

    queue[queueCount].parameter = mode;

    queueCount++;
}
////////////////////////////////////////////////////////
// Start queue
////////////////////////////////////////////////////////

bool Vampire::queueStart()
{
    if(queueCount == 0)
        return false;

    queuePosition = 0;

    queueActive = true;

    debugLog.add("Queue started");

    queueNext();

    return true;
}
////////////////////////////////////////////////////////
// Next queue item
////////////////////////////////////////////////////////

void Vampire::queueNext()
{
    //--------------------------------------------------
    // Queue finished
    //--------------------------------------------------

    if(queuePosition >= queueCount)
    {
        queueActive = false;
        queueWaitingReply = false;
        queueWaitStarted = 0;

        debugLog.add("Queue finished; settings confirmed by device snapshot");

        // No ATgsets is needed here: after every accepted change the
        // controller automatically sends a complete settings frame, and
        // parseSettings() has already used that frame to update the cache.
        return;
    }

    //--------------------------------------------------
    // Current item
    //--------------------------------------------------

    QueueItem &item = queue[queuePosition];

    //--------------------------------------------------
    // Send mode
    //--------------------------------------------------

    if(item.isMode)
    {
        char cmd[16];

        sprintf(cmd, "ATmode%d", item.parameter);

        sendCommand(String(cmd));

        debugLog.add(
            "Queue MODE = " +
            String(item.parameter)
        );
    }

    //--------------------------------------------------
    // Send parameter
    //--------------------------------------------------

    else
    {
        sendParameter(
            item.parameter,
            item.value
        );

        debugLog.add(
            "Queue P" +
            String(item.parameter) +
            " = " +
            String(item.value)
        );
    }

    //--------------------------------------------------
    // Wait for the controller reply (normally a full settings snapshot)
    //--------------------------------------------------

    queuePosition++;

    queueWaitingReply = true;
    queueWaitStarted = millis();
}

////////////////////////////////////////////////////////
// Bluetooth Bridge
////////////////////////////////////////////////////////

void Vampire::setBridgeMode(bool enable)
{
    if (bridgeModeEnabled == enable)
        return;

    bridgeModeEnabled = enable;

    if (enable)
    {
        // A connected Bluetooth application owns command transmission.
        // Stop all ESP-generated queue traffic so monitoring and especially
        // Vampire firmware updates receive a clean transparent UART channel.
        queueClear();
        rxBuffer = "";
        telemetryStarted = false;
        telemetryStartAcks = 0;
        debugLog.add("Bluetooth exclusive bridge ON; Web UART writes blocked");
    }
    else
    {
        rxBuffer = "";

        // The normal Vampire application always returns to its standard UART
        // speed after boot/update. Restore it before sending synchronization
        // commands in case the updater selected a faster HC-06 baud rate.
        _serial->updateBaudRate(VAMPIRE_BAUD);
        debugLog.add("Bluetooth exclusive bridge OFF; UART restored to " + String(VAMPIRE_BAUD));
        debugLog.add("Bluetooth exclusive bridge OFF; resynchronizing Vampire");

        // The controller may have rebooted or changed settings during the
        // Bluetooth session/update. Reload everything after disconnection.
        requestInfo();
        requestSettings();
    }
}

bool Vampire::bridgeMode() const
{
    return bridgeModeEnabled;
}