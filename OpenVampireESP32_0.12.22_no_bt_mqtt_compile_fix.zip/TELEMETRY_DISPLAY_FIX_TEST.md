# 0.12.15 Telemetry display fix test

- Real telemetry values use a bold font.
- PV1/PV2 rows show current in amperes and calculated power in parentheses.
- PV current fields are interpreted as tenths of an ampere.
- Battery charge/discharge current is shown in amperes without an extra division by 10.
- Battery charge/discharge power is calculated from current and actual battery voltage.
