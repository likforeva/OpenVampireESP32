# 0.12.13 MPPT parameters fix test

Base: `0.12.12-wifi-led-test`.

Fixed the Web UI parameter enable/disable mapping for Regulator Mode2 (MPPT):

- `P2 (Kidch)` / `Reg.Coeff.` is now editable in MPPT mode.
- `P3 (MAX out)` / `MAX.reg.value %` is now editable in MPPT mode.
- MPPT fields `P4`, `P14`, and `P15` remain editable in MPPT mode.
- Mode1 fields are now mapped explicitly to `P0`, `P1`, `P12`, and `P13`.

No Vampire updater, ESP32 OTA, Wi-Fi LED, Bluetooth, or UART logic was changed.
