# Flash size fix

The application grew beyond the previous OTA slot size of 0x190000 (1,638,400 bytes).

Partition layout changed for a 4 MB ESP32 flash:

- app0: 0x1B0000 (1,769,472 bytes)
- app1: 0x1B0000 (1,769,472 bytes)
- SPIFFS: 0x090000 (589,824 bytes)

Important: install this build once over USB/serial so the new partition table is written.
The previous partition table cannot be changed by a normal OTA firmware update.
