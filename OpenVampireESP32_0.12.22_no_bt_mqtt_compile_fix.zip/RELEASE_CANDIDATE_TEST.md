# OpenVampireESP32 0.12.9 Release Candidate Test

This test build uses the intended release behavior:

- preserves the verified Bluetooth disconnect recovery;
- preserves automatic browser data refresh;
- removes StartupDiag, SafeBTWeb, heartbeat, and BUILD TEST serial diagnostics;
- locks ESP32 OTA file selection, Upload, and Close controls during upload;
- prevents duplicate OTA submissions;
- restores OTA controls after an error, timeout, or aborted request;
- leaves Vampire firmware update behavior unchanged.

Build verification is intentionally left to the device owner.
