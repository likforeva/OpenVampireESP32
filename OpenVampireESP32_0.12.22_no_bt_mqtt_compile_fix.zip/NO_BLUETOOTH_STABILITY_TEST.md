# 0.12.20 No Bluetooth Stability Test

This build is based on 0.12.19.

Classic Bluetooth support is completely removed from the compiled firmware.
BTBridge remains only as a zero-function compatibility stub, so the rest of
Vampire, Wi-Fi, WebServer, OTA ESP32, Vampire updater, telemetry, fuses and
status LED logic remain unchanged.

Expected behavior:
- no Bluetooth device SV-<serial> is advertised;
- /api/bt reports enabled=false and connected=false;
- web settings are never blocked by a Bluetooth client;
- OTA ESP32 and Vampire update continue to work normally.

Use this build only to compare stability and heap usage against the Bluetooth build.
