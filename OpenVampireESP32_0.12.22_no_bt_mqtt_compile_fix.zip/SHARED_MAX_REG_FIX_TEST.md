# Shared MAX.reg.value fix test

Version: `0.12.14-shared-max-reg-fix-test`

Fix:

- `P3 (MAX.reg.value % / MAX out)` is now editable in both:
  - Regulator Mode1 (Fix PV Voltage)
  - Regulator Mode2 (MPPT)
- `P2 (Kidch)` remains enabled only in Mode2 (MPPT).
- Wi-Fi LED, Bluetooth bridge, ESP32 OTA and Vampire updater logic are unchanged.
