# Browser firmware-list parser fix

- ESP32 proxies the original firmware page over HTTPS.
- Browser parses the table with DOMParser.
- Relative .bin links are converted to absolute HTTPS URLs.
- Online .bin downloads support HTTPS.
- Local firmware upload remains available.
- Bluetooth status remains removed from the menu.
