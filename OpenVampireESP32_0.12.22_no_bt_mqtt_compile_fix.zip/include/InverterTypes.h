#ifndef INVERTER_TYPES_H
#define INVERTER_TYPES_H

#include <Arduino.h>

struct InverterType
{
    uint8_t id;
    const char *name;
};

static const InverterType inverterTypes[] =
{
    {0,  "Voltronic & Clones 1PV"},
    {1,  "Voltronic & Clones 2PV"},
    {2,  "PowMr 10.2kW 2PV"},
    {3,  "PowMr Modbus 1PV"},
    {4,  "Anenji 4/6kW 1PV"},
    {5,  "Anenji 11kW 2PV"},
    {6,  "JSD Solar 1PV"},
    {7,  "Newjsdolar 2PV"},
    {8,  "Must 1PV"},
    {9,  "SRNE 1PV"},
    {10, "Deye 1ph 2PV"},
    {11, "Deye 3ph 2PV"},
    {12, "Lux Power 2PV"},
    {13, "Growatt 2PV"}
};

static const uint8_t inverterTypeCount =
sizeof(inverterTypes) / sizeof(inverterTypes[0]);

inline const char* inverterName(uint8_t id)
{
    for(uint8_t i=0;i<inverterTypeCount;i++)
    {
        if(inverterTypes[i].id==id)
            return inverterTypes[i].name;
    }

    return "Unknown";
}

#endif