#ifndef OTA_H
#define OTA_H

#include <Arduino.h>
#include <WebServer.h>

class OTA
{
public:
    OTA(WebServer &server);

    void begin();

private:
    WebServer *_server;

    void handlePage();
    void handleUpload();
};

#endif