#pragma once

#include <Arduino.h>

class DebugLog
{
public:

    void add(const String &text);

    void clear();

    String get() const;

private:

    static const uint16_t MAX_SIZE = 12000;

    String buffer;
};

extern DebugLog debugLog;