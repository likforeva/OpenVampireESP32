#pragma once

#include <Arduino.h>

////////////////////////////////////////////////////////
// Fuse limits
////////////////////////////////////////////////////////

struct FuseSettings
{
    bool batVoltEnable = false;
    uint16_t batVoltLimit = 0;

    bool batSocEnable = false;
    uint16_t batSocLimit = 0;

    bool chargeEnable = false;
    uint16_t chargeLimit = 0;

    bool dischargeEnable = false;
    uint16_t dischargeLimit = 0;

    bool loadEnable = false;
    uint16_t loadLimit = 0;

    bool gridEnable = false;
    uint16_t gridLimit = 0;
};

////////////////////////////////////////////////////////
// Vampire settings
////////////////////////////////////////////////////////

struct Settings
{
    //--------------------------------------------------
    // Mode (P30)
    //--------------------------------------------------

    uint8_t mode = 0;

    //--------------------------------------------------
    // Parameters P0...P17
    //--------------------------------------------------

    uint16_t p[18] = {0};

    //--------------------------------------------------
    // Decoded fuse settings (from P11)
    //--------------------------------------------------

    FuseSettings fuse;

    //--------------------------------------------------
    // Settings successfully received
    //--------------------------------------------------

    bool valid = false;

    //--------------------------------------------------
    // Decode P11 -> fuse bits
    //--------------------------------------------------

    void decodeFuseBits()
    {
        uint16_t bits = p[11];

        fuse.batVoltEnable    = bits & (1 << 1);
        fuse.batSocEnable     = bits & (1 << 2);
        fuse.chargeEnable     = bits & (1 << 3);
        fuse.dischargeEnable  = bits & (1 << 4);
        fuse.loadEnable       = bits & (1 << 5);
        fuse.gridEnable       = bits & (1 << 7);

        fuse.batVoltLimit      = p[5];
        fuse.batSocLimit       = p[6];
        fuse.chargeLimit       = p[7];
        fuse.dischargeLimit    = p[8];
        fuse.loadLimit         = p[9];
        fuse.gridLimit         = p[17];
    }

    //--------------------------------------------------
    // Encode fuse bits -> P11
    //--------------------------------------------------

    void encodeFuseBits()
    {
        uint16_t bits = 0;

        if(fuse.batVoltEnable)    bits |= (1 << 1);
        if(fuse.batSocEnable)     bits |= (1 << 2);
        if(fuse.chargeEnable)     bits |= (1 << 3);
        if(fuse.dischargeEnable)  bits |= (1 << 4);
        if(fuse.loadEnable)       bits |= (1 << 5);
        if(fuse.gridEnable)       bits |= (1 << 7);

        p[11] = bits;

        p[5]  = fuse.batVoltLimit;
        p[6]  = fuse.batSocLimit;
        p[7]  = fuse.chargeLimit;
        p[8]  = fuse.dischargeLimit;
        p[9]  = fuse.loadLimit;
        p[17] = fuse.gridLimit;
    }
};

////////////////////////////////////////////////////////
// Telemetry
////////////////////////////////////////////////////////

struct Telemetry
{
    uint16_t pv1Voltage = 0;
    uint16_t pv1Current = 0;
    uint32_t pv1Power = 0;

    uint16_t pv2Voltage = 0;
    uint16_t pv2Current = 0;
    uint32_t pv2Power = 0;

    uint16_t batteryVoltage = 0;
    uint16_t batterySOC = 0;

    int16_t chargeCurrent = 0;
    int16_t dischargeCurrent = 0;

    uint16_t inverterLoad = 0;
    int16_t gridPower = 0;

    uint16_t regulatorOutput = 0;

    bool valid = false;
};