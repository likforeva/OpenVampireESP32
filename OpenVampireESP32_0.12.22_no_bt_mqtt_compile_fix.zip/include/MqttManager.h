#pragma once

#include <Arduino.h>
#include <WiFiClient.h>
#include <PubSubClient.h>
#include <Preferences.h>
#include "Settings.h"

struct MqttConfig
{
    bool enabled = false;
    String host;
    uint16_t port = 1883;
    String user;
    String password;
    uint16_t periodSeconds = 10;
};

class MqttManager
{
public:
    MqttManager();

    void begin();
    void update(const Telemetry &telemetry, const String &serialNumber);
    void pause(bool paused);

    const MqttConfig &config() const { return cfg; }
    void save(const MqttConfig &newConfig);

    bool connected() { return client.connected(); }
    String stateText();
    String topicFor(const String &serialNumber) const;

private:
    WiFiClient wifiClient;
    PubSubClient client;
    Preferences prefs;
    MqttConfig cfg;

    bool isPaused = false;
    uint32_t lastConnectAttempt = 0;
    uint32_t lastPublish = 0;

    void load();
    bool connect(const String &serialNumber);
    void publishTelemetry(const Telemetry &t, const String &serialNumber);
};
