#pragma once

#include <Arduino.h>
#include "Config.h"
#include "Settings.h"
#include "Protocol.h"

class Vampire
{
public:

    Vampire(HardwareSerial &serial);

    //--------------------------------------------------
    // Init
    //--------------------------------------------------

    void begin();
    void update();

    //--------------------------------------------------
    // Basic commands
    //--------------------------------------------------

    bool sendCommand(const String &cmd);

    bool requestInfo();
    bool requestSettings();
    bool startTelemetry();

    //--------------------------------------------------
    // Parameters
    //--------------------------------------------------

    bool sendParameter(uint8_t number, uint16_t value);

    bool sendAllParameters();

    ////////////////////////////////////////////////////////
    // Command Queue
    ////////////////////////////////////////////////////////

    void queueClear();

    void queueAddParameter(
        uint8_t number,
        uint16_t value
    );

    void queueAddMode(
        uint8_t mode
    );

    bool queueStart();

    void queueNext();

    //--------------------------------------------------
    // Parsed data
    //--------------------------------------------------

    const Settings& getSettings() const;
    Settings& getSettings();
    const Telemetry& getTelemetry() const;

    //--------------------------------------------------
    // Device info
    //--------------------------------------------------

    String firmware() const;
    String serialNumber() const;

    //--------------------------------------------------
    // Bluetooth Bridge
    //--------------------------------------------------

    void setBridgeMode(bool enable);
    bool bridgeMode() const;

private:

    //--------------------------------------------------
    // UART
    //--------------------------------------------------

    HardwareSerial *_serial;

    String rxBuffer;
    uint32_t lastRxByteAt = 0;

////////////////////////////////////////////////////////
// Command Queue
////////////////////////////////////////////////////////

struct QueueItem
{
    bool isMode = false;

    uint8_t parameter = 0;

    uint16_t value = 0;
};

QueueItem queue[20];

uint8_t queueCount = 0;

uint8_t queuePosition = 0;

bool queueActive = false;

bool queueWaitingReply = false;

uint32_t queueWaitStarted = 0;

    //--------------------------------------------------
    // Internal data
    //--------------------------------------------------

    Settings settings;
    Telemetry telemetry;

    uint16_t lastSentP[18];

    bool lastSentValid = false;

    uint8_t lastSentMode = 255;

    String fw;
    String sn;

    uint32_t lastInfoRequest = 0;

    uint32_t lastTelemetryRequest = 0;

    bool telemetryStarted = false;
    uint8_t telemetryStartAcks = 0;

    //--------------------------------------------------
    // Bluetooth Bridge
    //--------------------------------------------------

     bool bridgeModeEnabled = false;

    //--------------------------------------------------
    // Parsing
    //--------------------------------------------------

    void processLine(String line);

    bool parseInfo(const String &line);
    bool parseSettings(const String &line);
    bool parseTelemetry(const String &line);
};