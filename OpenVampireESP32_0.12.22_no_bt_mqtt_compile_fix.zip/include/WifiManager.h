#ifndef WIFI_MANAGER_H
#define WIFI_MANAGER_H

#include <Arduino.h>

class WifiManager
{
public:
    void begin();

    bool hasCredentials();

    void saveCredentials(const String &ssid, const String &password);

    String getSSID();

    String getPassword();

    bool connect();

    bool isConnected();

private:
    String _ssid;
    String _password;
};

#endif