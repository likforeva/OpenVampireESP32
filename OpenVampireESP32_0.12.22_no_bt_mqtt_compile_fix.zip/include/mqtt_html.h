#pragma once
#include <pgmspace.h>

const char MQTT_HTML[] PROGMEM = R"rawliteral(
<!DOCTYPE html><html lang="ru"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>MQTT Settings</title>
<style>
body{font-family:Arial,sans-serif;background:#f4f6f8;margin:0;padding:20px;color:#222}.card{max-width:620px;margin:auto;background:#fff;padding:24px;border-radius:14px;box-shadow:0 4px 18px #0002}h2{margin-top:0}.row{margin:14px 0}label{display:block;font-weight:700;margin-bottom:6px}input[type=text],input[type=password],input[type=number]{width:100%;box-sizing:border-box;padding:11px;border:1px solid #bbb;border-radius:8px;font-size:16px}.switch{display:flex;align-items:center;gap:10px}.buttons{display:flex;gap:12px;flex-wrap:wrap;margin-top:22px}button{border:0;border-radius:8px;padding:11px 18px;font-weight:700;cursor:pointer;background:#3949ab;color:white}button.secondary{background:#607d8b}.status{margin-top:18px;padding:12px;background:#eef1f5;border-radius:8px;white-space:pre-wrap}.hint{color:#666;font-size:14px}
</style></head><body><div class="card"><h2>MQTT Settings</h2>
<div class="row switch"><input id="enabled" type="checkbox"><label for="enabled" style="margin:0">Enable MQTT</label></div>
<div class="row"><label>Broker</label><input id="host" type="text" placeholder="192.168.1.10 or mqtt.example.com"></div>
<div class="row"><label>Port</label><input id="port" type="number" min="1" max="65535" value="1883"></div>
<div class="row"><label>Username</label><input id="user" type="text"></div>
<div class="row"><label>Password</label><input id="password" type="password"></div>
<div class="row"><label>Per, seconds</label><input id="period" type="number" min="0" max="65535" value="10"><div class="hint">0 = publish once per minute</div></div>
<div class="row"><label>Topic</label><input id="topic" type="text" readonly></div>
<div class="buttons"><button onclick="save()">Save</button><button class="secondary" onclick="location.href='/'">Back</button></div>
<div id="status" class="status">Loading...</div></div>
<script>
async function load(){try{const r=await fetch('/api/mqtt?_='+Date.now(),{cache:'no-store'});const d=await r.json();enabled.checked=d.enabled;host.value=d.host||'';port.value=d.port||1883;user.value=d.user||'';password.value='';period.value=d.period??10;topic.value=d.topic||'';status.textContent='State: '+d.state;}catch(e){status.textContent='Load error: '+e.message}}
async function save(){const body={enabled:enabled.checked,host:host.value.trim(),port:Number(port.value),user:user.value,password:password.value,period:Number(period.value)};status.textContent='Saving...';try{const r=await fetch('/api/mqtt',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const d=await r.json();if(!r.ok)throw new Error(d.message||'HTTP '+r.status);status.textContent='Saved. State: '+d.state;password.value='';setTimeout(load,1000)}catch(e){status.textContent='Save error: '+e.message}}
load();setInterval(load,5000);
</script></body></html>
)rawliteral";
