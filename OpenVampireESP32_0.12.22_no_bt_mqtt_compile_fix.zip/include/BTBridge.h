#pragma once

#include <Arduino.h>

// Test build: Classic Bluetooth is completely removed.
// This compatibility stub keeps the rest of the project unchanged so the
// stability of Wi-Fi/WebServer can be compared directly with the BT build.
class BTBridge
{
public:
    void begin();
    void enable();
    void disable();
    void restart();
    void update();

    void setDeviceName(const String &name);
    const String &getDeviceName() const;

    bool enabled() const;
    bool isConnected() const;

    void writeFromVampire(uint8_t value);

private:
    String deviceName = "OpenVampire";
};

extern BTBridge btBridge;
