#pragma once

#include <Arduino.h>

enum class StatusLedMode : uint8_t
{
    Normal,
    VampireUpdate,
    EspOta
};

class StatusLed
{
public:
    void begin();
    void update();
    void activity(uint32_t durationMs = 80);
    void setMode(StatusLedMode mode);

private:
    void write(bool on);

    StatusLedMode _mode = StatusLedMode::Normal;
    uint32_t _activityUntil = 0;
    bool _lastOutput = false;
    bool _initialized = false;
};

extern StatusLed statusLed;
