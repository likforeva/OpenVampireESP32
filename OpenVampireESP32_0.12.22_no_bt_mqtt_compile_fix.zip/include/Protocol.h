#pragma once

////////////////////////////////////////////////////////
// AT COMMANDS
////////////////////////////////////////////////////////

#define CMD_INFO           "ATinfo"
#define CMD_RESET          "ATreset"

#define CMD_GET_SETTINGS   "ATgsets"
#define CMD_TELEMETRY      "ATtrans"

#define CMD_MODE           "ATmode"

////////////////////////////////////////////////////////
// Parameter commands
////////////////////////////////////////////////////////

#define CMD_P00 "AT00par"
#define CMD_P01 "AT01par"
#define CMD_P02 "AT02par"
#define CMD_P03 "AT03par"
#define CMD_P04 "AT04par"
#define CMD_P05 "AT05par"
#define CMD_P06 "AT06par"
#define CMD_P07 "AT07par"
#define CMD_P08 "AT08par"
#define CMD_P09 "AT09par"
#define CMD_P10 "AT10par"
#define CMD_P11 "AT11par"
#define CMD_P12 "AT12par"
#define CMD_P13 "AT13par"
#define CMD_P14 "AT14par"
#define CMD_P15 "AT15par"
#define CMD_P16 "AT16par"
#define CMD_P17 "AT17par"

////////////////////////////////////////////////////////
// UART
////////////////////////////////////////////////////////

#define VAMPIRE_FRAME_BEGIN '>'

////////////////////////////////////////////////////////
// Timeouts
////////////////////////////////////////////////////////

#define VAMPIRE_COMMAND_TIMEOUT   1000
#define VAMPIRE_TELEMETRY_PERIOD  1000
#define VAMPIRE_INFO_PERIOD       5000