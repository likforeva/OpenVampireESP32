#pragma once
#include <Arduino.h>
#include <FS.h>

class VampireUpdater {
public:
    enum class State { IDLE, VALIDATING, READY, WAIT_BANNER, SENDING, WAIT_ACK, SUCCESS, ERROR };
    explicit VampireUpdater(HardwareSerial &serial);
    void begin();
    bool beginLocalUpload(const String &filename, String &error);
    bool writeLocalUpload(const uint8_t *data, size_t length, String &error);
    bool finishLocalUpload(String &error);
    bool start(String &error);
    void update();
    void reset();
    bool busy() const;
    bool flashing() const;
    bool ready() const;
    bool finished() const;
    String statusJson() const;
    const String& log() const { return _log; }
    const String& selectedVersion() const { return _selectedVersion; }
private:
    HardwareSerial *_serial;
    File _file;
    File _uploadFile;
    State _state = State::IDLE;
    String _log;
    String _error;
    String _selectedVersion;
    uint32_t _stateSince = 0;
    uint32_t _fileSize = 0;
    uint32_t _asciiRead = 0;
    uint16_t _blockLength = 0;
    uint16_t _blockIndex = 0;
    uint16_t _blockCount = 0;
    uint16_t _blockBytesRemaining = 0;
    bool _blockHeaderSent = false;
    bool _localUploadActive = false;
    String _banner;
    void addLog(const String &line);
    bool validateFile(String &error);
    bool readHexByte(uint8_t &value);
    bool readHexWord(uint16_t &value);
    int hexValue(char c) const;
    void fail(const String &message);
    String stateName() const;
};
