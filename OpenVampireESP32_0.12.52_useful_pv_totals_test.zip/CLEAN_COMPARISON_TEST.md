# 0.12.50 Clean comparison test

Removed the temporary PV V×I verification test.
Production energy integration, Today/month/all-time statistics and graphs are unchanged from 0.12.49.
Use this build for multi-day PV energy comparison with DessMonitor.
