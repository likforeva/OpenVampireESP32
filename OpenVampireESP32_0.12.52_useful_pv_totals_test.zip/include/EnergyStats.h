#pragma once

#include <Arduino.h>
#include <Preferences.h>
#include "Settings.h"

class EnergyStats {
public:
    void begin();
    void update(const Telemetry &t);
    String json() const;
    String csv() const;
    void reset();
    bool timeReady() const { return clockReady; }

private:
    static constexpr uint16_t GRAPH_POINTS = 288; // 24 h, 5 min
    static constexpr uint8_t DAYS_MAX = 31;
    static constexpr uint8_t MONTHS_MAX = 120; // rolling 10-year archive

    struct EnergySet {
        double pv = 0;
        double load = 0;
        double charge = 0;
        double discharge = 0;
        double gridImport = 0;
        double gridExport = 0;
    };

    struct GraphPoint {
        uint16_t minute = 0;
        // Time-weighted accumulators (W * ms). 64-bit storage prevents the
        // overflow seen when the main loop repeatedly added the same sample.
        uint64_t pvWms = 0;
        uint64_t loadWms = 0;
        uint64_t chargeWms = 0;
        uint64_t dischargeWms = 0;
        int64_t gridWms = 0;
        uint32_t coveredMs = 0;
        uint16_t samples = 0;
        uint8_t valid = 0;
    };

    struct DayRecord {
        uint8_t day = 0;
        float pv = 0;
        float load = 0;
        float charge = 0;
        float discharge = 0;
        float gridImport = 0;
        float gridExport = 0;
    };

    struct MonthRecord {
        uint16_t year = 0;
        uint8_t month = 0;
        float pv = 0;
        float load = 0;
        float charge = 0;
        float discharge = 0;
        float gridImport = 0;
        float gridExport = 0;
    };

    Preferences prefs;
    EnergySet today;
    EnergySet total;
    DayRecord days[DAYS_MAX]{};
    MonthRecord months[MONTHS_MAX]{};
    GraphPoint graph[GRAPH_POINTS]{};
    uint16_t currentYear = 0;
    uint8_t currentMonth = 0;
    uint8_t currentDay = 0;
    uint8_t monthCount = 0;
    bool clockReady = false;
    bool haveSample = false;
    uint64_t lastSampleUs = 0;
    uint64_t lastFrameUs = 0;
    uint32_t lastFrameId = 0;
    bool haveFrame = false;
    uint32_t lastSaveMs = 0;
    int lastGraphSlot = -1;

    void load();
    void save(bool force = false);
    void updateClockAndRollovers();
    void closeDay(uint8_t day);
    void closeMonth(uint16_t year, uint8_t month);
    void clearDailyGraph();
    static void add(EnergySet &dst, const EnergySet &src);
    static double sumDays(const DayRecord *records, size_t n, double DayRecord::*field);
};
