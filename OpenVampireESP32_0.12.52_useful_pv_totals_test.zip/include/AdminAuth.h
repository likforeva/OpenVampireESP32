#pragma once

#include <Arduino.h>
#include <WebServer.h>

class AdminAuth
{
public:
    void begin();

    bool isApRequest(WebServer &server) const;
    bool isAuthenticated(WebServer &server);
    bool require(WebServer &server);

    bool login(WebServer &server, const String &password);
    void logout(WebServer &server);

    bool setPasswordFromAp(WebServer &server, const String &newPassword, String &error);
    bool changePassword(WebServer &server, const String &currentPassword, const String &newPassword, String &error);

    String stateJson(WebServer &server);
    String pageHtml(WebServer &server);

private:
    String _passwordHash;
    String _sessionToken;
    uint32_t _sessionExpiresAt = 0;

    static constexpr uint32_t SESSION_TTL_MS = 15UL * 60UL * 1000UL;

    String sha256Hex(const String &value) const;
    String makeToken() const;
    String cookieValue(WebServer &server, const String &name) const;
    void saveHash(const String &hash);
};

extern AdminAuth adminAuth;
