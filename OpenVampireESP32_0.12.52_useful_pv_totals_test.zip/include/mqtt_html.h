#pragma once
#include <pgmspace.h>

const char MQTT_HTML[] PROGMEM = R"rawliteral(
<!DOCTYPE html><html lang="ru"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>MQTT Settings</title>
<style>
body{font-family:Arial,sans-serif;background:#f4f6f8;margin:0;padding:20px;color:#222}.card{max-width:680px;margin:auto;background:#fff;padding:24px;border-radius:14px;box-shadow:0 4px 18px #0002}h2{margin-top:0}.row{margin:14px 0}label{display:block;font-weight:700;margin-bottom:6px}input[type=text],input[type=password],input[type=number]{width:100%;box-sizing:border-box;padding:11px;border:1px solid #bbb;border-radius:8px;font-size:16px}.switch{display:flex;align-items:center;gap:10px}.buttons{display:flex;gap:12px;flex-wrap:wrap;margin-top:22px}button{border:0;border-radius:8px;padding:11px 18px;font-weight:700;cursor:pointer;background:#3949ab;color:white}button.secondary{background:#607d8b}.status{margin-top:18px;padding:12px;border-radius:8px;background:#eef1f5}.status.ok{background:#e8f5e9;color:#138a2e;font-weight:700}.status.bad{background:#ffebee;color:#c62828;font-weight:700}.hint{color:#666;font-size:14px}.topics{margin-top:18px;padding:14px;border:1px solid #dfe5eb;border-radius:10px;background:#f8fafc;line-height:1.65}.topics code{overflow-wrap:anywhere}@media(max-width:520px){body{padding:0}.card{border-radius:0}}
</style></head><body><div class="card"><h2>MQTT Settings</h2>
<div class="row switch"><input id="enabled" type="checkbox"><label for="enabled" style="margin:0">Enable MQTT</label></div>
<div class="row"><label>Broker</label><input id="host" type="text" placeholder="192.168.1.10 or mqtt.example.com"></div>
<div class="row"><label>Port</label><input id="port" type="number" min="1" max="65535" value="1883"></div>
<div class="row"><label>Username</label><input id="user" type="text"></div>
<div class="row"><label>Password</label><input id="password" type="password"></div>
<div class="row"><label>Per, seconds</label><input id="period" type="number" min="0" max="65535" value="10"><div class="hint">0 = publish once per minute</div></div>
<div class="row"><label>Topic</label><input id="topic" type="text" placeholder="Leave empty for automatic topic"><div class="hint">Empty = tele/VAMPIRE/SV-&lt;serial&gt;/STATE</div></div>
<div class="buttons"><button onclick="saveSettings()">Save</button><button class="secondary" onclick="location.href='/'">Back</button></div>
<div id="status" class="status">Loading...</div>
<div class="topics"><b>Home Assistant</b><br>MQTT Auto Discovery is published automatically after every broker connection.<br><br><b>MQTT topics</b><br>Telemetry: <code id="stateTopic">—</code><br>Device info: <code id="infoTopic">—</code><br>Availability: <code id="lwtTopic">—</code></div>
</div><script>
const $=id=>document.getElementById(id);
function relatedTopic(state,suffix){return state.endsWith('/STATE')?state.slice(0,-6)+'/'+suffix:state+'/'+suffix}
function showState(state,connected){const e=$('status');e.textContent='State: '+state;e.className='status '+(connected?'ok':state==='disabled'?'':'bad')}
async function load(){try{const r=await fetch('/api/mqtt?_='+Date.now(),{cache:'no-store'});const d=await r.json();if(!r.ok)throw new Error(d.message||'HTTP '+r.status);$('enabled').checked=d.enabled;$('host').value=d.host||'';$('port').value=d.port||1883;$('user').value=d.user||'';$('period').value=d.period??10;if(document.activeElement!==$('topic'))$('topic').value=d.configured_topic||'';showState(d.state,d.connected);const t=d.topic||'tele/VAMPIRE/SV-UNKNOWN/STATE';$('stateTopic').textContent=t;$('infoTopic').textContent=relatedTopic(t,'INFO');$('lwtTopic').textContent=relatedTopic(t,'LWT')}catch(e){const s=$('status');s.textContent='Load error: '+e.message;s.className='status bad'}}
async function saveSettings(){const body={enabled:$('enabled').checked,host:$('host').value.trim(),port:Number($('port').value),user:$('user').value,password:$('password').value,period:Number($('period').value),topic:$('topic').value.trim()};const s=$('status');s.textContent='Saving...';s.className='status';try{const r=await fetch('/api/mqtt',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const d=await r.json();if(!r.ok)throw new Error(d.message||'HTTP '+r.status);$('password').value='';showState(d.state,d.state==='connected');setTimeout(load,500)}catch(e){s.textContent='Save error: '+e.message;s.className='status bad'}}
load();setInterval(load,5000);
</script><script>
(function(){
  fetch('/api/status?t='+Date.now(),{cache:'no-store'})
    .then(function(r){return r.json();})
    .then(function(j){
      var sn=(j.serial||'').trim();
      if(sn) document.title=sn.indexOf('SV-')===0?sn:'SV-'+sn;
    })
    .catch(function(){});
})();
</script></body></html>
)rawliteral";
