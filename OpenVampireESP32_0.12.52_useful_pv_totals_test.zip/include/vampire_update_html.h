#pragma once

const char VAMPIRE_UPDATE_HTML[] PROGMEM = R"rawliteral(
<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Обновление Solar Vampire</title><style>
*{box-sizing:border-box}body{margin:0;background:#e8e8e8;color:#222;font-family:Arial,sans-serif}.page{max-width:760px;margin:auto;padding:12px}.card{background:#fff;border-radius:12px;padding:18px;margin-bottom:16px;box-shadow:0 2px 8px #0002}h1{font-size:25px;margin:0 0 8px}.info{color:#555;margin-bottom:16px}.buttons{display:grid;grid-template-columns:1fr 1fr;gap:12px}.btn{border:0;border-radius:10px;padding:14px;font-size:17px;font-weight:700;background:#1976d2;color:#fff;cursor:pointer}.btn.alt{background:#666}.btn.link{background:#6a45b8}.btn.exit{grid-column:1/-1;justify-self:center;width:min(100%,430px);background:#ef6c00}.btn.exit:hover{background:#e65100}.btn:disabled{opacity:.4;cursor:not-allowed}input[type=file]{width:100%;margin:12px 0}.log{min-height:250px;max-height:420px;overflow:auto;white-space:pre-wrap;background:#17181b;color:#eee;border-radius:8px;padding:12px;font:14px/1.4 monospace}.progress{height:18px;background:#ddd;border-radius:9px;overflow:hidden;margin-top:12px}.bar{height:100%;width:0;background:#2e7d32}.copyrow{display:flex;justify-content:flex-end;margin-bottom:8px}.copybtn{border:0;border-radius:8px;padding:9px 12px;background:#444;color:#fff;font-weight:700;cursor:pointer}.status{text-align:center;margin-top:7px;color:#555}@media(max-width:560px){.buttons{grid-template-columns:1fr}}
</style></head><body><main class="page"><section class="card"><h1>Обновление прошивки Vampire</h1><div id="device" class="info">Получение информации о контроллере…</div><button class="btn link" onclick="window.open('http://solarvampire.net/FW/fw.htm','_blank')">Открыть сайт прошивок</button></section><section class="card"><label for="localFile"><b>Локальный файл прошивки (.bin)</b></label><input id="localFile" type="file" accept=".bin,application/octet-stream"><div class="buttons"><button id="uploadBtn" class="btn" onclick="uploadLocal()">Загрузить файл</button><button id="updateBtn" class="btn" disabled onclick="startUpdate()">Обновить Vampire</button><button id="backBtn" class="btn exit" onclick="returnNormal()">Выйти из режима обновления</button></div><div class="progress"><div id="bar" class="bar"></div></div><div id="progressText" class="status">0%</div></section><section class="card"><div class="copyrow"><button class="copybtn" onclick="copyLog()">Копировать лог</button></div><div id="log" class="log" tabindex="0">Открыта страница обновления Vampire.</div></section></main><script>
let currentState='idle';const q=id=>document.getElementById(id),log=q('log'),uploadBtn=q('uploadBtn'),updateBtn=q('updateBtn'),backBtn=q('backBtn');
async function loadInfo(){try{const r=await fetch('/api/status',{cache:'no-store'}),d=await r.json();q('device').textContent='Серийный номер: '+(d.serial||'неизвестен')+' · Текущая версия: '+(d.fw||'неизвестна');}catch(e){q('device').textContent='Не удалось прочитать информацию о Vampire';}}
function addLog(s){log.textContent+='\n'+s;log.scrollTop=log.scrollHeight;}
async function copyLog(){try{await navigator.clipboard.writeText(log.textContent);const b=document.querySelector('.copybtn');const old=b.textContent;b.textContent='Скопировано';setTimeout(()=>b.textContent=old,1200)}catch(e){const r=document.createRange();r.selectNodeContents(log);const sel=window.getSelection();sel.removeAllRanges();sel.addRange(r);document.execCommand('copy');sel.removeAllRanges();}}
function uploadLocal(){if(currentState==='busy')return;const file=q('localFile').files[0];if(!file){addLog('ОШИБКА: выберите файл .bin');return}if(!file.name.toLowerCase().endsWith('.bin')){addLog('ОШИБКА: требуется файл .bin');return}const form=new FormData();form.append('firmware',file,file.name);uploadBtn.disabled=true;updateBtn.disabled=true;addLog('Загрузка '+file.name+'…');const x=new XMLHttpRequest();x.open('POST','/api/vampire-fw/upload',true);x.timeout=180000;x.upload.onprogress=e=>{if(e.lengthComputable){const p=Math.round(e.loaded*100/e.total);q('bar').style.width=p+'%';q('progressText').textContent='Загрузка файла: '+p+'%'}};x.onload=async()=>{try{const d=JSON.parse(x.responseText||'{}');if(x.status<200||x.status>=300)throw new Error(d.message||('HTTP '+x.status));await refresh()}catch(e){addLog('ОШИБКА: '+e.message)}finally{uploadBtn.disabled=false}};x.onerror=()=>{addLog('ОШИБКА: соединение прервано');uploadBtn.disabled=false};x.ontimeout=()=>{addLog('ОШИБКА: истекло время загрузки');uploadBtn.disabled=false};x.send(form)}
async function startUpdate(){updateBtn.disabled=true;backBtn.disabled=true;const r=await fetch('/api/vampire-fw/start',{method:'POST'});if(!r.ok){const d=await r.json();addLog('ОШИБКА: '+(d.message||r.status));backBtn.disabled=false;return}currentState='busy'}
async function refresh(){try{const r=await fetch('/api/vampire-fw/status',{cache:'no-store'}),d=await r.json();currentState=d.busy?'busy':d.state;if(d.log){log.textContent=d.log;log.scrollTop=log.scrollHeight}const p=d.progress||0;q('bar').style.width=p+'%';q('progressText').textContent=(d.blocks?d.block+' / '+d.blocks+' блоков — ':'')+p+'%';updateBtn.disabled=!d.ready;backBtn.disabled=!!d.flashing;uploadBtn.disabled=!!d.busy}catch(e){}}
async function returnNormal(){
  if(backBtn.disabled)return;
  backBtn.disabled=true;
  const controller=new AbortController();
  const timer=setTimeout(()=>controller.abort(),3000);
  try{
    const r=await fetch('/api/vampire-fw/exit',{method:'POST',cache:'no-store',signal:controller.signal});
    if(r.status===423){
      const d=await r.json().catch(()=>({}));
      addLog('ОШИБКА: '+(d.message||'обновление прошивки ещё выполняется'));
      backBtn.disabled=false;
      return;
    }
  }catch(e){
    // Even if the reply is lost, leave the update page. The normal page will
    // reconnect after the ESP32 finishes processing the exit request.
  }finally{clearTimeout(timer)}
  window.location.replace('/?from=vampire-update&t='+Date.now());
}
loadInfo();refresh();setInterval(refresh,500);
</script><script>
(function(){
  fetch('/api/status?t='+Date.now(),{cache:'no-store'})
    .then(function(r){return r.json();})
    .then(function(j){
      var sn=(j.serial||'').trim();
      if(sn) document.title=sn.indexOf('SV-')===0?sn:'SV-'+sn;
    })
    .catch(function(){});
})();
</script></body></html>
)rawliteral";
