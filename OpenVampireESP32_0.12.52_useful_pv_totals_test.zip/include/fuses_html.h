#pragma once

const char FUSES_HTML[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Fuse Settings</title>
  <style>
    /*====================================================
     OpenVampire ESP32 - style.css (v0.5.0 Embedded)
    ====================================================*/
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: Arial, Helvetica, sans-serif;
    }

    body {
      background: #e8e8e8;
      color: #222;
      font-size: 16px;
    }

    .page {
      width: 100%;
      max-width: 700px;
      margin: auto;
      padding: 12px;
    }

    /* HEADER */
    .header {
      display: flex;
      align-items: center;
      gap: 12px;
      margin-bottom: 15px;
    }

    .menuButton {
      width: 48px;
      height: 48px;
      font-size: 28px;
      border: none;
      border-radius: 8px;
      background: #1976d2;
      color: white;
      cursor: pointer;
    }

    .menuButton:hover {
      background: #1565c0;
    }

    .headerInfo {
      flex: 1;
    }

    .line {
      display: flex;
      align-items: center;
      gap: 8px;
      margin: 3px 0;
      font-size: 17px;
      font-weight: bold;
    }

    .sep {
      color: #888;
    }

    /* MENU */
    .menu {
      display: none;
      position: absolute;
      top: 60px;
      left: 12px;
      background: white;
      border-radius: 10px;
      box-shadow: 0 3px 10px rgba(0,0,0,.25);
      overflow: hidden;
      z-index: 1000;
    }

    .menu button {
      display: block;
      width: 230px;
      padding: 14px;
      border: none;
      border-bottom: 1px solid #ddd;
      background: white;
      text-align: left;
      cursor: pointer;
      font-size: 16px;
    }

    .menu button:hover {
      background: #f0f0f0;
    }

    /* CARD */
    .card {
      background: white;
      border-radius: 12px;
      padding: 18px;
      margin-bottom: 18px;
      box-shadow: 0 2px 8px rgba(0,0,0,.12);
    }

    .card h2 {
      text-align: center;
      margin-bottom: 16px;
    }

    .card h3 {
      text-align: center;
      margin-bottom: 10px;
      font-size: 16px;
      color: #444;
    }

    /* DIMMER */
    .dimmerControl {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .dimmerControl button {
      width: 42px;
      height: 42px;
      font-size: 24px;
      border: none;
      border-radius: 8px;
      background: #1976d2;
      color: white;
      cursor: pointer;
    }

    .dimmerControl button:disabled {
      background: #bdbdbd;
      cursor: default;
    }

    #dimmerValue {
      width: 70px;
      height: 42px;
      text-align: center;
      font-size: 20px;
      font-weight: bold;
      border: 1px solid #bdbdbd;
      border-radius: 8px;
      background: white;
      color: #222;
    }

    /* SMOOTH CONTROL */
    .radioLabel {
      display: block;
      margin-top: 18px;
      margin-bottom: 10px;
      font-size: 17px;
      font-weight: bold;
    }

    .radioLabel input {
      width: 20px;
      height: 20px;
      margin-right: 8px;
    }

    .modeTable {
      width: 100%;
      border-collapse: separate;
      border-spacing: 0 10px;
    }

    .modeTable td {
      padding: 4px;
      vertical-align: middle;
    }

    .modeTable td:first-child {
      width: 36%;
    }

    .modeTable td:nth-child(2) {
      width: 16%;
    }

    .modeTable td:nth-child(3) {
      width: 28%;
      text-align: right;
      padding-right: 10px;
    }

    .modeTable td:nth-child(4) {
      width: 20%;
    }

    .modeTable input {
      width: 100%;
      height: 38px;
      text-align: center;
      font-size: 16px;
      border: 1px solid #bdbdbd;
      border-radius: 8px;
    }

    /* MAX REG VALUE */
    .maxBlock {
      margin-top: 22px;
      text-align: center;
    }

    .maxBlock label {
      display: block;
      font-weight: bold;
      margin-bottom: 10px;
    }

    .maxBlock input {
      width: 120px;
      height: 42px;
      text-align: center;
      font-size: 18px;
      border: 1px solid #bdbdbd;
      border-radius: 8px;
    }

    /* APPLY */
    .applyBlock {
      margin-top: 25px;
      text-align: center;
    }

    .applyButton {
      width: 220px;
      height: 52px;
      font-size: 20px;
      font-weight: bold;
      color: white;
      background: #2e7d32;
      border: none;
      border-radius: 10px;
      cursor: pointer;
    }

    .applyButton:hover {
      background: #1b5e20;
    }

    /* REAL TIME MONITOR */
    .monitorTable {
      width: 100%;
      border-collapse: collapse;
      text-align: center;
    }

    .monitorTable th {
      padding: 12px 8px;
      background: #1976d2;
      color: white;
      font-size: 16px;
    }

    .monitorTable td {
      padding: 12px 10px;
      border-bottom: 1px solid #dcdcdc;
      font-size: 17px;
    }

    .monitorTable td:first-child {
      font-weight: bold;
      width: 32%;
    }

    .monitorTable td:nth-child(2) {
      width: 26%;
    }

    .monitorTable td:nth-child(3) {
      width: 6%;
      text-align: center;
      font-size: 22px;
    }

    .monitorTable td:nth-child(4) {
      width: 36%;
    }

    /* FUSE STATUS */
    .fuseNormal {
      color: #2e7d32;
      font-weight: bold;
    }

    .fuseTrip {
      color: #d50000;
      font-weight: bold;
    }

    /* PROTOCOL */
    .protocolTitle {
      margin-bottom: 6px;
      font-size: 14px;
      color: #666;
    }

    .protocolBlock {
      text-align: center;
    }

    .protocolBlock select {
      width: 220px;
      height: 42px;
      font-size: 16px;
      border-radius: 8px;
      border: 1px solid #bdbdbd;
    }

    .protocolInfo {
      margin-top: 6px;
      text-align: center;
      color: #777;
      font-size: 12px;
    }

    /* DIALOGS */
    .dialog {
      display: none;
      position: fixed;
      inset: 0;
      background: rgba(0,0,0,.35);
      justify-content: center;
      align-items: center;
      z-index: 5000;
    }

    .dialogWindow {
      width: 92%;
      max-width: 420px;
      background: white;
      border-radius: 12px;
      padding: 20px;
    }

    .dialogWindow h2 {
      margin-bottom: 18px;
      text-align: center;
    }

    .dialogWindow input {
      width: 100%;
      height: 42px;
      margin-bottom: 12px;
      padding: 10px;
      border-radius: 8px;
      border: 1px solid #bdbdbd;
    }

    .dialogWindow textarea {
      width: 100%;
      height: 320px;
      resize: none;
      padding: 10px;
      border-radius: 8px;
      border: 1px solid #bdbdbd;
      font-family: monospace;
    }

    .dialogButtons {
      display: flex;
      justify-content: space-between;
      gap: 10px;
      margin-top: 18px;
    }

    .dialogButtons button {
      flex: 1;
      height: 44px;
      border: none;
      border-radius: 8px;
      color: white;
      background: #1976d2;
      cursor: pointer;
    }

    /* PHONE ADAPTATION */
    @media (max-width: 600px) {
      .page {
        padding: 8px;
      }
      .header {
        gap: 8px;
      }
      .menuButton {
        width: 44px;
        height: 44px;
      }
      .line {
        font-size: 15px;
      }
      .card {
        padding: 14px;
      }
      .modeTable td {
        font-size: 14px;
        padding: 3px;
      }
      .modeTable input {
        height: 34px;
        font-size: 15px;
      }
      .monitorTable th {
        font-size: 14px;
      }
      .monitorTable td {
        font-size: 14px;
        padding: 10px 4px;
      }
      .monitorTable td:nth-child(3) {
        font-size: 18px;
      }
      .applyButton {
        width: 100%;
      }
      .protocolBlock select {
        width: 100%;
      }
    }

    #dimmerMinus,
    #dimmerPlus {
      opacity: 0.35;
      pointer-events: none;
      transition: 0.2s;
    }

    #dimmerMinus.active,
    #dimmerPlus.active {
      opacity: 1;
      pointer-events: auto;
    }

    /* FUSE ENABLE / DISABLE */
    .fuseEnabled {
      color: #000000;
      font-weight: bold;
    }

    .fuseDisabled {
      color: #909090;
      font-weight: normal;
    }

    .compareEnabled {
      color: #000000;
      font-weight: bold;
    }

    .compareDisabled {
      color: #909090;
      font-weight: normal;
    }
  </style>
</head>

<body>

<div class="page">

  <!-- HEADER -->
  <div class="header">
    <button class="menuButton" onclick="backToMain()">←</button>
    <div class="headerInfo">
      <div class="line">Fuse Settings</div>
      <div class="line">OpenVampire ESP32</div>
    </div>
  </div>

  <!-- BATTERY PROTECTION -->
  <div class="card">
    <h2>Battery Protection</h2>
    <table class="modeTable">
      <tr>
        <td><input type="checkbox" id="batVoltEnable"></td>
        <td>Battery Voltage</td>
        <td><input id="batVolt" type="number" min="0" step="0.1"></td>
        <td>V</td>
      </tr>
      <tr>
        <td><input type="checkbox" id="batSocEnable"></td>
        <td>Battery SOC</td>
        <td><input id="batSoc" type="number" min="0" max="100" step="1"></td>
        <td>%</td>
      </tr>
      <tr>
        <td><input type="checkbox" id="chargeEnable"></td>
        <td>Charge Current</td>
        <td><input id="chargeCurrent" type="number" min="0" step="0.1"></td>
        <td>A</td>
      </tr>
      <tr>
        <td><input type="checkbox" id="dischargeEnable"></td>
        <td>Discharge Current</td>
        <td><input id="dischargeCurrent" type="number" min="0" step="0.1"></td>
        <td>A</td>
      </tr>
    </table>
  </div>

  <!-- FUSES -->
  <div class="card">
    <h2>Power Limits</h2>
    <table class="modeTable">
      <tr>
        <td><input type="checkbox" id="loadEnable"></td>
        <td>Inverter Load</td>
        <td><input id="loadLimit" type="number" min="0" step="10"></td>
        <td>W</td>
      </tr>
      <tr>
        <td><input type="checkbox" id="gridEnable"></td>
        <td>Grid Power</td>
        <td><input id="gridLimit" type="number" min="0" step="10"></td>
        <td>W</td>
      </tr>
    </table>
  </div>

  <!-- ACTIONS -->
  <div class="applyBlock">
    <button class="applyButton" onclick="saveFuseSettings()">Save</button>
  </div>
  <div class="applyBlock">
    <button class="applyButton" onclick="backToMain()">Back</button>
  </div>

</div>

<script>
// OpenVampire ESP32 - fuses.js

const FUSE = {
  batVoltEnable   : document.getElementById("batVoltEnable"),
  batVolt         : document.getElementById("batVolt"),
  batSocEnable    : document.getElementById("batSocEnable"),
  batSoc          : document.getElementById("batSoc"),
  chargeEnable    : document.getElementById("chargeEnable"),
  chargeCurrent   : document.getElementById("chargeCurrent"),
  dischargeEnable : document.getElementById("dischargeEnable"),
  dischargeCurrent: document.getElementById("dischargeCurrent"),
  loadEnable      : document.getElementById("loadEnable"),
  loadLimit       : document.getElementById("loadLimit"),
  gridEnable      : document.getElementById("gridEnable"),
  gridLimit       : document.getElementById("gridLimit")
};

function backToMain() {
  window.location.replace("/?t=" + Date.now());
}

async function fetchWithTimeout(url, options = {}, timeoutMs = 5000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    return await fetch(url, {
      ...options,
      cache: "no-store",
      signal: controller.signal
    });
  } finally {
    clearTimeout(timer);
  }
}

function updateFuseControls() {
  FUSE.batVolt.disabled          = !FUSE.batVoltEnable.checked;
  FUSE.batSoc.disabled           = !FUSE.batSocEnable.checked;
  FUSE.chargeCurrent.disabled    = !FUSE.chargeEnable.checked;
  FUSE.dischargeCurrent.disabled = !FUSE.dischargeEnable.checked;
  FUSE.loadLimit.disabled        = !FUSE.loadEnable.checked;
  FUSE.gridLimit.disabled        = !FUSE.gridEnable.checked;
}

async function loadFuseSettings() {
  try {
    const r = await fetchWithTimeout("/api/fuses?t=" + Date.now());
    if (!r.ok) throw new Error("HTTP status " + r.status);
    const j = await r.json();

    FUSE.batVoltEnable.checked   = Boolean(j.batVoltEnable);
    FUSE.batVolt.value          = j.batVolt ?? "";

    FUSE.batSocEnable.checked    = Boolean(j.batSocEnable);
    FUSE.batSoc.value           = j.batSoc ?? "";

    FUSE.chargeEnable.checked    = Boolean(j.chargeEnable);
    FUSE.chargeCurrent.value    = j.chargeCurrent ?? "";

    FUSE.dischargeEnable.checked = Boolean(j.dischargeEnable);
    FUSE.dischargeCurrent.value = j.dischargeCurrent ?? "";

    FUSE.loadEnable.checked      = Boolean(j.loadEnable);
    FUSE.loadLimit.value        = j.loadLimit ?? "";

    FUSE.gridEnable.checked      = Boolean(j.gridEnable);
    FUSE.gridLimit.value        = j.gridLimit ?? "";
  } catch(e) {
    alert("Cannot load fuse settings.");
  } finally {
    updateFuseControls();
  }
}

async function saveFuseSettings() {
  const data = {
    batVoltEnable   : FUSE.batVoltEnable.checked,
    batVolt         : Number(FUSE.batVolt.value),
    batSocEnable    : FUSE.batSocEnable.checked,
    batSoc          : Number(FUSE.batSoc.value),
    chargeEnable    : FUSE.chargeEnable.checked,
    chargeCurrent   : Number(FUSE.chargeCurrent.value),
    dischargeEnable : FUSE.dischargeEnable.checked,
    dischargeCurrent: Number(FUSE.dischargeCurrent.value),
    loadEnable      : FUSE.loadEnable.checked,
    loadLimit       : Number(FUSE.loadLimit.value),
    gridEnable      : FUSE.gridEnable.checked,
    gridLimit       : Number(FUSE.gridLimit.value)
  };

  try {
    const r = await fetchWithTimeout("/api/fuses?t=" + Date.now(), {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Cache-Control": "no-cache"
      },
      body: JSON.stringify(data)
    }, 10000);
    if (!r.ok) throw new Error("Save error");
    alert("Fuse settings saved.");
  } catch(e) {
    alert("Save error.");
  }
}

// Bind events
Object.keys(FUSE).filter(k => k.endsWith("Enable")).forEach(key => {
  FUSE[key].onchange = updateFuseControls;
});

window.onload = loadFuseSettings;
</script>

<script>
(function(){
  fetch('/api/status?t='+Date.now(),{cache:'no-store'})
    .then(function(r){return r.json();})
    .then(function(j){
      var sn=(j.serial||'').trim();
      if(sn) document.title=sn.indexOf('SV-')===0?sn:'SV-'+sn;
    })
    .catch(function(){});
})();
</script></body>
</html>
)rawliteral";