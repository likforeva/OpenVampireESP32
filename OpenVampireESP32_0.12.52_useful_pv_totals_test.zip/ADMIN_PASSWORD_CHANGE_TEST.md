# OpenVampireESP32 0.12.44 — Admin password change test

- Router/STA mode: telemetry remains open; protected changes require Admin login.
- Router/STA mode: an authenticated administrator can change the password by entering the current password plus the new password twice.
- ESP32 AP service mode (192.168.4.1): full service access without Admin password; the password can be replaced without knowing the old one.
- Existing AP shutdown behavior (5 minutes after successful router connection) is unchanged.
