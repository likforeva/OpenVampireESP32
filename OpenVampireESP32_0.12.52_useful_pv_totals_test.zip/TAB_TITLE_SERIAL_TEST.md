# OpenVampireESP32 0.12.42 — Browser tab serial title test

- Browser tab title changes from the generic OpenVampire name to `SV-<Vampire serial>`.
- The title is updated after `/api/status` returns the connected Vampire serial number.
- Main, Statistics, Fuse Settings, MQTT, Vampire Update, ESP32 OTA and Administration pages are covered.
- If the Vampire serial is not available yet, the page keeps its normal fallback title until status becomes available.
