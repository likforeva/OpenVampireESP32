# Useful PV statistics test — 0.12.51

Test change:

- `Power — current day` is unchanged and continues to plot raw `PV1 + PV2` power.
- Accumulated PV energy (`Today`, daily bars, monthly/year archive, `Current month`, `All time`) now integrates useful PV power:

  `max(0, Load + Battery charge - Battery discharge - Grid import + Grid export)`

- Load, battery charge/discharge and grid energy integration are otherwise unchanged.
- Existing stored historical PV totals are not retroactively recalculated. For a clean A/B comparison, reset statistics at the chosen test boundary.
