# 0.12.47 Monitor First Layout Test

- Moved **Real-Time Monitor** above **Smooth Control Setting** on the main page.
- Telemetry is now visible immediately after opening the page, especially on mobile screens.
- No telemetry, control, MQTT, statistics, authentication, or firmware-update logic was changed.
- Fixed the missing closing `</div>` for the Smooth Control card while reordering the blocks.
- Based on 0.12.46 Energy Frame Diagnostics Fix Test.
