# 0.12.52 Useful PV Totals Test

Accumulated PV energy is derived from accumulated energy flows:

`PV useful = max(0, Load + Battery charge - Battery discharge - Grid import + Grid export)`

Unlike 0.12.51, the formula is applied to accumulated kWh totals, not to every instantaneous sample. This avoids positive bias from clipping negative instantaneous balance values to zero.

The current-day Power graph is unchanged and continues to show raw PV1 + PV2 input power.

Existing daily and monthly records are recalculated in RAM from their stored Load/Battery/Grid totals, so historical graph values can also reflect the new formula.
