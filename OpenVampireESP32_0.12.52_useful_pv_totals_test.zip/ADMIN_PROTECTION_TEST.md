# 0.12.41 Admin protection test

- Viewing telemetry, settings, statistics and status remains available without a password.
- Changes through the router/STA interface require an administrator session.
- Protected actions: Vampire settings, protocol, fuses, Wi-Fi, MQTT, statistics reset, ESP restart, ESP32 OTA, Vampire firmware upload/start.
- Administration page: `/admin`.
- Default administrator password on first boot: `admin`.
- STA login session lasts 15 minutes and is stored in an HttpOnly SameSite cookie.
- Password is stored in NVS as SHA-256, not as plaintext.
- When a request arrives through the ESP32 AP interface (`192.168.4.1`), protected actions are allowed without admin login (service mode).
- Administrator password can be changed/replaced only through the AP interface on `/admin`.
- AP behavior remains: it starts at boot and shuts down 5 minutes after successful router connection.
- If the router connection is later lost, the AP is NOT restarted automatically; reboot the ESP32 to restore the 5-minute service window.
