# 0.12.45 Energy Diagnostics Test

Temporary diagnostic build for comparing ESP32 energy statistics with DessMonitor.

Changes:
- The current-day power graph now uses the average of all telemetry samples in each 5-minute interval instead of the last sample in the interval.
- Added a diagnostic panel with PV1/PV2 integration, normal PV integration, a 5-minute sample-average PV estimate, energy balance, sample counts, rejected long gaps, maximum telemetry gap, and maximum PV power.
- Existing Today/Month/All-time accumulated energy counters are not recalibrated or corrected in this test build.
- Diagnostic counters are RAM-only and reset after reboot or at daily graph rollover.

Purpose: collect one full uninterrupted day and compare the counters with DessMonitor before changing the production energy calculation.
