# 0.12.48 PV 5-minute comparison test

- Removed the previous Energy diagnostics test panel and its temporary counters.
- Production Today / Current month / All time energy integration is unchanged.
- Added a temporary PV 5-minute comparison test.
- Captures one real UART telemetry-frame PV snapshot for each 5-minute interval.
- Calculates a parallel daily estimate assuming that snapshot represents the full 5-minute interval.
- Shows normal Today PV, 5-minute snapshot estimate, difference, captured interval count, and a per-interval table.
- Test data is RAM-only and resets after reboot or daily graph reset.
- Real-Time Monitor remains above Smooth Control Setting from 0.12.47.
- The normal comparison value uses only PV energy accumulated since the test started, so reflashing/rebooting mid-day does not compare RAM-only test data against older NVS-restored energy.
