# 0.12.46 Energy Frame Diagnostics Fix Test

Diagnostic follow-up build for comparing OpenVampire ESP32 energy statistics with DessMonitor.

Changes:
- Fixed the diagnostic sample counter: it now counts real UART telemetry frames instead of every `loop()` read of the cached Telemetry object.
- Added a telemetry `frameId` that increments once per parsed telemetry frame, including invalid frames.
- Fixed the 5-minute graph/estimate accumulator overflow seen in 0.12.45.
- The current-day graph now uses time-weighted averages of real telemetry frames.
- Added `EnergyStats update calls` and `Cached-value loop reads` so the difference between firmware loop rate and actual telemetry frame rate is visible.
- `Maximum telemetry gap` and `Rejected gaps > 30 s` are now based on real UART frame spacing.
- The production Today/Month/All-time energy integration algorithm is intentionally unchanged in this test build.

Purpose:
Run for a full uninterrupted day and compare `PV normal integration`, `PV telemetry-frame estimate`, and DessMonitor. The two ESP counters should now be close to each other instead of the impossible 0.12.45 5-minute estimate.
