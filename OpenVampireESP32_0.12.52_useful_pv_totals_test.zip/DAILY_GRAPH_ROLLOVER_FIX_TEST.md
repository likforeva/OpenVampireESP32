# 0.12.40 Daily graph rollover fix test

- Clears the 24-hour power graph buffer when the local calendar day changes.
- Clears the graph when a month/year rollover is processed.
- Resets graph sampling state so the first new-day point starts cleanly.
- Handles delayed NTP synchronization after startup: if the saved date differs from the current date, the old graph is discarded during rollover processing.
- Keeps daily/monthly/all-time energy counters and archives unchanged.
