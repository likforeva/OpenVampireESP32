# OpenVampireESP32 0.12.43 — Browser tab title compile fix

- Fixed malformed multiline C++ string in `AdminAuth.cpp`.
- Browser tab title remains `SV-<Vampire serial>` after serial number is received.
- No functional changes to administrator protection or energy statistics.
