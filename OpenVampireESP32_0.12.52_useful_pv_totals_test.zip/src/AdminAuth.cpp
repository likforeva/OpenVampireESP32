#include "AdminAuth.h"

#include <WiFi.h>
#include <Preferences.h>
#include <esp_system.h>
#include <mbedtls/sha256.h>
#include <ArduinoJson.h>

AdminAuth adminAuth;

namespace
{
Preferences adminPrefs;
const char *DEFAULT_ADMIN_PASSWORD = "admin";
}

String AdminAuth::sha256Hex(const String &value) const
{
    unsigned char hash[32];
    mbedtls_sha256_ret(reinterpret_cast<const unsigned char *>(value.c_str()),
                       value.length(), hash, 0);

    static const char hex[] = "0123456789abcdef";
    String out;
    out.reserve(64);
    for (size_t i = 0; i < sizeof(hash); ++i)
    {
        out += hex[(hash[i] >> 4) & 0x0F];
        out += hex[hash[i] & 0x0F];
    }
    return out;
}

void AdminAuth::saveHash(const String &hash)
{
    _passwordHash = hash;
    adminPrefs.putString("pwdhash", hash);
}

void AdminAuth::begin()
{
    adminPrefs.begin("admin", false);
    _passwordHash = adminPrefs.getString("pwdhash", "");
    if (_passwordHash.isEmpty())
    {
        saveHash(sha256Hex(DEFAULT_ADMIN_PASSWORD));
        Serial.println("Admin password initialized to default: admin");
    }
}

bool AdminAuth::isApRequest(WebServer &server) const
{
    const wifi_mode_t mode = WiFi.getMode();
    if (mode != WIFI_AP && mode != WIFI_AP_STA)
        return false;

    const IPAddress apIp = WiFi.softAPIP();
    const IPAddress localIp = server.client().localIP();
    return apIp != IPAddress(0, 0, 0, 0) && localIp == apIp;
}

String AdminAuth::cookieValue(WebServer &server, const String &name) const
{
    if (!server.hasHeader("Cookie"))
        return "";

    const String cookies = server.header("Cookie");
    const String key = name + "=";
    int pos = cookies.indexOf(key);
    if (pos < 0)
        return "";
    pos += key.length();
    int end = cookies.indexOf(';', pos);
    if (end < 0)
        end = cookies.length();
    String value = cookies.substring(pos, end);
    value.trim();
    return value;
}

bool AdminAuth::isAuthenticated(WebServer &server)
{
    if (isApRequest(server))
        return true;

    if (_sessionToken.isEmpty())
        return false;

    if ((int32_t)(millis() - _sessionExpiresAt) >= 0)
    {
        _sessionToken = "";
        _sessionExpiresAt = 0;
        return false;
    }

    const String token = cookieValue(server, "OVADMIN");
    if (token != _sessionToken)
        return false;

    // Sliding 15 minute timeout while protected actions are being used.
    _sessionExpiresAt = millis() + SESSION_TTL_MS;
    return true;
}

bool AdminAuth::require(WebServer &server)
{
    if (isAuthenticated(server))
        return true;

    server.sendHeader("Cache-Control", "no-store");
    server.send(401,
                "application/json",
                R"({"result":"auth_required","message":"Administrator password required. Open Administration and sign in."})");
    return false;
}

String AdminAuth::makeToken() const
{
    char buf[33];
    snprintf(buf, sizeof(buf), "%08lx%08lx%08lx%08lx",
             (unsigned long)esp_random(),
             (unsigned long)esp_random(),
             (unsigned long)esp_random(),
             (unsigned long)esp_random());
    return String(buf);
}

bool AdminAuth::login(WebServer &server, const String &password)
{
    if (sha256Hex(password) != _passwordHash)
        return false;

    _sessionToken = makeToken();
    _sessionExpiresAt = millis() + SESSION_TTL_MS;
    server.sendHeader("Set-Cookie", "OVADMIN=" + _sessionToken + "; Path=/; HttpOnly; SameSite=Strict");
    return true;
}

void AdminAuth::logout(WebServer &server)
{
    _sessionToken = "";
    _sessionExpiresAt = 0;
    server.sendHeader("Set-Cookie", "OVADMIN=; Path=/; Max-Age=0; HttpOnly; SameSite=Strict");
}

bool AdminAuth::setPasswordFromAp(WebServer &server, const String &newPassword, String &error)
{
    if (!isApRequest(server))
    {
        error = "Administrator password can only be changed through the ESP32 access point (192.168.4.1).";
        return false;
    }

    if (newPassword.length() < 4)
    {
        error = "Password must contain at least 4 characters.";
        return false;
    }

    saveHash(sha256Hex(newPassword));
    _sessionToken = "";
    _sessionExpiresAt = 0;
    return true;
}


bool AdminAuth::changePassword(WebServer &server, const String &currentPassword, const String &newPassword, String &error)
{
    if (isApRequest(server))
        return setPasswordFromAp(server, newPassword, error);

    if (!isAuthenticated(server))
    {
        error = "Administrator session is locked.";
        return false;
    }

    if (sha256Hex(currentPassword) != _passwordHash)
    {
        error = "Current administrator password is incorrect.";
        return false;
    }

    if (newPassword.length() < 4)
    {
        error = "Password must contain at least 4 characters.";
        return false;
    }

    saveHash(sha256Hex(newPassword));
    // Keep the current browser authenticated after a successful password change.
    _sessionExpiresAt = millis() + SESSION_TTL_MS;
    return true;
}

String AdminAuth::stateJson(WebServer &server)
{
    JsonDocument doc;
    doc["ap_mode"] = isApRequest(server);
    doc["authenticated"] = isAuthenticated(server);
    doc["session_minutes"] = 15;
    String out;
    serializeJson(doc, out);
    return out;
}

String AdminAuth::pageHtml(WebServer &server)
{
    const bool ap = isApRequest(server);
    const bool logged = isAuthenticated(server);

    String html = R"rawliteral(<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>OpenVampire Administration</title><style>
body{font-family:Arial,sans-serif;background:#f3f5f8;color:#172033;margin:0;padding:18px}.wrap{max-width:560px;margin:auto}.card{background:#fff;border:1px solid #d8dee8;border-radius:14px;padding:22px;box-shadow:0 4px 18px #00000012}h2{margin-top:0}.mode{padding:11px 13px;border-radius:9px;background:#eef4ff;margin:12px 0 20px;font-weight:700}.ok{color:#16723b}.bad{color:#b42318}label{display:block;margin:14px 0 6px;font-weight:700}input{box-sizing:border-box;width:100%;padding:11px;border:1px solid #b9c2d0;border-radius:8px;font-size:16px}button{margin-top:14px;padding:11px 18px;border:0;border-radius:8px;background:#174ea6;color:#fff;font-weight:700;font-size:15px;cursor:pointer}.secondary{background:#5f6b7a}.msg{margin-top:14px;min-height:20px;font-weight:700}.note{font-size:13px;color:#5b6574;line-height:1.45}.row{display:flex;gap:10px;flex-wrap:wrap}.row button{flex:1;min-width:130px}</style></head><body><div class="wrap"><div class="card"><h2>Administration</h2>)rawliteral";

    if (ap)
    {
        html += R"rawliteral(<div class="mode ok">Service mode — access through ESP32 AP (192.168.4.1). No administrator password is required.</div>
<p class="note">You can set or replace the administrator password here. This password protects changes made through the router network.</p>
<label for="p1">New administrator password</label><input id="p1" type="password" autocomplete="new-password">
<label for="p2">Repeat password</label><input id="p2" type="password" autocomplete="new-password">
<div class="row"><button id="change">Change password</button><button class="secondary" onclick="location.href='/'">Back</button></div><div id="msg" class="msg"></div>
<script>document.getElementById('change').addEventListener('click',async()=>{const a=p1.value,b=p2.value;if(a!==b){msg.textContent='Passwords do not match.';msg.className='msg bad';return}try{const r=await fetch('/api/admin/password',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:a})});const d=await r.json();msg.textContent=d.message|| (r.ok?'Password changed.':'Error');msg.className='msg '+(r.ok?'ok':'bad');if(r.ok){p1.value='';p2.value=''}}catch(e){msg.textContent='Connection error.';msg.className='msg bad'}})</script>)rawliteral";
    }
    else
    {
        html += String("<div class=\"mode ") + (logged ? "ok\">Administrator session is unlocked." : "bad\">Administrator session is locked.") + "</div>";
        if (!logged)
        {
            html += R"rawliteral(<p class="note">Viewing telemetry and statistics remains open. Sign in to change settings, Wi-Fi, MQTT, reset statistics, restart, or flash ESP32/Vampire. The session expires after 15 minutes.</p>
<label for="pwd">Administrator password</label><input id="pwd" type="password" autocomplete="current-password">
<div class="row"><button id="login">Unlock</button><button class="secondary" onclick="location.href='/'">Back</button></div><div id="msg" class="msg"></div>
<script>document.getElementById('login').addEventListener('click',async()=>{try{const r=await fetch('/api/admin/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:pwd.value})});const d=await r.json();if(r.ok){location.reload();return}msg.textContent=d.message||'Wrong password.';msg.className='msg bad'}catch(e){msg.textContent='Connection error.';msg.className='msg bad'}});pwd.addEventListener('keydown',e=>{if(e.key==='Enter')login.click()})</script>)rawliteral";
        }
        else
        {
            html += R"rawliteral(<p class="note">Protected changes are enabled for this browser. Activity on protected actions extends the 15 minute session.</p>
<hr style="border:0;border-top:1px solid #d8dee8;margin:22px 0">
<h3>Change administrator password</h3>
<label for="curpwd">Current password</label><input id="curpwd" type="password" autocomplete="current-password">
<label for="newpwd1">New password</label><input id="newpwd1" type="password" autocomplete="new-password">
<label for="newpwd2">Repeat new password</label><input id="newpwd2" type="password" autocomplete="new-password">
<button id="changePwd">Change password</button><div id="pwdmsg" class="msg"></div>
<hr style="border:0;border-top:1px solid #d8dee8;margin:22px 0">
<div class="row"><button id="logout" class="secondary">Lock now</button><button onclick="location.href='/'">Back</button></div>
<script>
document.getElementById('changePwd').addEventListener('click',async()=>{
  const c=curpwd.value,a=newpwd1.value,b=newpwd2.value;
  if(a!==b){pwdmsg.textContent='Passwords do not match.';pwdmsg.className='msg bad';return;}
  try{
    const r=await fetch('/api/admin/password',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({current_password:c,password:a})});
    const d=await r.json();
    pwdmsg.textContent=d.message||(r.ok?'Password changed.':'Error');
    pwdmsg.className='msg '+(r.ok?'ok':'bad');
    if(r.ok){curpwd.value='';newpwd1.value='';newpwd2.value='';}
  }catch(e){pwdmsg.textContent='Connection error.';pwdmsg.className='msg bad';}
});
document.getElementById('logout').addEventListener('click',async()=>{await fetch('/api/admin/logout',{method:'POST'});location.reload()});
</script>)rawliteral";
        }
    }

    html += R"rawliteral(</div></div><script>
(function(){
  fetch('/api/status?t='+Date.now(),{cache:'no-store'})
    .then(function(r){return r.json();})
    .then(function(j){
      var sn=(j.serial||'').trim();
      if(sn) document.title=sn.indexOf('SV-')===0?sn:'SV-'+sn;
    })
    .catch(function(){});
})();
</script></body></html>)rawliteral";
    return html;
}
