# 0.12.26 MQTT Deep Debug Test

Based on 0.12.25. Adds direct visibility into the real `PubSubClient::publish()` result, actual topic used, payload length and payload preview. The MQTT topic is now editable and stored in Preferences; an empty value keeps the automatic `tele/VAMPIRE/SV-<serial>/STATE` topic.
