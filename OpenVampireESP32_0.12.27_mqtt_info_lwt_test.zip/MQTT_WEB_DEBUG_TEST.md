# 0.12.25 MQTT Web Debug Test

Based on 0.12.24 (No Bluetooth + MQTT + Wi-Fi bars).

Added MQTT diagnostics directly to the web interface for systems where USB/Serial Monitor is unavailable:

- connection state and PubSubClient state code;
- last connection/publish error;
- successful publish and failure counters;
- connection attempt and reconnect counters;
- age of the last successful publication;
- manual `Send Test Message` button (`.../TEST` topic);
- manual `Reconnect MQTT` button;
- diagnostics refresh every 3 seconds.

Normal telemetry topic and payload remain unchanged.
