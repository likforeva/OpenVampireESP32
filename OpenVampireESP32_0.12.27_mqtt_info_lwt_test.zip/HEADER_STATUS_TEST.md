# Header status test 0.12.23

Added to the main-page header:

- Wi-Fi RSSI in dBm with a compact signal bar;
- ESP32 uptime in days, hours, minutes and seconds.

The values are supplied by `/api/status` and refresh with the existing status polling.
MQTT, OTA, Vampire update and telemetry logic are unchanged.
