#include "MqttManager.h"
#include <WiFi.h>
#include <ArduinoJson.h>
#include "Config.h"

MqttManager::MqttManager() : client(wifiClient)
{
}

void MqttManager::begin()
{
    load();
    client.setBufferSize(768);
    client.setKeepAlive(20);
    client.setSocketTimeout(2);
    lastClientState = client.state();
}

void MqttManager::load()
{
    prefs.begin("mqtt", true);
    cfg.enabled = prefs.getBool("enabled", false);
    cfg.host = prefs.getString("host", "");
    cfg.port = prefs.getUShort("port", 1883);
    cfg.user = prefs.getString("user", "");
    cfg.password = prefs.getString("pass", "");
    cfg.periodSeconds = prefs.getUShort("period", 10);
    cfg.topic = prefs.getString("topic", "");
    prefs.end();
}

void MqttManager::save(const MqttConfig &newConfig)
{
    const bool reconnectRequired =
        cfg.host != newConfig.host ||
        cfg.port != newConfig.port ||
        cfg.user != newConfig.user ||
        cfg.password != newConfig.password ||
        cfg.enabled != newConfig.enabled;

    cfg = newConfig;

    prefs.begin("mqtt", false);
    prefs.putBool("enabled", cfg.enabled);
    prefs.putString("host", cfg.host);
    prefs.putUShort("port", cfg.port);
    prefs.putString("user", cfg.user);
    prefs.putString("pass", cfg.password);
    prefs.putUShort("period", cfg.periodSeconds);
    prefs.putString("topic", cfg.topic);
    prefs.end();

    if (reconnectRequired && client.connected())
        client.disconnect();

    lastConnectAttempt = 0;
    lastPublish = 0;
    lastClientState = client.state();
    lastError = cfg.enabled ? "Configuration saved; waiting for connection" : "MQTT disabled";
}

void MqttManager::pause(bool paused)
{
    isPaused = paused;
    if (paused && client.connected())
        client.disconnect();
    if (paused)
        lastError = "Paused by maintenance/update mode";
}

String MqttManager::topicFor(const String &serialNumber) const
{
    if (!cfg.topic.isEmpty())
        return cfg.topic;

    String sn = serialNumber;
    if (sn.isEmpty())
        sn = "UNKNOWN";
    return "tele/VAMPIRE/SV-" + sn + "/STATE";
}

String MqttManager::derivedTopic(const String &serialNumber, const char *suffix) const
{
    String base = topicFor(serialNumber);
    if (base.endsWith("/STATE"))
        base.remove(base.length() - 6);
    return base + "/" + suffix;
}

String MqttManager::clientStateText() const
{
    switch (lastClientState)
    {
    case MQTT_CONNECTION_TIMEOUT: return "Connection timeout (-4)";
    case MQTT_CONNECTION_LOST: return "Connection lost (-3)";
    case MQTT_CONNECT_FAILED: return "TCP connect failed (-2)";
    case MQTT_DISCONNECTED: return "Disconnected (-1)";
    case MQTT_CONNECTED: return "Connected (0)";
    case MQTT_CONNECT_BAD_PROTOCOL: return "Bad protocol (1)";
    case MQTT_CONNECT_BAD_CLIENT_ID: return "Bad client ID (2)";
    case MQTT_CONNECT_UNAVAILABLE: return "Broker unavailable (3)";
    case MQTT_CONNECT_BAD_CREDENTIALS: return "Bad credentials (4)";
    case MQTT_CONNECT_UNAUTHORIZED: return "Unauthorized (5)";
    default: return "Unknown state (" + String(lastClientState) + ")";
    }
}

void MqttManager::rememberClientState(const String &context)
{
    lastClientState = client.state();
    lastError = context + ": " + clientStateText();
}

bool MqttManager::connect(const String &serialNumber, const String &vampireFirmware)
{
    if (cfg.host.isEmpty())
    {
        lastError = "Broker address is empty";
        return false;
    }

    client.setServer(cfg.host.c_str(), cfg.port);

    String sn = serialNumber;
    if (sn.isEmpty())
        sn = "UNKNOWN";

    const uint64_t mac = ESP.getEfuseMac();
    char macSuffix[9];
    snprintf(macSuffix, sizeof(macSuffix), "%08lX", (unsigned long)(mac & 0xFFFFFFFFULL));
    String clientId = "OpenVampire-" + sn + "-" + String(macSuffix);

    const String lwtTopic = derivedTopic(serialNumber, "LWT");
    connectAttemptCount++;
    const bool wasEverConnected = lastSuccessfulConnect != 0;
    bool ok = false;
    if (cfg.user.isEmpty())
        ok = client.connect(clientId.c_str(), lwtTopic.c_str(), 0, true, "offline");
    else
        ok = client.connect(clientId.c_str(), cfg.user.c_str(), cfg.password.c_str(),
                            lwtTopic.c_str(), 0, true, "offline");

    lastClientState = client.state();
    if (ok)
    {
        if (wasEverConnected)
            reconnectCount++;
        lastSuccessfulConnect = millis();
        lastError = "None";

        client.publish(lwtTopic.c_str(), "online", true);
        publishInfo(serialNumber, vampireFirmware);
        return true;
    }

    rememberClientState("Connect failed");
    return false;
}

bool MqttManager::publishPayload(const String &topic, const uint8_t *payload, size_t length)
{
    lastPublishedTopic = topic;
    lastPayloadSize = length;
    lastPublishedPayload = "";
    if (payload != nullptr && length > 0)
    {
        const size_t previewLength = length > 480 ? 480 : length;
        lastPublishedPayload.reserve(previewLength + (length > previewLength ? 3 : 0));
        for (size_t i = 0; i < previewLength; ++i)
            lastPublishedPayload += (char)payload[i];
        if (length > previewLength)
            lastPublishedPayload += "...";
    }

    if (!client.connected())
    {
        lastError = "Publish skipped: MQTT is not connected";
        publishFailureCount++;
        lastPublishOk = false;
        hasLastPublishResult = true;
        return false;
    }

    const bool ok = client.publish(topic.c_str(), payload, length, false);
    lastClientState = client.state();
    lastPublishOk = ok;
    hasLastPublishResult = true;
    if (ok)
    {
        publishCount++;
        lastSuccessfulPublish = millis();
        lastError = "None";
    }
    else
    {
        publishFailureCount++;
        rememberClientState("Publish failed");
    }
    return ok;
}

bool MqttManager::publishTelemetry(const Telemetry &t, const String &serialNumber)
{
    JsonDocument doc;

    const float pv1Current = t.pv1Current / 10.0f;
    const float pv2Current = t.pv2Current / 10.0f;
    const float batteryVoltage = t.batteryVoltage / 10.0f;

    doc["PV1"] = t.pv1Voltage;
    doc["PV2"] = t.pv2Voltage;
    doc["PC1"] = pv1Current;
    doc["PC2"] = pv2Current;
    doc["PW1"] = (float)t.pv1Voltage * pv1Current;
    doc["PW2"] = (float)t.pv2Voltage * pv2Current;
    doc["BAT"] = batteryVoltage;
    doc["SOC"] = t.batterySOC;
    doc["CHR"] = t.chargeCurrent;
    doc["DSC"] = t.dischargeCurrent;
    doc["LOAD"] = t.inverterLoad;
    doc["OUT"] = t.regulatorOutput;

    char payload[512];
    const size_t length = serializeJson(doc, payload, sizeof(payload));
    return publishPayload(topicFor(serialNumber), reinterpret_cast<const uint8_t *>(payload), length);
}

bool MqttManager::publishInfo(const String &serialNumber, const String &vampireFirmware)
{
    JsonDocument doc;
    doc["SN"] = serialNumber.isEmpty() ? "UNKNOWN" : serialNumber;
    doc["FW"] = vampireFirmware;
    doc["ESP"] = FW_VERSION;
    doc["IP"] = WiFi.localIP().toString();
    doc["RSSI"] = WiFi.RSSI();
    doc["Uptime"] = millis() / 1000UL;

    char payload[320];
    const size_t length = serializeJson(doc, payload, sizeof(payload));
    const String infoTopic = derivedTopic(serialNumber, "INFO");
    const bool ok = client.publish(infoTopic.c_str(), reinterpret_cast<const uint8_t *>(payload), length, true);
    if (!ok)
        rememberClientState("INFO publish failed");
    return ok;
}

bool MqttManager::publishTest(const String &serialNumber)
{
    if (!cfg.enabled)
    {
        lastError = "Test failed: MQTT is disabled";
        return false;
    }
    if (isPaused)
    {
        lastError = "Test failed: MQTT is paused";
        return false;
    }
    if (WiFi.status() != WL_CONNECTED)
    {
        lastError = "Test failed: WiFi is offline";
        return false;
    }

    lastSerialNumber = serialNumber;
    if (!client.connected() && !connect(serialNumber, ""))
        return false;

    JsonDocument doc;
    doc["test"] = "ok";
    doc["sn"] = serialNumber;
    doc["uptime_s"] = millis() / 1000UL;

    char payload[192];
    const size_t length = serializeJson(doc, payload, sizeof(payload));
    String topic = topicFor(serialNumber);
    if (topic.endsWith("/STATE"))
        topic = topic.substring(0, topic.length() - 6) + "/TEST";
    else
        topic += "/TEST";
    return publishPayload(topic, reinterpret_cast<const uint8_t *>(payload), length);
}

void MqttManager::forceReconnect()
{
    if (client.connected())
        client.disconnect();
    lastConnectAttempt = 0;
    lastClientState = client.state();
    lastError = "Manual reconnect requested";
}

uint32_t MqttManager::lastPublishAgeSeconds() const
{
    if (lastSuccessfulPublish == 0)
        return UINT32_MAX;
    return (uint32_t)(millis() - lastSuccessfulPublish) / 1000UL;
}

uint32_t MqttManager::lastConnectAgeSeconds() const
{
    if (lastSuccessfulConnect == 0)
        return UINT32_MAX;
    return (uint32_t)(millis() - lastSuccessfulConnect) / 1000UL;
}

void MqttManager::update(const Telemetry &telemetry, const String &serialNumber, const String &vampireFirmware)
{
    lastSerialNumber = serialNumber;

    if (!cfg.enabled || isPaused || WiFi.status() != WL_CONNECTED)
    {
        if (client.connected())
            client.disconnect();
        lastClientState = client.state();
        if (!cfg.enabled)
            lastError = "MQTT disabled";
        else if (isPaused)
            lastError = "Paused by maintenance/update mode";
        else
            lastError = "WiFi offline";
        return;
    }

    if (!client.connected())
    {
        if ((uint32_t)(millis() - lastConnectAttempt) < 10000)
            return;

        lastConnectAttempt = millis();
        if (!connect(serialNumber, vampireFirmware))
            return;
    }

    client.loop();
    lastClientState = client.state();

    if (!telemetry.valid)
    {
        lastError = "Connected; waiting for valid telemetry";
        return;
    }

    const uint32_t periodMs =
        (cfg.periodSeconds == 0 ? 60UL : (uint32_t)cfg.periodSeconds) * 1000UL;

    if ((uint32_t)(millis() - lastPublish) < periodMs)
        return;

    lastPublish = millis();
    publishTelemetry(telemetry, serialNumber);
}

String MqttManager::stateText()
{
    if (!cfg.enabled)
        return "disabled";
    if (isPaused)
        return "paused";
    if (WiFi.status() != WL_CONNECTED)
        return "wifi_offline";
    if (cfg.host.isEmpty())
        return "not_configured";
    return client.connected() ? "connected" : "disconnected";
}
