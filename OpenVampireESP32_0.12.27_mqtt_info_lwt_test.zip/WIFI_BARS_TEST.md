# WiFi Bars Test

Version: 0.12.24-wifi-bars-test

- Replaced the single Unicode RSSI symbol with a four-step CSS signal indicator.
- Active bars are blue; inactive bars are light gray.
- The WiFi label and numeric RSSI value remain visible.
- AP mode shows all bars inactive and displays `WiFi AP`.
