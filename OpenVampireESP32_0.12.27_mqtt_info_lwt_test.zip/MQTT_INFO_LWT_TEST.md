# 0.12.27 MQTT INFO + LWT Test

- Removed deep MQTT diagnostics and test controls from the web page.
- Kept compact Connected/Disconnected status.
- Added retained INFO message after every MQTT connection/reconnection.
- Added retained LWT availability topic with online/offline state.
- Added MAC suffix to MQTT Client ID to avoid collisions on public brokers.
- STATE telemetry format and scaling are unchanged.
